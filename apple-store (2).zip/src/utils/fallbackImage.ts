/**
 * Dynamic Apple-style SVG device graphics as an automatic fallback
 * when Unsplash or external CDN image hosts fail to load (CORS, network blocks, sandboxing).
 */
export function getFallbackImage(productName: string, selectedColorHex?: string): string {
  // Identify start/end theme colors based on device finish
  let startColor = '#1e3c72';
  let endColor = '#2a5298';
  let chassisColor = '#3B3D3F';

  const nameLower = productName.toLowerCase();
  
  if (selectedColorHex) {
    const hex = selectedColorHex.toLowerCase();
    chassisColor = selectedColorHex;
    if (['#3b3d3f', '#1f2022', '#2d3238', '#1c1d21', '#000000'].includes(hex)) {
      // Space Black / Midnight / Black Titanium
      startColor = '#2c2c2e';
      endColor = '#1c1c1e';
      chassisColor = '#48484a';
    } else if (['#e7e2dc', '#e6e8e6', '#faf9f6', '#e3e4e5'].includes(hex)) {
      // Natural Titanium / Silver / White
      startColor = '#d1cfcd';
      endColor = '#a8a6a4';
      chassisColor = '#b5b3b1';
    } else if (['#d9c8b5', '#faf4d3', '#fce9e9'].includes(hex)) {
      // Desert Titanium / Pink / Yellow
      startColor = '#dfcfbf';
      endColor = '#f0d2ad';
      chassisColor = '#cbbb9b';
    } else if (['#007791', '#dceef3'].includes(hex)) {
      // Ultramarine / Soft Blue
      startColor = '#0b5269';
      endColor = '#2183a2';
      chassisColor = '#1F6F8B';
    } else if (['#de6fa1'].includes(hex)) {
      // Soft Pink
      startColor = '#db7093';
      endColor = '#fba2c1';
      chassisColor = '#a53e6b';
    } else if (['#1ae1c6', '#edfaf5'].includes(hex)) {
      // Teal / Soft Green
      startColor = '#0a9396';
      endColor = '#94d2bd';
      chassisColor = '#1CAFA0';
    } else if (['#b51a1a'].includes(hex)) {
      // Product RED
      startColor = '#a00';
      endColor = '#e5383b';
      chassisColor = '#7a0000';
    }
  } else {
    // If no color selected yet, parse the model name patterns
    if (nameLower.includes('pro')) {
      if (nameLower.includes('desert') || nameLower.includes('gold')) {
        startColor = '#dfcfbf';
        endColor = '#dfa570';
        chassisColor = '#cbbb9b';
      } else if (nameLower.includes('natural')) {
        startColor = '#d1cfcd';
        endColor = '#a8a6a4';
        chassisColor = '#b5b3b1';
      } else {
        // Space Black / Dark Gray Pro
        startColor = '#2c2c2e';
        endColor = '#1c1c1e';
        chassisColor = '#48484a';
      }
    } else if (nameLower.includes('se')) {
      startColor = '#1c1c1e';
      endColor = '#48484a';
      chassisColor = '#3a3a3c';
    } else {
      // Standard models
      if (nameLower.includes('blue') || nameLower.includes('ultramarine')) {
        startColor = '#0b5269';
        endColor = '#2183a2';
        chassisColor = '#1F6F8B';
      } else if (nameLower.includes('pink')) {
        startColor = '#db7093';
        endColor = '#fba2c1';
        chassisColor = '#a53e6b';
      } else if (nameLower.includes('teal') || nameLower.includes('green')) {
        startColor = '#0a9396';
        endColor = '#94d2bd';
        chassisColor = '#1CAFA0';
      } else {
        startColor = '#2c2c2e';
        endColor = '#3e3e42';
        chassisColor = '#414145';
      }
    }
  }

  // Generate a clean, modern Apple-style mockup in vectors
  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 320" width="100%" height="100%" style="background:#F5F5F7;border-radius:16px;">
  <defs>
    <linearGradient id="wallGrad-${productName.replace(/[^a-zA-Z0-9]/g, '-')}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${startColor}" />
      <stop offset="50%" stop-color="${endColor}" />
      <stop offset="100%" stop-color="#121213" />
    </linearGradient>
    <linearGradient id="chassisGrad-${productName.replace(/[^a-zA-Z0-9]/g, '-')}" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${chassisColor}" />
      <stop offset="100%" stop-color="#1D1D1F" />
    </linearGradient>
  </defs>

  <!-- Shadow drop -->
  <rect x="35" y="25" width="170" height="275" rx="30" fill="rgba(0,0,0,0.06)" filter="blur(6px)" />

  <!-- External button stubs -->
  <rect x="29" y="80" width="2" height="10" rx="1" fill="#7A7B7F" />
  <rect x="29" y="96" width="2" height="14" rx="1" fill="#7A7B7F" />
  <rect x="29" y="114" width="2" height="14" rx="1" fill="#7A7B7F" />
  <rect x="209" y="90" width="2" height="22" rx="1" fill="#7A7B7F" />

  <!-- Solid Metal Curved Bezel -->
  <rect x="30" y="20" width="180" height="280" rx="28" fill="url(#chassisGrad-${productName.replace(/[^a-zA-Z0-9]/g, '-')})" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" />

  <!-- Inner border bezel -->
  <rect x="34" y="24" width="172" height="272" rx="24" fill="#0c0d0f" />

  <!-- Fluid screen wallpaper -->
  <rect x="38" y="28" width="164" height="264" rx="20" fill="url(#wallGrad-${productName.replace(/[^a-zA-Z0-9]/g, '-')})" />

  <!-- Glowing atmospheric gradients -->
  <circle cx="120" cy="160" r="45" fill="white" opacity="0.08" filter="blur(15px)" />
  <ellipse cx="80" cy="210" rx="40" ry="25" fill="${startColor}" opacity="0.4" filter="blur(12px)" />
  <ellipse cx="160" cy="100" rx="45" ry="30" fill="${endColor}" opacity="0.3" filter="blur(15px)" />

  <!-- Dynamic Island -->
  <rect x="85" y="34" width="70" height="13" rx="6.5" fill="#000000" />
  <!-- Lens reflect -->
  <circle cx="144" cy="40.5" r="1.5" fill="#141440" opacity="0.8" />
  <circle cx="144.5" cy="40.5" r="0.5" fill="#4287f5" opacity="0.9" />

  <!-- Glossy glare effect -->
  <path d="M38,28 L150,28 L38,180 Z" fill="rgba(255,255,255,0.05)" />

  <!-- Model labels inside the active screen -->
  <text x="120" y="250" text-anchor="middle" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="9.5" font-weight="700" fill="#FFFFFF" letter-spacing="-0.15">${productName}</text>
  <text x="120" y="262" text-anchor="middle" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="6.5" font-weight="500" fill="rgba(255,255,255,0.5)">Apple Intelligence</text>

  <!-- Micro details (time and battery status symbols) -->
  <text x="50" y="42" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="5.5" font-weight="600" fill="rgba(255,255,255,0.85)">9:41</text>
  <rect x="172" y="38" width="12" height="5.5" rx="1.5" fill="none" stroke="rgba(255,255,255,0.75)" stroke-width="0.75" />
  <rect x="173.2" y="39.2" width="7" height="3" rx="0.75" fill="rgba(255,255,255,0.85)" />
</svg>
`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
