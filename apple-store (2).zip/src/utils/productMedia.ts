/**
 * High-quality media asset mappings and calculations for the Apple Store.
 */

interface MediaAsset {
  videoUrl: string; // YouTube embed URL
  tagline: string;
}

const MEDIA_CATALOG: { [key: string]: MediaAsset } = {
  'iphone-16-pro-max': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Introduce iPhone 16 Pro. Built for Apple Intelligence.'
  },
  'iphone-16-pro': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Introduce iPhone 16 Pro. Titanium strength.'
  },
  'iphone-16': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Introduce iPhone 16. A giant leap in capability.'
  },
  'iphone-15-pro-max': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Titanium design. Advanced A17 Pro performance.'
  },
  'iphone-15-pro': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Titanium design. Advanced A17 Pro performance.'
  },
  'iphone-15': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'New primary 48MP camera and Dynamic Island.'
  },
  'iphone-14-pro-max': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Introduce iPhone 14 Pro with Dynamic Island.'
  },
  'iphone-14-pro': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'Introduce iPhone 14 Pro with Dynamic Island.'
  },
  'iphone-14': {
    videoUrl: 'https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4',
    tagline: 'iPhone 14. Huge camera upgrades and Crash Detection.'
  },
  'apple-watch-ultra-2': {
    videoUrl: 'https://images.pexels.com/video-files/4010131/4010131-hd_1280_720_30fps.mp4',
    tagline: 'Apple Watch Ultra 2. Adventure awaits.'
  },
  'apple-watch-series-10': {
    videoUrl: 'https://images.pexels.com/video-files/4010131/4010131-hd_1280_720_30fps.mp4',
    tagline: 'Introducing Apple Watch Series 10. Thinner, brighter.'
  },
  'airpods-pro-2': {
    videoUrl: 'https://images.pexels.com/video-files/3850541/3850541-hd_1280_720_30fps.mp4',
    tagline: 'Rebuilt from the sound up. 2x Active Noise Cancellation.'
  },
  'macbook-pro-m4': {
    videoUrl: 'https://images.pexels.com/video-files/8260154/8260154-hd_1280_720_25fps.mp4',
    tagline: 'MacBook Pro with M4, M4 Pro, and M4 Max silicon.'
  },
  'macbook-air-m3': {
    videoUrl: 'https://images.pexels.com/video-files/8260154/8260154-hd_1280_720_25fps.mp4',
    tagline: 'Supercharged by M3. Incredibly thin.'
  },
  'apple-vision-pro': {
    videoUrl: 'https://images.pexels.com/video-files/2885473/2885473-hf_1280_720_24fps.mp4',
    tagline: 'Welcome to the era of spatial computing.'
  }
};

const DEFAULT_MEDIA: MediaAsset = {
  videoUrl: 'https://images.pexels.com/video-files/2885473/2885473-hf_1280_720_24fps.mp4',
  tagline: 'Discover advanced Apple Silicon engineering.'
};

/**
 * Retrieves official video details for a given product ID.
 */
export function getProductMedia(productId: string): MediaAsset {
  // Normalize match
  const key = productId.toLowerCase();
  for (const matchKey of Object.keys(MEDIA_CATALOG)) {
    if (key.includes(matchKey) || matchKey.includes(key)) {
      return MEDIA_CATALOG[matchKey];
    }
  }
  return DEFAULT_MEDIA;
}

/**
 * Calculates monthly EMI schedules from leading credit institutions
 */
export interface EMIOption {
  bankName: string;
  months: number;
  ratePercent: number;
  monthlyInstallment: number;
  totalWithInterest: number;
}

export function calculateEMISchedules(principal: number): EMIOption[] {
  const banks = [
    { name: 'HDFC Bank (No Cost EMI)', tenure: [3, 6, 9], interest: 0 },
    { name: 'ICICI Bank (Aesthetic EMI)', tenure: [6, 12, 18], interest: 12.5 },
    { name: 'SBI Credit Card (Super Saver)', tenure: [12, 24], interest: 13.9 },
    { name: 'Axis Bank (Interest-Free Step-up)', tenure: [3, 6], interest: 0 }
  ];

  const plans: EMIOption[] = [];

  banks.forEach((b) => {
    b.tenure.forEach((m) => {
      const r = b.interest / 100 / 12;
      let monthly = 0;
      let totalAmount = principal;

      if (r === 0) {
        monthly = principal / m;
      } else {
        monthly = (principal * r * Math.pow(1 + r, m)) / (Math.pow(1 + r, m) - 1);
        totalAmount = monthly * m;
      }

      plans.push({
        bankName: b.name,
        months: m,
        ratePercent: b.interest,
        monthlyInstallment: Math.round(monthly),
        totalWithInterest: Math.round(totalAmount)
      });
    });
  });

  return plans;
}

/**
 * Periodic Dynamic Pricing Simulator parameters
 */
export function getDynamicPriceAdjustment(productId: string): { 
  fluctuation: number; 
  status: 'online' | 'syncing' | 'verified';
  rateINR: number;
} {
  // Use a reproducible hash helper to generate minor price ticks
  let hash = 0;
  for (let i = 0; i < productId.length; i++) {
    hash = productId.charCodeAt(i) + ((hash << 5) - hash);
  }
  const dateSeed = new Date().getMinutes(); // Fluctuate minute by minute
  const flValue = Math.sin(hash + dateSeed) * 450; // Max fluctuation +/- 450 Rupees

  return {
    fluctuation: Math.round(flValue),
    status: (dateSeed % 3 === 0) ? 'syncing' : 'verified',
    rateINR: 83.45 // Mock dollar rate sync checks
  };
}
