/**
 * Formats a numeric price to Indian Rupees (INR) with the standard Indian numbering system.
 * Format output: e.g., ₹79,900, ₹1,19,900
 */
export function formatINR(price: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(price);
}

/**
 * Calculates monthly EMI approximate value for a given product price on a 24-month basis.
 * Formatted as INR.
 */
export function formatEMI(price: number): string {
  const emi = Math.round(price / 24);
  return formatINR(emi);
}
