import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import AuthForm from './AuthForm';
import { 
  Trash2, Plus, Minus, ArrowRight, ArrowLeft, Percent, 
  MapPin, CreditCard, ShieldCheck, HelpCircle, Mail, Phone, MapPinIcon,
  Copy, Check, ExternalLink, Sparkles, Clock, Shield, CheckCircle2, Loader2, QrCode, Wallet, Calendar, Smartphone,
  Instagram, Compass, Target, Eye
} from 'lucide-react';
import { Address } from '../types';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR } from '../utils/currency';
import { motion, AnimatePresence } from 'motion/react';

interface ViewProps {
  setView: (view: string, params?: any) => void;
}

// ====================== 1. CART VIEW ======================

export function CartView({ setView }: ViewProps) {
  const { 
    cart, 
    updateCartQuantity, 
    removeFromCart, 
    coupon, 
    applyCoupon, 
    removeCoupon,
    getCartSummary 
  } = useStore();

  const [couponInput, setCouponInput] = useState('');
  const [couponErr, setCouponErr] = useState('');
  const [couponOk, setCouponOk] = useState(false);

  const { subtotal, discount, tax, shipping, total } = getCartSummary();

  const handleCouponApply = async (e: React.FormEvent) => {
    e.preventDefault();
    setCouponErr('');
    setCouponOk(false);
    if (!couponInput.trim()) return;

    const res = await applyCoupon(couponInput);
    if (res.success) {
      setCouponOk(true);
      setCouponInput('');
    } else {
      setCouponErr(res.error || 'Invalid coupon code');
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto my-16 text-center animate-fade-in px-4 text-apple-dark">
        <h2 className="text-xl font-bold font-sans">Your Cart Bag is Empty</h2>
        <p className="text-xs text-apple-gray mt-1">Add items from our premium titanium iPhone collection to checkout.</p>
        <button onClick={() => setView('collection')} className="apple-btn-primary mt-6 text-xs">Return to Collection</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-apple-dark" id="cart-view-main">
      <h1 className="text-2xl font-extrabold tracking-tight font-sans mb-8">Review your Cart Bag.</h1>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Cart Items List */}
        <div className="lg:col-span-8 space-y-6">
          {cart.map((item, idx) => {
            const price = item.product.price * (1 - item.product.discount / 100);
            return (
              <div 
                key={`${item.productId}-${item.selectedColor}-${item.selectedStorage}`}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-gray-100 pb-6 gap-4"
              >
                <div className="flex items-center gap-4 cursor-pointer flex-1" onClick={() => setView('details', { id: item.productId })}>
                  <img 
                    src={item.product.images[0]} 
                    alt={item.product.name} 
                    className="w-16 h-16 object-contain bg-[#F5F5F7] rounded-xl border border-gray-100"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = getFallbackImage(item.product.name, item.selectedColor);
                    }}
                  />
                  <div>
                    <h3 className="font-semibold text-xs sm:text-sm text-apple-dark hover:text-apple-accent transition-colors">
                      {item.product.name}
                    </h3>
                    <p className="text-[10.5px] text-apple-gray mt-0.5">
                      Finish: <span className="text-apple-dark font-medium">{item.product.colorNames[item.product.colors.indexOf(item.selectedColor)]}</span> | Capacity: <span className="text-apple-dark font-medium">{item.selectedStorage}</span>
                    </p>
                    <p className="text-xs font-semibold text-apple-dark mt-1">
                      {formatINR(price)} each
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-6 justify-between sm:justify-end w-full sm:w-auto shrink-0">
                  
                  {/* Quantity updates counters */}
                  <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden bg-white">
                    <button 
                      onClick={() => updateCartQuantity(item.productId, item.selectedColor, item.selectedStorage, Math.max(1, item.quantity - 1))}
                      className="px-2 py-1.5 hover:bg-gray-50 text-gray-500 hover:text-black cursor-pointer transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-3.5 text-xs font-semibold font-mono">{item.quantity}</span>
                    <button 
                      onClick={() => updateCartQuantity(item.productId, item.selectedColor, item.selectedStorage, item.quantity + 1)}
                      className="px-2 py-1.5 hover:bg-gray-50 text-gray-500 hover:text-black cursor-pointer transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <strong className="text-xs font-bold text-apple-dark font-mono w-20 text-right">
                    {formatINR(price * item.quantity)}
                  </strong>

                  <button 
                    onClick={() => removeFromCart(item.productId, item.selectedColor, item.selectedStorage)}
                    className="text-red-500 hover:text-red-700 p-1 cursor-pointer transition-colors"
                    title="Erase from cart bag"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                </div>
              </div>
            );
          })}
        </div>

        {/* Cart Summary Card */}
        <div className="lg:col-span-4 bg-white border border-gray-100 rounded-3xl p-6 shadow-xs h-fit space-y-6">
          <h4 className="font-bold text-sm text-apple-dark border-b border-gray-50 pb-2">Order Price Summary</h4>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between text-apple-gray">
              <span>Bag Subtotal:</span>
              <span className="font-semibold text-apple-dark font-mono">{formatINR(subtotal)}</span>
            </div>
            
            {discount > 0 && (
              <div className="flex justify-between text-red-600">
                <span className="flex items-center gap-1">
                  <Percent className="w-3.5 h-3.5" />
                  Coupon Savings:
                </span>
                <span className="font-semibold font-mono">-{formatINR(discount)}</span>
              </div>
            )}

            <div className="flex justify-between text-apple-gray">
              <span>Estimated GST (18% Incl.):</span>
              <span className="font-semibold text-apple-dark font-mono">{formatINR(tax)}</span>
            </div>

            <div className="flex justify-between text-[#86868B]">
              <span>Delivery Charges (India):</span>
              <span className="font-semibold text-[#1D1D1F]">{shipping === 0 ? 'FREE' : formatINR(shipping)}</span>
            </div>

            <div className="border-t border-gray-200 pt-3 flex justify-between text-sm font-bold text-apple-dark">
              <span>Total Price:</span>
              <span className="text-apple-accent font-mono font-sans text-base">{formatINR(total)}</span>
            </div>
          </div>

          {/* Dynamic Coupon form */}
          <div className="border-t border-gray-100 pt-4 space-y-3">
            {coupon ? (
              <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-[11px] text-emerald-800">
                <div className="flex items-center gap-1.5 font-sans">
                  <Percent className="w-3.5 h-3.5 shrink-0" />
                  <span>Promo Applied: <b>{coupon.code}</b> ({coupon.discountPercent}% OFF)</span>
                </div>
                <button 
                  onClick={removeCoupon}
                  className="text-red-500 font-bold hover:text-black hover:scale-105"
                  title="Remove coupon"
                >
                  ×
                </button>
              </div>
            ) : (
              <form onSubmit={handleCouponApply} className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Coupon (e.g. APPLE10)" 
                  className="apple-input bg-zinc-50 py-1.5 text-xs flex-1 uppercase"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                />
                <button 
                  type="submit"
                  className="apple-btn-secondary text-[11px] font-semibold py-1.5 px-3 shadow-3xs"
                >
                  Apply Code
                </button>
              </form>
            )}

            {couponErr && <p className="text-[10px] text-red-500 px-1">⚠️ {couponErr}</p>}
            {couponOk && <p className="text-[10px] text-emerald-600 px-1">✓ Promo discount applied successfully!</p>}
          </div>

          <button 
            onClick={() => setView('checkout')}
            className="w-full glowing-cyan-btn py-3 text-xs font-black shadow-md rounded-full flex items-center justify-center gap-1.5 cursor-pointer mt-4"
          >
            Proceed to Secure UPI Checkout
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
}

// ====================== 2. WISHLIST VIEW ======================

export function WishlistView({ setView }: ViewProps) {
  const { wishlist, toggleWishlist, addToCart } = useStore();

  const handleMoveToCart = (p: any) => {
    addToCart(p, 1, p.colors[0], p.storages[0]);
    toggleWishlist(p);
  };

  if (wishlist.length === 0) {
    return (
      <div className="max-w-2xl mx-auto my-16 text-center animate-fade-in px-4 text-apple-dark">
        <h2 className="text-xl font-bold font-sans">Your Wishlist of Favorites is Empty</h2>
        <p className="text-xs text-apple-gray mt-1">Tap the heart icons while browsing products to append them here.</p>
        <button onClick={() => setView('collection')} className="apple-btn-primary mt-6 text-xs">Return to Catalog</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-apple-dark" id="wishlist-v-main">
      <h1 className="text-2xl font-extrabold tracking-tight font-sans mb-8">Your Wishlist Favorites.</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {wishlist.map((p) => {
          const price = p.price * (1 - p.discount / 100);
          return (
            <div 
              key={p.id}
              className="bg-[#F5F5F7]/40 rounded-2xl border border-gray-100 p-4 hover:shadow-xl hover:bg-white transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-center h-40 bg-zinc-50 rounded-xl relative border border-gray-50 p-2">
                  <img 
                    src={p.images[0]} 
                    alt={p.name} 
                    className="h-32 object-contain" 
                    referrerPolicy="no-referrer" 
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = getFallbackImage(p.name, p.colors[0]);
                    }}
                  />
                  <button 
                    onClick={() => toggleWishlist(p)}
                    className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-xs text-red-500 hover:text-black cursor-pointer transition-colors"
                  >
                    ×
                  </button>
                </div>
                <h3 className="font-semibold text-xs sm:text-sm text-apple-dark text-center mt-3 truncate">{p.name}</h3>
                <p className="text-xs font-bold text-center mt-1 text-gray-700">{formatINR(price)}</p>
              </div>

              <div className="mt-4 flex gap-2">
                <button 
                  onClick={() => setView('details', { id: p.id })}
                  className="w-1/2 text-center text-[10.5px] border border-gray-200 py-1.5 rounded-lg hover:border-black transition-colors cursor-pointer"
                >
                  View Details
                </button>
                <button 
                  onClick={() => handleMoveToCart(p)}
                  className="w-1/2 text-center text-[10.5px] bg-apple-accent text-white py-1.5 rounded-lg hover:bg-opacity-90 font-medium cursor-pointer"
                >
                  Move to Cart
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ====================== 3. CHECKOUT VIEW ======================

export function CheckoutView({ setView }: ViewProps) {
  const { user, cart, getCartSummary, placeOrder, addAddress } = useStore();
  const { subtotal, discount, tax, shipping, total } = getCartSummary();

  const [checkoutStep, setCheckoutStep] = useState<'address' | 'payment' | 'processing' | 'success'>('address');
  const [orderOkId, setOrderOkId] = useState<string | null>(null);
  const [checkoutErr, setCheckoutErr] = useState('');
  
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [processingMessage, setProcessingMessage] = useState('Initiating secure PhonePe transaction...');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [estimatedDelivery, setEstimatedDelivery] = useState('');

  // Delivery credentials validation form states
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [houseNumber, setHouseNumber] = useState('');
  const [area, setArea] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('');
  const [pincode, setPincode] = useState('');
  const [isSavingAddr, setIsSavingAddr] = useState(false);
  const [savedAddress, setSavedAddress] = useState<Address | null>(null);

  // Manual payment verification states
  const [utrNumber, setUtrNumber] = useState('');
  const [payInitiated, setPayInitiated] = useState(false);
  const [utrError, setUtrError] = useState('');

  // Sync current address profiles under active authenticated user profile
  useEffect(() => {
    if (user) {
      const defAddr = user.addresses?.find((a: any) => a.isDefault) || user.addresses?.[0];
      if (defAddr) {
        setFullName(defAddr.name || user.name || '');
        setMobileNumber(defAddr.phone || '');
        setHouseNumber(defAddr.line1 || '');
        setArea(defAddr.line2 || '');
        setCity(defAddr.city || '');
        setStateName(defAddr.state || '');
        setPincode(defAddr.postalCode || '');
        setSavedAddress(defAddr);
      } else {
        setFullName(user.name || '');
        setMobileNumber('');
      }
    }
  }, [user]);

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutErr('');

    if (!fullName.trim() || !mobileNumber.trim() || !houseNumber.trim() || !area.trim() || !city.trim() || !stateName.trim() || !pincode.trim()) {
      setCheckoutErr('Please enter all delivery details to save and continue.');
      return;
    }

    setIsSavingAddr(true);
    const newAddr: Omit<Address, 'id'> = {
      name: fullName.trim(),
      phone: mobileNumber.trim(),
      line1: houseNumber.trim(),
      line2: area.trim(),
      city: city.trim(),
      state: stateName.trim(),
      postalCode: pincode.trim(),
      country: 'India',
      isDefault: true
    };

    const success = await addAddress(newAddr);
    setIsSavingAddr(false);

    if (success) {
      setSavedAddress({
        id: 'delivery-latest',
        ...newAddr,
        isDefault: true
      });
      setCheckoutStep('payment');
    } else {
      setCheckoutErr('Failed to register delivery details to MongoDB. Please try again.');
    }
  };

  const handlePayNow = () => {
    setCheckoutErr('');
    setUtrError('');
    
    // Attempt deep link trigger for mobile and tablet processors
    const upiDeepLink = `upi://pay?pa=kalidhas487@oksbi&pn=Kali%20Dhas%2520Store&am=${total}&cu=INR`;
    try {
      window.location.href = upiDeepLink;
    } catch (e) {
      console.log("Deep link triggered.");
    }
    
    setPayInitiated(true);
  };

  const handleSubmitUtr = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutErr('');
    setUtrError('');

    // UPI Ref Number (UTR) validation: must be 12-digit numeric
    const cleanUtr = utrNumber.replace(/\s+/g, '');
    if (!/^\d{12}$/.test(cleanUtr)) {
      setUtrError('Indian UPI UTR verification codes are exactly 12 numeric digits.');
      return;
    }

    setCheckoutStep('processing');
    setProcessingMessage('Checking transaction ledger references...');

    const messages = [
      'Establishing secure UPI connection...',
      'Validating 12-digit UTR ledger format with PhonePe hosts...',
      'Compiling custom multi-layer verification profiles...',
      'Saving delivery logs under Kali Dhas Store administration...',
      'Deducting warehouse stock counts across active indices...'
    ];

    let currentMsgIdx = 0;
    const interval = setInterval(() => {
      if (currentMsgIdx < messages.length - 1) {
        currentMsgIdx++;
        setProcessingMessage(messages[currentMsgIdx]);
      }
    }, 450);

    const checkAddress: Address = savedAddress || {
      id: 'delivery-temp',
      name: fullName || user?.name || 'Customer Address',
      phone: mobileNumber || '',
      line1: houseNumber || '123 Store Street',
      line2: area || 'Retail Avenue',
      city: city || 'New Delhi',
      state: stateName || 'Delhi',
      postalCode: pincode || '110001',
      country: 'India',
      isDefault: true
    };

    try {
      // Pass UTR code within the paymentMethod name so administrators can instantly see and cross-verify it!
      const res = await placeOrder(checkAddress, `PhonePe UPI (UTR: ${cleanUtr})`);
      
      setTimeout(() => {
        clearInterval(interval);
        if (res.success && res.orderId) {
          // Generate automated tracking number
          const randomDigits = Math.floor(1000000000 + Math.random() * 9000000000);
          setTrackingNumber(`APL-${randomDigits}-IN`);
          
          // Generate estimated delivery date
          const etaDate = new Date();
          etaDate.setDate(etaDate.getDate() + 3);
          const formattedEta = etaDate.toLocaleDateString('en-IN', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          });
          setEstimatedDelivery(formattedEta);
          
          setOrderOkId(res.orderId);
          setCheckoutStep('success');
        } else {
          setCheckoutErr(res.error || 'Failed to submit order for verification. Please try again.');
          setCheckoutStep('payment');
        }
      }, 2500);
    } catch (err: any) {
      clearInterval(interval);
      setCheckoutErr(err.message || 'Verification connection timeout.');
      setCheckoutStep('payment');
    }
  };

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 animate-fade-in text-[#1d1d1f]">
        <div className="text-center max-w-md mx-auto space-y-5">
          <div className="w-12 h-12 rounded-full bg-blue-600/10 text-blue-600 flex items-center justify-center mx-auto">
            <Shield className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight font-sans">Secure Checkout Access</h2>
          <p className="text-xs text-gray-500 max-w-sm mx-auto">
            Please sign in with your account credentials or register a profile below to continue with checkout safety.
          </p>
          <div className="bg-white border border-gray-150 p-6 rounded-[30px] shadow-3xs text-left">
            <AuthForm mode="login" setView={setView} />
          </div>
        </div>
      </div>
    );
  }

  if (checkoutStep === 'processing') {
    return (
      <div className="max-w-md mx-auto my-20 p-8 bg-white border border-gray-250 rounded-[30px] shadow-2xl flex flex-col items-center justify-center text-center space-y-6 animate-fade-in" id="payment-processing-screen">
        <div className="relative w-14 h-14 flex items-center justify-center">
          <div className="absolute inset-0 border-4 border-slate-100 rounded-full" />
          <div className="absolute inset-0 border-4 border-purple-600 border-t-transparent rounded-full animate-spin" />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-base font-extrabold text-[#1d1d1f] tracking-tight font-sans">
            Confirming Payment
          </h3>
          <p className="text-xs text-slate-500 font-medium font-mono h-8 animate-pulse">
            {processingMessage}
          </p>
        </div>

        <div className="w-full bg-[#FAF9F6] p-3 rounded-xl border border-neutral-100 text-[10px] text-zinc-450 font-bold">
          🔒 Encrypted PhonePe secure tunnel. Please keep this session open.
        </div>
      </div>
    );
  }

  if (checkoutStep === 'success') {
    return (
      <div className="max-w-xl mx-auto my-16 p-8 sm:p-10 bg-white border border-gray-150 rounded-[30px] shadow-2xl animate-fade-in text-[#1d1d1f]" id="order-success-screen">
        <div className="text-center space-y-4">
          <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 bg-emerald-100 rounded-full animate-ping scale-95 opacity-35" />
            <div className="w-14 h-14 bg-emerald-500 rounded-full flex items-center justify-center text-white relative z-10 shadow-xs">
              <Check className="w-7 h-7 stroke-[3]" />
            </div>
          </div>

          <div className="space-y-1">
            <span className="bg-amber-50 text-amber-800 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-amber-100 inline-block font-sans animate-pulse">
              Verification Pending
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-[#1d1d1f] tracking-tight font-sans">
              Order Logged Successfully
            </h2>
            <p className="text-xs text-gray-500 max-w-sm mx-auto leading-relaxed font-semibold">
              Thank you for choosing Kali Dhas Store. Your order is registered. Once our team verifies your 12-digit UTR transfer code in our PhonePe merchant ledger, shipping dispatch will immediately boot!
            </p>
          </div>
        </div>

        <div className="mt-8 bg-[#FAF9F6] border border-gray-150 rounded-[24px] p-5 sm:p-6 space-y-4 text-xs text-left text-[#1d1d1f]">
          {utrNumber && (
            <div className="flex items-center justify-between border-b border-gray-200/60 pb-3 text-left">
              <div>
                <span className="text-[10px] font-bold text-gray-400 block tracking-wider uppercase">Submitted UTR Code</span>
                <span className="text-xs font-mono font-black text-amber-700">{utrNumber}</span>
              </div>
              <span className="text-[8px] font-black uppercase tracking-wider text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-100">
                PENDING LEDGER
              </span>
            </div>
          )}
          <div className="flex items-center justify-between border-b border-gray-200/60 pb-3 text-left">
            <div>
              <span className="text-[10px] font-bold text-gray-400 block tracking-wider uppercase">Order ID</span>
              <span className="text-xs font-mono font-black text-[#1d1d1f]">{orderOkId}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                if (orderOkId) {
                  navigator.clipboard.writeText(orderOkId);
                  setCopiedText("orderId");
                  setTimeout(() => setCopiedText(null), 1500);
                }
              }}
              className="text-[10px] text-blue-600 font-extrabold flex items-center gap-1 hover:underline cursor-pointer"
            >
              {copiedText === 'orderId' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-650" /> Copied
                </>
              ) : (
                'Copy ID'
              )}
            </button>
          </div>

          <div className="flex items-center justify-between border-b border-gray-200/60 pb-3 text-left">
            <div>
              <span className="text-[10px] font-bold text-gray-400 block tracking-wider uppercase">Tracking Number</span>
              <span className="text-xs font-mono font-black text-purple-650">{trackingNumber}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(trackingNumber);
                setCopiedText("tracking");
                setTimeout(() => setCopiedText(null), 1500);
              }}
              className="text-[10px] text-blue-600 font-extrabold flex items-center gap-1 hover:underline cursor-pointer"
            >
              {copiedText === 'tracking' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-green-655" /> Copied
                </>
              ) : (
                'Copy Code'
              )}
            </button>
          </div>

          <div className="flex items-center justify-between pt-1 text-left">
            <div>
              <span className="text-[10px] font-bold text-gray-400 block tracking-wider uppercase">Estimated Delivery Date</span>
              <span className="text-xs font-extrabold text-[#1d1d1f] flex items-center gap-1.5 mt-0.5">
                <Calendar className="w-3.5 h-3.5 text-blue-500" />
                {estimatedDelivery}
              </span>
            </div>
            <span className="text-[9.5px] font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100 font-sans">
              EXPRESS DISPATCH
            </span>
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => setView('account')}
            className="flex-1 py-3.5 bg-black hover:bg-neutral-800 text-white rounded-xl text-xs font-black tracking-wide cursor-pointer transition-colors active:scale-95 shadow-sm text-center font-sans uppercase"
          >
            Track Order
          </button>

          <button
            onClick={() => setView('home')}
            className="flex-1 py-3.5 bg-white hover:bg-[#FAF9F6] border border-gray-200 text-[#1d1d1f] rounded-xl text-xs font-black tracking-wide cursor-pointer transition-colors active:scale-95 text-center font-sans uppercase"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in text-[#1d1d1f]" id="checkout-view-main">
      <div className="text-left mb-8">
        <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 font-mono">
          STATION ID: PHONEPE-PAY-DESK
        </span>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#1d1d1f] mt-1 font-sans">
          Express checkout.
        </h1>
        <p className="text-xs text-slate-505 mt-1 font-semibold">
          Secure multi-layer verification platform configured for Kali Dhas Store transactions.
        </p>
      </div>

      {checkoutErr && (
        <div className="p-3 bg-red-50 text-red-700 text-xs rounded-xl mb-6 border border-red-100 max-w-4xl font-semibold">
          ⚠️ <b>Operational Lockout:</b> {checkoutErr}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Column: Form Sections based on active Step */}
        <div className="lg:col-span-7">
          <AnimatePresence mode="wait">
            {checkoutStep === 'address' ? (
              <motion.div
                key="address-step"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.25 }}
                className="bg-white border border-gray-150 p-6 sm:p-8 rounded-[30px] shadow-3xs space-y-6 text-left animate-fade-in"
              >
                <div className="border-b border-gray-100 pb-4 text-left">
                  <span className="text-[10px] font-black tracking-widest text-[#8B5CF6] uppercase block font-sans">
                    STEP 1 OUT OF 2
                  </span>
                  <h3 className="text-lg font-black tracking-tight text-[#1d1d1f] mt-1 font-sans">
                    Delivery Information
                  </h3>
                  <p className="text-[11px] text-gray-400 font-semibold mt-0.5 font-sans">
                    Please provide exact residential or business shipping credentials under security procedures.
                  </p>
                </div>

                <form onSubmit={handleSaveAddress} className="space-y-4 text-left">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        Full Name
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Kali Dhas"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none animate-fade-in"
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        Mobile Number
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. 9876543210"
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        House Number / Street
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Flat 3A, Block-G"
                        value={houseNumber}
                        onChange={(e) => setHouseNumber(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        Area / Locality
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Connaught Place"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        City
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. New Delhi"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        State
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Delhi"
                        value={stateName}
                        onChange={(e) => setStateName(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>

                    <div className="space-y-1.5 text-left">
                      <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                        Pincode
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 110001"
                        value={pincode}
                        onChange={(e) => setPincode(e.target.value)}
                        className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-semibold w-full focus:bg-white focus:border-blue-500 transition-all outline-none"
                      />
                    </div>
                  </div>

                  <div className="pt-4 text-left">
                    <button
                      type="submit"
                      disabled={isSavingAddr}
                      className="w-full py-3.5 bg-black hover:bg-neutral-800 disabled:opacity-50 text-white rounded-xl text-xs font-black tracking-wider uppercase cursor-pointer transition-all duration-200 shadow-sm flex items-center justify-center gap-2 font-sans"
                    >
                      {isSavingAddr ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Saving Credentials...
                        </>
                      ) : (
                        'Save Address'
                      )}
                    </button>
                  </div>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="payment-step"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.25 }}
                className="space-y-6 text-left"
              >
                {/* Saved Address Summary */}
                <div className="bg-white border border-gray-150 p-5 rounded-[24px] shadow-3xs flex items-center justify-between text-left animate-fade-in">
                  <div>
                    <span className="text-[9px] font-black uppercase text-gray-400 block tracking-widest font-sans">
                      SHIPPING REGISTERED TO
                    </span>
                    <h4 className="font-extrabold text-xs text-[#1d1d1f] mt-0.5 font-sans">
                      {fullName} &bull; {mobileNumber}
                    </h4>
                    <p className="text-[10.5px] text-gray-500 mt-0.5 font-semibold font-sans">
                      {houseNumber}, {area}, {city}, {stateName} - {pincode}
                    </p>
                  </div>
                  <button
                    onClick={() => setCheckoutStep('address')}
                    className="p-2 text-xs font-extrabold text-[#8B5CF6] hover:underline cursor-pointer font-sans"
                  >
                    Edit
                  </button>
                </div>

                {/* Forced PhonePe gateway selector card */}
                <div className="bg-white border border-gray-150 p-6 sm:p-8 rounded-[30px] shadow-3xs space-y-6 text-left">
                  <div className="border-b border-gray-100 pb-4">
                    <span className="text-[10px] font-black tracking-widest text-[#8B5CF6] uppercase block font-sans">
                      STEP 2 OUT OF 2
                    </span>
                    <h3 className="text-lg font-black tracking-tight text-[#1d1d1f] mt-1 font-sans">
                      Payment Method &amp; Authorization
                    </h3>
                    <p className="text-[11px] text-gray-400 font-semibold mt-0.5 font-sans font-medium">
                      All products are routed with PhonePe security credentials. Alternate credit tunnels are disabled.
                    </p>
                  </div>

                  {!payInitiated ? (
                    <div className="space-y-6">
                      <div className="p-6 border-2 border-purple-600 bg-purple-50/10 rounded-[20px] shadow-3xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 select-none relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-1.5 bg-purple-600 text-white font-extrabold text-[8px] uppercase tracking-widest rounded-bl-xl font-sans text-right">
                          ACTIVE METHOD
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-purple-100 rounded-xl shrink-0 border border-purple-200 shadow-3xs">
                            <Smartphone className="w-6 h-6 text-purple-750 animate-pulse" />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 text-left">
                              <span className="font-black text-sm text-[#1d1d1f] font-sans">
                                PhonePe UPI Only
                              </span>
                            </div>
                            <p className="text-[10px] text-zinc-550 font-semibold leading-normal mt-0.5 font-sans text-left">
                              Instant Indian gateway clearance. Touchless settlement protocol.
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-1.5 shrink-0">
                          <div className="w-5 h-5 rounded-full border border-purple-600 bg-purple-600 flex items-center justify-center">
                            <span className="w-1.5 h-1.5 bg-white rounded-full animate-scale-up" />
                          </div>
                          <span className="text-[10px] font-bold text-purple-700 uppercase font-sans">Secured</span>
                        </div>
                      </div>

                      {/* Prominent Merchant UPI details banner */}
                      <div className="bg-slate-50 border border-slate-150/70 p-4 rounded-xl flex items-center justify-between text-left font-sans">
                        <div>
                          <span className="text-[9.5px] uppercase font-bold text-slate-400 block font-mono">Merchant UPI ID</span>
                          <code className="text-xs font-mono font-black text-purple-705 mt-1 block">
                            kalidhas487@oksbi
                          </code>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText("kalidhas487@oksbi");
                            setCopiedText("kalidhas487@oksbi");
                            setTimeout(() => setCopiedText(null), 1500);
                          }}
                          className="text-[10px] uppercase font-black font-sans text-blue-600 hover:text-blue-700 flex items-center gap-1 shrink-0 p-2 border border-blue-100 bg-white rounded-lg shadow-3xs cursor-pointer animate-fade-in"
                        >
                          {copiedText === 'kalidhas487@oksbi' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-green-655 animate-scale-up" /> Copied
                            </>
                          ) : (
                            'Copy ID'
                          )}
                        </button>
                      </div>

                      {/* Pay with PhonePe core button */}
                      <div className="pt-2 text-left">
                        <motion.button
                          type="button"
                          onClick={handlePayNow}
                          whileHover={{ scale: 1.015 }}
                          whileTap={{ scale: 0.985 }}
                          animate={{
                            boxShadow: ["0px 0px 0px rgba(103, 57, 183, 0)", "0px 0px 14px rgba(103, 57, 183, 0.25)", "0px 0px 0px rgba(103, 57, 183, 0)"]
                          }}
                          transition={{
                            repeat: Infinity,
                            duration: 2.2
                          }}
                          className="w-full py-4 bg-[#5f259f] hover:bg-[#4d1e82] text-white rounded-2xl text-[#fff] text-xs sm:text-sm font-black tracking-widest uppercase flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-lg shadow-purple-500/10 font-sans"
                          id="checkout-pay-now-btn"
                        >
                          Pay with PhonePe
                          <Sparkles className="w-4 h-4 fill-white animate-pulse" />
                        </motion.button>
                        
                        <div className="flex items-center justify-center gap-1.5 text-[10px] text-neutral-400 mt-4 font-bold select-none leading-none">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                          Double encrypted terminal certified under active security profiles.
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6 animate-fade-in">
                      {/* Active verification instructions header */}
                      <div className="bg-amber-50/45 border border-amber-100 p-4 rounded-xl text-left space-y-1">
                        <span className="text-[10px] font-black uppercase text-amber-705 tracking-wider block font-sans">
                          ⚠️ UPI Verification Mode Active
                        </span>
                        <p className="text-[11px] text-slate-600 font-semibold leading-relaxed">
                          Please complete your transfer of <b className="text-zinc-900">{formatINR(total)}</b> using our QR code scanner or the copy credentials helper below, then enter your 12-digit UTR confirmation code inside the security grid.
                        </p>
                      </div>

                      {/* Flex layout for Scan QR & Details */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                        <div className="md:col-span-5 flex flex-col items-center justify-center border border-gray-150 p-4 rounded-2xl bg-[#fafafa]">
                          <img 
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`upi://pay?pa=kalidhas487@oksbi&pn=Kali%20Dhas%2520Store&am=${total}&cu=INR`)}`}
                            alt="PhonePe UPI QR Code"
                            referrerPolicy="no-referrer"
                            className="w-32 h-32 object-contain aspect-square mix-blend-multiply"
                          />
                          <span className="text-[9px] font-bold text-gray-400 mt-2 uppercase tracking-widest">
                            Scan to pay
                          </span>
                        </div>

                        <div className="md:col-span-7 space-y-3">
                          <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg flex items-center justify-between text-left font-sans">
                            <div>
                              <span className="text-[9px] uppercase font-bold text-slate-400 block font-mono">Recipient ID</span>
                              <code className="text-xs font-mono font-black text-[#1d1d1f] block mt-0.5 select-all">
                                kalidhas487@oksbi
                              </code>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText("kalidhas487@oksbi");
                                setCopiedText("kalidhas487@oksbi");
                                setTimeout(() => setCopiedText(null), 1500);
                              }}
                              className="text-[9.5px] uppercase font-black text-blue-600 hover:underline cursor-pointer"
                            >
                              {copiedText === 'kalidhas487@oksbi' ? 'Copied' : 'Copy'}
                            </button>
                          </div>

                          <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg flex items-center justify-between text-left font-sans">
                            <div>
                              <span className="text-[9px] uppercase font-bold text-slate-400 block font-mono">Total amount</span>
                              <span className="text-xs font-mono font-black text-purple-700 block mt-0.5">
                                {formatINR(total)}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(total.toString());
                                setCopiedText("amount");
                                setTimeout(() => setCopiedText(null), 1500);
                              }}
                              className="text-[9.5px] uppercase font-black text-blue-600 hover:underline cursor-pointer"
                            >
                              {copiedText === 'amount' ? 'Copied' : 'Copy'}
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Manual input form block */}
                      <form onSubmit={handleSubmitUtr} className="space-y-4 pt-1">
                        <div className="space-y-1.5 text-left">
                          <label className="text-[10.5px] font-extrabold uppercase tracking-wider text-neutral-500 block pl-0.5 font-sans">
                            12-Digit UPI Ref No / UTR Number
                          </label>
                          <input
                            type="text"
                            required
                            maxLength={12}
                            placeholder="e.g. 612345678901"
                            value={utrNumber}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, ''); // strip non-numeric
                              setUtrNumber(val);
                            }}
                            className="apple-input bg-slate-50 border border-gray-155 rounded-xl py-3 px-4 text-xs font-mono font-bold tracking-widest w-full focus:bg-white focus:border-[#5f259f] transition-all outline-none"
                          />
                          {utrError && (
                            <span className="text-[10px] font-black text-red-500 block mt-1">
                              ❌ {utrError}
                            </span>
                          )}
                          <p className="text-[9.5px] text-gray-450 leading-relaxed font-semibold pl-0.5">
                            You'll find your 12-digit transaction ID (UTR/Ref number) on your transfer receipt screen in PhonePe, GPay, or Paytm under Transaction History.
                          </p>
                        </div>

                        <div className="pt-2 flex flex-col sm:flex-row gap-2">
                          <button
                            type="submit"
                            className="flex-1 py-3.5 bg-[#5f259f] hover:bg-[#4d1e82] text-white rounded-xl text-xs font-black tracking-widest uppercase cursor-pointer transition-colors flex items-center justify-center gap-1.5 font-sans shadow-md"
                          >
                            Verify &amp; Submit Order
                            <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setPayInitiated(false);
                              setUtrNumber('');
                              setUtrError('');
                            }}
                            className="py-3.5 px-4 border border-gray-200 hover:bg-neutral-50 text-[#1d1d1f] rounded-xl text-xs font-bold font-sans cursor-pointer transition-all duration-150"
                          >
                            Go Back
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: PRODUCT SUMMARY CARD */}
        <div className="lg:col-span-5">
          <div className="bg-white border border-gray-150 rounded-[30px] p-6 sm:p-8 shadow-3xs space-y-5 text-left">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-400 font-sans text-left">Order Items</h3>
              <span className="text-[10px] uppercase font-black text-purple-750 bg-purple-50/55 border border-purple-100 px-2.5 py-0.5 rounded-full font-mono">
                {cart.reduce((sum, item) => sum + item.quantity, 0)} Items
              </span>
            </div>

            <div className="divide-y divide-gray-100 max-h-[300px] overflow-y-auto pr-2 scrollbar-none text-left font-sans">
              {cart.map((item, idx) => {
                const price = item.product.price * (1 - item.product.discount / 100);
                return (
                  <div key={idx} className="flex gap-4 py-3.5 first:pt-0 last:pb-0 text-left">
                    <div className="w-14 h-14 rounded-2xl bg-[#FAF9F6] border border-gray-100 flex items-center justify-center shrink-0">
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-10 h-10 object-contain" 
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = getFallbackImage(item.product.name, item.selectedColor);
                        }}
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0 text-left">
                      <h4 className="font-extrabold text-xs text-[#1d1d1f] truncate leading-tight font-sans">
                        {item.product.name}
                      </h4>
                      <p className="text-[10.5px] text-gray-400 mt-1 font-semibold block">
                        Finish: {item.product.colorNames[item.product.colors.indexOf(item.selectedColor)] || 'Titanium'} | {item.selectedStorage}
                      </p>
                      
                      <div className="flex items-center gap-2 mt-1.5 text-left">
                        <span className="text-[9px] text-[#2d2d2f] font-black bg-slate-100 border border-slate-200/60 px-2 py-0.5 rounded-md font-sans">
                          Quantity: {item.quantity}
                        </span>
                        {item.quantity > 1 && (
                          <span className="text-[9.5px] text-gray-400 font-semibold font-mono">
                            {formatINR(price)} each
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right shrink-0 font-mono">
                      <span className="text-xs font-black text-[#1d1d1f] block font-mono">
                        {formatINR(price * item.quantity)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Price Calculations */}
            <div className="border-t border-gray-100 pt-4 space-y-2.5 text-xs text-left">
              <div className="flex justify-between text-gray-500">
                <span>Subtotal:</span>
                <span className="font-semibold text-[#1d1d1f] font-mono">{formatINR(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-red-500 font-semibold col-red-500 hover:text-red-600 duration-150 transition-all font-sans">
                  <span>Coupon discount:</span>
                  <span className="font-mono">-{formatINR(discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-500">
                <span>Estimated GST (18% Incl.):</span>
                <span className="font-semibold text-[#1d1d1f] font-mono">{formatINR(tax)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Shipping &amp; Delivery:</span>
                <span className="font-semibold text-emerald-600 font-mono tracking-wide font-sans">FREE</span>
              </div>
              
              <div className="border-t border-dashed border-neutral-200 pt-3 flex justify-between items-baseline font-sans">
                <span className="text-sm font-black text-[#1d1d1f]">Total Amount:</span>
                <span className="text-lg font-black text-[#8B5CF6] font-mono">{formatINR(total)}</span>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}

// ====================== 4. INFORMATION PAGES ======================

interface InfoProps extends ViewProps {
  section: 'about' | 'contact' | 'privacy' | 'terms';
}

export function InfoPagesView({ section, setView }: InfoProps) {
  // Contact Form logs
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactOk, setContactOk] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactName('');
    setContactEmail('');
    setContactMessage('');
    setContactOk(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 animate-fade-in text-apple-dark font-sans leading-relaxed text-xs sm:text-sm" id={`info-layout-${section}`}>
      
      {/* 4a. ABOUT KALI DHAS STORE */}
      {section === 'about' && (
        <div className="space-y-12 animate-fade-in text-zinc-900 dark:text-zinc-100 font-sans">
          
          {/* Header Banner & Glass Profile */}
          <div className="relative text-center bg-gradient-to-br from-[#8B5CF6]/10 via-purple-500/5 to-transparent rounded-[32px] p-8 md:p-14 border border-neutral-200/40 dark:border-zinc-800/30 overflow-hidden">
            <div className="absolute inset-0 bg-white/20 dark:bg-black/20 backdrop-blur-[2px] pointer-events-none" />
            
            <div className="relative flex flex-col items-center">
              {/* Profile Photo */}
              <div className="relative mb-6">
                <div className="absolute inset-0 bg-gradient-to-tr from-[#8B5CF6] to-purple-655 rounded-full blur-md opacity-30 transform scale-105 animate-pulse" />
                <img
                  src="/src/assets/images/founder_kali_dhas_1781867572501.jpg"
                  alt="Kali Dhas - Founder"
                  onError={(e) => {
                    // Fail-safe default avatar if loading fails
                    e.currentTarget.src = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400";
                  }}
                  className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover object-top border-4 border-white dark:border-zinc-900 shadow-2xl transition-transform hover:scale-105 duration-500"
                />
                <span className="absolute bottom-2 right-2 bg-[#8B5CF6] text-white p-1.5 rounded-full shadow-lg">
                  <Sparkles className="w-4 h-4" />
                </span>
              </div>

              {/* Founder Information */}
              <span className="text-[10px] sm:text-xs font-black uppercase tracking-widest text-[#8B5CF6] bg-[#8B5CF6]/10 dark:bg-[#8B5CF6]/20 px-4 py-1.5 rounded-full mb-3 inline-block">
                FOUNDER & CEO
              </span>
              <h1 className="text-3xl sm:text-5xl font-black text-zinc-900 dark:text-white tracking-tight leading-none mb-4">
                About Kali Dhas Store
              </h1>
              <p className="text-zinc-500 dark:text-zinc-400 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-medium">
                "We don't just supply devices; we curate a portal of acoustic and computing perfection. Every titanium build, precise color finish, and active screen refresh should be experienced as a luxurious rite of passage."
              </p>
            </div>
          </div>

          {/* Short Story */}
          <div className="max-w-3xl mx-auto space-y-4 text-left border-t border-zinc-100 dark:border-zinc-800/80 pt-8">
            <h3 className="text-xl font-bold tracking-tight text-zinc-900 dark:text-white flex items-center gap-2">
              <Compass className="w-5 h-5 text-[#8B5CF6]" /> The Curated Heritage
            </h3>
            <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed">
              Founded in India by technologist and premium design enthusiast <b>Kali Dhas</b>, our store represents a relentless pursuit of hardware perfection. Kali realized early on that premium devices suffer from complex purchasing loops, unverified distribution networks, and a lack of visual appreciation during unboxing. 
            </p>
            <p className="text-zinc-500 dark:text-zinc-400 text-sm leading-relaxed">
              We eliminated the noise to offer Indian tech lovers an ultra-simplified storefront featuring 100% genuine consumer electronics. Backed by direct brand validations, expedited coastal shipping pathways, and real product unboxing transparency, we deliver high-end technology to your doorstep in pristine condition.
            </p>
          </div>

          {/* Mission, Vision & Support Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            
            {/* Mission */}
            <div className="bg-white/50 dark:bg-zinc-900/30 backdrop-blur-md border border-neutral-250/30 dark:border-zinc-800/30 p-6 rounded-3xl flex flex-col justify-between hover:shadow-lg hover:border-zinc-300 dark:hover:border-zinc-700 transition-all duration-300 group">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-sky-50 dark:bg-sky-950/45 text-sky-600 flex items-center justify-center mb-4">
                  <Target className="w-5 h-5" />
                </div>
                <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white mb-2 uppercase tracking-wide">Our Mission</h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed font-semibold">
                  To connect consumers with verified premium hardware, offering a seamless purchasing loop, extreme pricing clarity, and complete logistical security.
                </p>
              </div>
            </div>

            {/* Vision */}
            <div className="bg-white/50 dark:bg-zinc-900/30 backdrop-blur-md border border-neutral-250/30 dark:border-zinc-800/30 p-6 rounded-3xl flex flex-col justify-between hover:shadow-lg hover:border-zinc-300 dark:hover:border-zinc-700 transition-all duration-300 group">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-950/45 text-purple-600 flex items-center justify-center mb-4">
                  <Eye className="w-5 h-5" />
                </div>
                <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white mb-2 uppercase tracking-wide">Our Vision</h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed font-semibold">
                  To establish India's premier high-end smartphone boutique, praised for original seals, direct logistics, and responsive digital interfaces.
                </p>
              </div>
            </div>

            {/* Support */}
            <div className="bg-white/50 dark:bg-zinc-900/30 backdrop-blur-md border border-neutral-250/30 dark:border-zinc-800/30 p-6 rounded-3xl flex flex-col justify-between hover:shadow-lg hover:border-zinc-300 dark:hover:border-zinc-700 transition-all duration-300 group">
              <div>
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/45 text-emerald-600 flex items-center justify-center mb-4">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h4 className="font-extrabold text-sm text-zinc-900 dark:text-white mb-2 uppercase tracking-wide">Genuine Support</h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed font-semibold">
                  Active, customized post-purchase assistance matching global technical benchmarks to guarantee complete hardware peace of mind.
                </p>
              </div>
            </div>

          </div>

          {/* Indian Customer Trust Milestones */}
          <div className="bg-[#F5F5F7] dark:bg-zinc-900 rounded-[28px] p-8 max-w-5xl mx-auto text-center border border-zinc-150 dark:border-zinc-800/50">
            <h4 className="text-xs font-black uppercase tracking-widest text-[#8B5CF6] mb-6 block">
              Trusted by customers across India
            </h4>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-1">
                <span className="text-3xl sm:text-4xl font-black block text-zinc-900 dark:text-white font-mono">50k+</span>
                <span className="text-[10px] text-zinc-450 uppercase font-black tracking-wider block">Inspected Shipments</span>
              </div>
              <div className="space-y-1">
                <span className="text-3xl sm:text-4xl font-black block text-[#8B5CF6] font-mono">100%</span>
                <span className="text-[10px] text-zinc-450 uppercase font-black tracking-wider block">Sealed Authenticity</span>
              </div>
              <div className="space-y-1">
                <span className="text-3xl sm:text-4xl font-black block text-emerald-600 font-mono">4.9★</span>
                <span className="text-[10px] text-zinc-450 uppercase font-black tracking-wider block">Verified Ratings</span>
              </div>
              <div className="space-y-1">
                <span className="text-3xl sm:text-4xl font-black block text-zinc-900 dark:text-white font-mono">24 Hour</span>
                <span className="text-[10px] text-zinc-450 uppercase font-black tracking-wider block">Express Dispatches</span>
              </div>
            </div>
          </div>

          {/* Socials Connection */}
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-r from-pink-500/5 to-indigo-500/5 rounded-3xl border border-pink-500/10 dark:border-indigo-500/10 max-w-xl mx-auto gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-tr from-yellow-500 via-pink-500 to-purple-600 rounded-full text-white shadow-md">
                <Instagram className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="text-xs font-extrabold text-[#8B5CF6] block font-sans uppercase tracking-wider">Follow the founder</span>
                <a 
                  href="https://instagram.com/_no__fear__boy______" 
                  target="_blank" 
                  rel="noreferrer" 
                  className="text-sm font-black hover:underline text-zinc-800 dark:text-white block"
                >
                  @_no__fear__boy______
                </a>
              </div>
            </div>
            <a
              href="https://instagram.com/_no__fear__boy______" 
              target="_blank" 
              rel="noreferrer"
              className="px-5 py-2.5 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white rounded-full text-xs font-black shadow-md transition-all active:scale-95 inline-flex items-center gap-2"
            >
              Connect on Instagram <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Contact Us Section at the Bottom */}
          <div className="border-t border-zinc-200 dark:border-zinc-800 pt-10" id="about-page-contact-desk">
            <h3 className="text-xl font-black tracking-tight text-zinc-900 dark:text-white text-center mb-6">
              Contact our Premium Desk
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto text-left">
              
              <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800 flex items-start gap-3.5 hover:shadow-sm">
                <Phone className="w-5 h-5 text-[#8B5CF6] shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-xs text-zinc-400 uppercase tracking-widest">Call Premium Lines</h5>
                  <span className="text-sm font-extrabold text-zinc-850 dark:text-zinc-100 block mt-1">+91 63790 28154</span>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1">Available daily 9:00 AM - 10:00 PM IST</p>
                </div>
              </div>

              <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200/50 dark:border-zinc-800 flex items-start gap-3.5 hover:shadow-sm">
                <Mail className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-bold text-xs text-zinc-400 uppercase tracking-widest">Authorized Email Support</h5>
                  <span className="text-sm font-extrabold text-zinc-850 dark:text-zinc-100 block mt-1">kalidhas487@gmail.com</span>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1">Written tickets verified within 1 hour</p>
                </div>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* 4b. CONTACT CUSTOMER DESK */}
      {section === 'contact' && (
        <div className="space-y-8">
          <h1 className="text-3xl font-extrabold tracking-tight font-sans">Contact Customer Care.</h1>
          <p className="text-gray-500 text-sm leading-relaxed">
            Have questions regarding device specs, orders, block lockout policies, or licensing details? Write to us below, or call regional care centers.
          </p>

          {contactOk && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-2xl flex items-center gap-1.5">
              ✓ Thank you! Your help request has been compiled. Our support staff will response within 24 hours.
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            
            {/* Contact form */}
            <form onSubmit={handleContactSubmit} className="bg-white border border-gray-100 p-6 shadow-xl rounded-3xl space-y-4">
              <h4 className="font-bold text-xs text-apple-dark uppercase tracking-wider border-b pb-2">Support Ticket Form</h4>
              <input 
                type="text" 
                placeholder="Name" 
                className="apple-input w-full"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                required
              />
              <input 
                type="email" 
                placeholder="Email Address" 
                className="apple-input w-full"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                required
              />
              <textarea 
                placeholder="Message (e.g. Inquiring about shipping rates...)" 
                className="apple-input w-full h-24 text-xs"
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                required
              />
              <button type="submit" className="apple-btn-primary py-2 text-xs w-full shadow-sm">Submit help ticket</button>
            </form>

            {/* Quick cards */}
            <div className="space-y-4 bg-zinc-50 border border-zinc-100 p-6 rounded-3xl text-xs text-gray-500 space-y-4">
              <div className="flex gap-2.5 items-start">
                <Mail className="w-4 h-4 text-apple-accent shrink-0 mt-0.5" />
                <div>
                  <strong className="text-apple-dark block">Email Support Desk</strong>
                  <span>support@istorepremium.com</span><br />
                  <span>sales@istorepremium.com</span>
                </div>
              </div>

              <div className="flex gap-2.5 items-start">
                <Phone className="w-4 h-4 text-apple-accent shrink-0 mt-0.5" />
                <div>
                  <strong className="text-apple-dark block">Phone Tech Lines</strong>
                  <span>+1 (800) MY-APPLE (Main Office)</span><br />
                  <span>+1 (408) 555-0199 (Support Center)</span>
                </div>
              </div>

              <div className="flex gap-2.5 items-start">
                <MapPinIcon className="w-4 h-4 text-apple-accent shrink-0 mt-0.5" />
                <div>
                  <strong className="text-apple-dark block">Corporate HQ Address</strong>
                  <span>iStore Premium Solutions Inc.</span><br />
                  <span>Infinite Loop, Cupertino, California</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 4c. PRIVACY POLICY */}
      {section === 'privacy' && (
        <div className="space-y-6 text-gray-500 font-sans leading-relaxed">
          <h1 className="text-3xl font-extrabold tracking-tight font-sans text-apple-dark">Privacy Disclosures.</h1>
          <p className="text-xs text-gray-400">Published: June 17, 2026. Global privacy and security regulations.</p>
          
          <h3 className="font-bold text-sm text-apple-dark mt-6 uppercase tracking-wide">1. Information Gathering</h3>
          <p>
            Secure user credentials, checkout orders, and shipment selections are indexed safely inside dedicated, fully encrypted databases. Technical teams enforce standard transport security protocols and do not share, sell, or index customer purchase logs outside verified pathways.
          </p>

          <h3 className="font-bold text-sm text-apple-dark uppercase tracking-wide">2. Storage & Cache Safety</h3>
          <p>
            This portal incorporates browser memory structures (such as localStorage states) purely to remember active customer authorization tokens, favorited items in wishlists, and cart items. These items can be cleared at any time directly through the client browser settings.
          </p>
        </div>
      )}

      {/* 4d. TERMS & CONDITIONS */}
      {section === 'terms' && (
        <div className="space-y-6 text-gray-500 font-sans leading-relaxed">
          <h1 className="text-3xl font-extrabold tracking-tight font-sans text-apple-dark">Terms of Use.</h1>
          <p className="text-xs text-gray-400">Published: June 17, 2026. Standard Store Terms.</p>
          
          <h3 className="font-bold text-sm text-apple-dark mt-6 uppercase tracking-wide">1. Retail Transaction Controls</h3>
          <p>
            By placing orders on this platform, users confirm that contact and delivery options supplied are 100% correct. Orders are queued for immediate warehouse dispatch, and delivery estimations remain subject to localized career schedules.
          </p>

          <h3 className="font-bold text-sm text-apple-dark uppercase tracking-wide">2. Brand Protection Rights</h3>
          <p>
            The names "iStore", specific configuration finishes (such as Natural Titanium), software operating structures, and dynamic display options represent elite retail catalogs. Warranty is issued directly upon device delivery confirmation.
          </p>
        </div>
      )}

    </div>
  );
}
