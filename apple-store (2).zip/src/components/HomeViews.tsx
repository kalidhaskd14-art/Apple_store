import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../store';
import { formatINR } from '../utils/currency';
import { getFallbackImage } from '../utils/fallbackImage';
import { 
  ArrowRight, ShieldCheck, Award, ChevronLeft, ChevronRight, Star, 
  VolumeX, Volume2, Play, Smartphone, Laptop, Tablet, Headphones, 
  Watch, Sparkles, HelpCircle, RefreshCw, Truck, Percent
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HomeViewsProps {
  setView: (view: string, params?: any) => void;
}

// 1. CINEMATIC VIDEO SLIDES DATA
const CINEMATIC_SLIDES = [
  {
    id: 1,
    badge: "Futuristic Experience",
    title: "iPhone 16 Pro Max",
    tagline: "Built for Apple Intelligence",
    description: "An aerospace‑grade titanium masterpiece with an advanced dual tandem dual-pixel camera and custom A18 chip.",
    videoUrl: "https://images.pexels.com/video-files/3582457/3582457-hd_1280_720_30fps.mp4",
    targetId: "iphone-16-pro-max"
  },
  {
    id: 2,
    badge: "Sound Engineering",
    title: "AirPods Pro 2",
    tagline: "Absolute Acoustic Silence",
    description: "Experience pristine unboxing audio, dynamic head tracking, and real-time noise neutralizing filters.",
    videoUrl: "https://images.pexels.com/video-files/3850541/3850541-hd_1280_720_30fps.mp4",
    targetId: "airpods-pro-2"
  },
  {
    id: 3,
    badge: "Performance Pioneer",
    title: "Apple Watch Ultra 2",
    tagline: "Tested Beyond Boundaries",
    description: "Superb dual‑frequency GPS accuracy, dual-tap gestures, and aerospace titanium housing built to endure.",
    videoUrl: "https://images.pexels.com/video-files/4010131/4010131-hd_1280_720_30fps.mp4",
    targetId: "apple-watch-ultra-2"
  }
];

// 2. FEATURED IPHONE CATALOG SERIES (13, 14, 15, 16 Pro)
const IPHONE_SERIES = [
  {
    id: 'iphone-13',
    name: 'iPhone 13',
    price: 49900,
    rating: 4.7,
    ratingCount: 184,
    image: 'https://images.unsplash.com/photo-1632661674596-df8be070a585?auto=format&fit=contain&q=85&w=800',
    colorHex: '#0f4c81'
  },
  {
    id: 'iphone-14',
    name: 'iPhone 14',
    price: 58900,
    rating: 4.7,
    ratingCount: 124,
    image: 'https://images.unsplash.com/photo-1605787020600-b9ebd5df1d07?auto=format&fit=contain&q=85&w=800',
    colorHex: '#3b2f42'
  },
  {
    id: 'iphone-15',
    name: 'iPhone 15',
    price: 69900,
    rating: 4.8,
    ratingCount: 156,
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=contain&q=85&w=800',
    colorHex: '#cfdbe3'
  },
  {
    id: 'iphone-16-pro',
    name: 'iPhone 16 Pro',
    price: 119900,
    rating: 4.9,
    ratingCount: 228,
    image: 'https://images.unsplash.com/photo-1727181516086-44cedf3eeb88?auto=format&fit=contain&q=85&w=800',
    colorHex: '#cbbda9'
  }
];

// 3. HD AUTO-PLAY REACTION REELS DATA WITH FALLBACK POSTERS
const CREATOR_REELS = [
  {
    id: 'reel-1',
    creator: 'Shlok Mehta',
    comment: 'Pristine unboxing! Received the brand new sealed Desert Titanium today. Thumbs up to this store!',
    stars: 5,
    videoUrl: 'https://images.pexels.com/video-files/5081399/5081399-uhd_1080_1920_30fps.mp4',
    posterUrl: 'https://images.pexels.com/photos/5081399/pexels-photo-5081399.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: 'reel-2',
    creator: 'Riya Sen',
    comment: 'Super fast trade-in check. My device looks incredibly gorgeous and is fully brand authorized!',
    stars: 5,
    videoUrl: 'https://images.pexels.com/video-files/8088172/8088172-hd_1080_1920_30fps.mp4',
    posterUrl: 'https://images.pexels.com/photos/8088172/pexels-photo-8088172.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: 'reel-3',
    creator: 'Dev Malhotra',
    comment: '100% genuine with active Apple Care. Camera control is awesome. Absolutely thumbs up!',
    stars: 5,
    videoUrl: 'https://images.pexels.com/video-files/4057321/4057321-hd_1080_1920_25fps.mp4',
    posterUrl: 'https://images.pexels.com/photos/4057321/pexels-photo-4057321.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: 'reel-4',
    creator: 'Ananya Sharma',
    comment: 'Stunning titanium build. Fast 24h delivery. Will definitely buy my next MacBook from here.',
    stars: 5,
    videoUrl: 'https://images.pexels.com/video-files/3850125/3850125-hd_1080_1920_30fps.mp4',
    posterUrl: 'https://images.pexels.com/photos/3850125/pexels-photo-3850125.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

// 4. TRENDING PRODUCTS
const TRENDING_GADGETS = [
  {
    id: 'iphone-16',
    name: 'iPhone 16 Standard',
    price: 79900,
    rating: 4.8,
    ratingCount: 160,
    image: 'https://images.unsplash.com/photo-1727181516086-44cedf3eeb88?auto=format&fit=contain&q=80&w=500',
    colorHex: '#3e6ae1'
  },
  {
    id: 'apple-watch-ultra-2',
    name: 'Apple Watch Ultra 2',
    price: 89900,
    rating: 4.9,
    ratingCount: 94,
    image: 'https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?auto=format&fit=contain&q=80&w=500',
    colorHex: '#3a3a3c'
  },
  {
    id: 'iphone-16-pro-max',
    name: 'iPhone 16 Pro Max',
    price: 144900,
    rating: 4.9,
    ratingCount: 312,
    image: 'https://images.unsplash.com/photo-1736780381615-5e003faae9be?auto=format&fit=contain&q=80&w=500',
    colorHex: '#c0ad99'
  }
];

// 5. PROMOTIONAL OFFERS
const OFFERS_DATA = [
  {
    id: 1,
    title: "Instant Bank Discount",
    description: "Get instant discount support up to ₹6,000 on purchase of real Apple hardware using verified premium HDFC and ICICI credit cards.",
    badge: "HDFC & ICICI Cards",
    accent: "from-blue-500/10 to-indigo-500/10"
  },
  {
    id: 2,
    title: "Hassle-Free Trade-in Credit",
    description: "Exchange your legacy smartphone to save up to ₹67,500 on selected iPhone models. Immediate valuation, dynamic pickup support.",
    badge: "Trade-In Reward",
    accent: "from-emerald-500/10 to-teal-500/10"
  },
  {
    id: 3,
    title: "No-Cost EMI Solutions",
    description: "Avail 3, 6, or 9 months interest‑free payment installments at zero processing charges for high-end digital lifestyle choices.",
    badge: "0% Interest EMI",
    accent: "from-purple-500/10 to-pink-500/10"
  }
];

// 6. POPULAR CATEGORIES
const CATEGORIES_INDICATOR = [
  { name: 'iPhone', icon: Smartphone, key: 'iphones' },
  { name: 'AirPods', icon: Headphones, key: 'airpods' },
  { name: 'Apple Watch', icon: Watch, key: 'watches' },
  { name: 'MacBook', icon: Laptop, key: 'macbooks' },
  { name: 'iPad', icon: Tablet, key: 'ipads' }
];

export default function HomeViews({ setView }: HomeViewsProps) {
  const { fetchProducts } = useStore();

  // State Management
  const [cinematicIndex, setCinematicIndex] = useState(0);
  const [activeReelIndex, setActiveReelIndex] = useState(0);
  const [isReelMuted, setIsReelMuted] = useState(true);
  const [isReelPlaying, setIsReelPlaying] = useState(true);
  const [phoneImageErrors, setPhoneImageErrors] = useState<Record<string, boolean>>({});
  const [trendingImageErrors, setTrendingImageErrors] = useState<Record<string, boolean>>({});

  // Touch swipe states
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);

  const cinematicVideoRefs = useRef<Record<number, HTMLVideoElement | null>>({});
  const creatorVideoRefs = useRef<Record<string, HTMLVideoElement | null>>({});

  // Cinematic Video Slide Rotation (every 5 seconds)
  useEffect(() => {
    const timer = setInterval(() => {
      setCinematicIndex((prev) => (prev + 1) % CINEMATIC_SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // Synchronize top slide active element playback
  useEffect(() => {
    CINEMATIC_SLIDES.forEach((slide, idx) => {
      const el = cinematicVideoRefs.current[idx];
      if (el) {
        if (idx === cinematicIndex) {
          el.play().catch(() => {});
        } else {
          el.pause();
          el.currentTime = 0;
        }
      }
    });
  }, [cinematicIndex]);

  // Synchronize Customer Reel Active Video playback
  useEffect(() => {
    CREATOR_REELS.forEach((reel, idx) => {
      const el = creatorVideoRefs.current[reel.id];
      if (el) {
        if (idx === activeReelIndex) {
          if (isReelPlaying) {
            el.play().catch(() => {});
          } else {
            el.pause();
          }
        } else {
          el.pause();
          el.currentTime = 0;
        }
      }
    });
  }, [activeReelIndex, isReelPlaying]);

  const handleNextReel = () => {
    setActiveReelIndex((prev) => (prev + 1) % CREATOR_REELS.length);
    setIsReelPlaying(true);
  };

  const handlePrevReel = () => {
    setActiveReelIndex((prev) => (prev - 1 + CREATOR_REELS.length) % CREATOR_REELS.length);
    setIsReelPlaying(true);
  };

  const handleScrollToReels = () => {
    const element = document.getElementById('testimonials-hub');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-[#F7F3FF] text-[#1D1D1F] flex flex-col min-h-screen relative antialiased selection:bg-[#8B5CF6] selection:text-white pb-32 transition-colors duration-500">
      
      {/* 1. CINEMATIC VIDEO BANNER (TOP SECTION) */}
      <section className="px-4 pt-6 max-w-7xl mx-auto w-full relative">
        
        <div className="relative rounded-[32px] overflow-hidden shadow-xl bg-black h-[300px] md:h-[450px] w-full group border border-violet-100/10 z-10">
          
          {/* Slides Loop */}
          <AnimatePresence mode="wait">
            <motion.div
              key={cinematicIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.0 }}
              className="absolute inset-0 w-full h-full"
            >
              <video
                ref={(el) => { cinematicVideoRefs.current[cinematicIndex] = el; }}
                src={CINEMATIC_SLIDES[cinematicIndex].videoUrl}
                className="w-full h-full object-cover opacity-85"
                playsInline
                muted
                loop
                autoPlay
              />

              {/* Sophisticated Dark Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/30" />

              {/* Premium Floating Texts and CTA buttons */}
              <div className="absolute inset-x-0 bottom-0 p-6 md:p-12 flex flex-col items-start text-left z-10 max-w-2xl select-none">
                <span className="bg-white/20 backdrop-blur-md text-white text-[10px] sm:text-xs font-black tracking-widest px-3 sm:px-4 py-1 rounded-full border border-white/25 uppercase inline-block mb-3">
                  {CINEMATIC_SLIDES[cinematicIndex].badge}
                </span>
                
                <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-none mb-1">
                  {CINEMATIC_SLIDES[cinematicIndex].title}
                </h1>
                
                <p className="text-[#A1A1A6] text-xs sm:text-sm font-semibold tracking-tight uppercase font-mono mb-2">
                  {CINEMATIC_SLIDES[cinematicIndex].tagline}
                </p>

                <p className="text-[#FAF9F6]/90 text-[11px] sm:text-xs leading-relaxed max-w-lg mb-6 line-clamp-2 md:line-clamp-none">
                  {CINEMATIC_SLIDES[cinematicIndex].description}
                </p>

                {/* Quick actions deck */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setView('details', { id: CINEMATIC_SLIDES[cinematicIndex].targetId })}
                    className="px-5 py-2.5 sm:px-7 sm:py-3.5 bg-white hover:bg-[#FAF9F6] text-black rounded-full text-xs font-black cursor-pointer shadow-md transition-transform active:scale-95 flex items-center gap-1"
                  >
                    Shop Now
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>

                  <button
                    onClick={handleScrollToReels}
                    className="px-5 py-2.5 sm:px-7 sm:py-3.5 bg-white/10 backdrop-blur-md text-white hover:bg-white/20 rounded-full text-xs font-black border border-white/20 transition-transform active:scale-95 cursor-pointer"
                  >
                    Watch Reviews
                  </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Dots Indicator Loop Aligned Bottom Right */}
          <div className="absolute bottom-6 right-6 md:right-12 z-20 flex gap-2">
            {CINEMATIC_SLIDES.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCinematicIndex(idx)}
                className={`h-2 rounded-full cursor-pointer transition-all duration-300 ${cinematicIndex === idx ? 'w-6 bg-white' : 'w-2 bg-white/40'}`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

        </div>
      </section>

      {/* 2. HORIZONTAL IPHONE COLLECTION */}
      <section className="py-14 max-w-7xl mx-auto w-full px-4 text-left" id="horizontal-iphone-showcase">
        <div className="flex items-end justify-between mb-8 pl-1">
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#8B5CF6] font-mono leading-none">
              The Standard of Premium Design
            </span>
            <h2 className="text-xl sm:text-3xl font-black text-[#1D1D1F] tracking-tight mt-2 pb-1">
              Horizontal iPhone Collection
            </h2>
          </div>
          
          <button
            onClick={() => {
              fetchProducts('', 'iphones');
              setView('collection');
            }}
            className="text-xs font-black text-[#8B5CF6] hover:underline flex items-center gap-1 group shrink-0"
          >
            Explore All Collection
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Swipe Snap Container */}
        <div className="flex gap-6 overflow-x-auto pb-6 pt-1 px-1 snap-x snap-mandatory scrollbar-none" id="horizontal-snap-row">
          {IPHONE_SERIES.map((phone) => {
            const isFallbackActive = phoneImageErrors[phone.id];
            return (
              <div
                key={phone.id}
                className="snap-start shrink-0 w-[280px] sm:w-[320px] bg-white border border-violet-100/60 rounded-[32px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgba(139,92,246,0.05)] hover:shadow-[0_15px_40px_rgba(139,92,246,0.12)] hover:scale-[1.015] transition-all duration-300 relative group overflow-hidden"
              >
                {/* Visual Canvas containing image using light helper background */}
                <div 
                  onClick={() => setView('details', { id: phone.id })}
                  className="h-[200px] w-full bg-[#EFE7FF] rounded-2xl border border-violet-100/20 py-4 px-4 flex items-center justify-center relative overflow-hidden cursor-pointer group-hover:scale-[1.01] transition-transform duration-300"
                >
                  <img
                    src={isFallbackActive ? getFallbackImage(phone.name, phone.colorHex) : phone.image}
                    alt={phone.name}
                    onError={() => setPhoneImageErrors((prev) => ({ ...prev, [phone.id]: true }))}
                    className="h-full object-contain duration-500 transition-all group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="text-left mt-4 text-[#1D1D1F]">
                  <h3 className="font-extrabold text-base sm:text-lg text-[#1D1D1F] tracking-tight truncate">
                    {phone.name}
                  </h3>
                  
                  {/* Rating Stars Overlay */}
                  <div className="flex items-center gap-1 mt-1 text-amber-500">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span className="text-xs font-extrabold text-[#1D1D1F]">{phone.rating}</span>
                    <span className="text-[10px] text-[#6E6E73] font-bold">({phone.ratingCount} reviews)</span>
                  </div>
                </div>

                {/* Price and checkout row */}
                <div className="pt-4 mt-4 border-t border-violet-100/50 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] font-extrabold text-[#6E6E73] uppercase tracking-widest block">Authorized price</span>
                    <span className="text-base font-black text-[#1D1D1F] tracking-tight mt-0.5 block">
                      {formatINR(phone.price)}
                    </span>
                  </div>
                  
                  <button
                    onClick={() => setView('details', { id: phone.id })}
                    className="px-5 py-2.5 bg-black hover:opacity-90 hover:scale-[1.03] text-white rounded-full text-xs font-black transition-all cursor-pointer shadow-sm active:scale-95"
                  >
                    View Details
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. TRENDING PRODUCTS */}
      <section className="py-14 bg-[#EFE7FF] border-y border-violet-100/40" id="trending-products-section">
        <div className="max-w-7xl mx-auto w-full px-4 text-left">
          
          <div className="mb-8">
            <span className="text-[10px] font-black uppercase tracking-widest text-[#8B5CF6] font-mono leading-none pl-1 block">
              Popular Releases Right Now
            </span>
            <h2 className="text-xl sm:text-3xl font-black text-[#1D1D1F] tracking-tight mt-2">
              Trending Apple Releases
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {TRENDING_GADGETS.map((item) => {
              const isTrendingFallbackActive = trendingImageErrors[item.id];
              return (
                <div
                  key={item.id}
                  onClick={() => setView('details', { id: item.id })}
                  className="bg-[#FFFFFF] border border-violet-100/60 rounded-[32px] p-5 flex flex-col justify-between shadow-[0_8px_30px_rgba(139,92,246,0.05)] hover:scale-[1.02] hover:shadow-[0_15px_40px_rgba(139,92,246,0.12)] hover:border-violet-200/50 transition-all duration-300 cursor-pointer group overflow-hidden"
                >
                  {/* High‑fidelity device canvas */}
                  <div className="aspect-[4/3] w-full rounded-2xl bg-[#EFE7FF] border border-violet-100/20 flex items-center justify-center relative overflow-hidden group-hover:scale-[1.01] transition-transform">
                    <img
                      src={isTrendingFallbackActive ? getFallbackImage(item.name, item.colorHex) : item.image}
                      alt={item.name}
                      onError={() => setTrendingImageErrors((prev) => ({ ...prev, [item.id]: true }))}
                      className="h-[80%] object-contain group-hover:scale-105 duration-300 transition-transform"
                      referrerPolicy="no-referrer"
                    />

                    <span className="absolute bottom-2.5 left-2.5 bg-white/95 border border-violet-100 rounded-md px-2 py-0.5 text-[9px] font-black text-[#1D1D1F] flex items-center gap-0.5 shadow-3xs">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                      {item.rating}
                    </span>
                  </div>

                  {/* Pricing metrics */}
                  <div className="pt-4 flex items-center justify-between mt-auto">
                    <div>
                      <h4 className="font-extrabold text-[13px] sm:text-[14px] text-[#1D1D1F] tracking-tight truncate max-w-[160px]">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-[#6E6E73] font-bold font-mono uppercase mt-0.5">Price starting</p>
                    </div>

                    <div className="text-right">
                      <span className="text-sm sm:text-base font-black text-[#8B5CF6] block">
                        {formatINR(item.price)}
                      </span>
                      <span className="text-[9px] font-extrabold text-[#8B5CF6] block hover:underline">
                        Order Now &rarr;
                      </span>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 4. CUSTOMER VIDEO REVIEWS */}
      <section className="py-14 bg-neutral-100 dark:bg-transparent border-b border-neutral-200/40 dark:border-white/5 relative text-center" id="testimonials-hub">
        <div className="max-w-xl mx-auto px-4 mb-8">
          <span className="text-[10px] bg-zinc-100 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-700 rounded-full font-black font-mono px-3.5 py-1 inline-block uppercase tracking-widest">
            Verified Customer Reactions Live
          </span>
          <h2 className="text-xl sm:text-3xl font-black text-black dark:text-white tracking-tight mt-2.5">
            Owner Testimonials & Unboxings
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2 max-w-sm mx-auto font-semibold leading-relaxed">
            Looping customer response video clips showing organic unboxing experiences and first impressions.
          </p>
        </div>

        {/* Cinematic Smartphone Loop Framework container with Touch Swiping support */}
        <div 
          onTouchStart={(e) => setTouchStartX(e.touches[0].clientX)}
          onTouchMove={(e) => setTouchEndX(e.touches[0].clientX)}
          onTouchEnd={() => {
            if (!touchStartX || !touchEndX) return;
            const diff = touchStartX - touchEndX;
            if (diff > 50) {
              handleNextReel();
            } else if (diff < -50) {
              handlePrevReel();
            }
            setTouchStartX(null);
            setTouchEndX(null);
          }}
          className="relative bg-black dark:bg-zinc-950 rounded-[32px] border border-neutral-800 dark:border-zinc-800/80 p-4 shadow-2xl overflow-hidden flex flex-col justify-between aspect-[9/16] w-full max-w-[320px] mx-auto group cursor-grab active:cursor-grabbing select-none"
        >
          
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-16 h-4 bg-black rounded-full z-20 flex items-center justify-center">
            <span className="w-2 h-2 bg-zinc-800 rounded-full animate-pulse" />
          </div>

          {/* Active video target area with smooth fade/slide transition */}
          <div className="absolute inset-0 bg-neutral-900 overflow-hidden flex items-center justify-center">
            <AnimatePresence mode="popLayout">
              <motion.div
                key={`reel-slide-${activeReelIndex}`}
                initial={{ opacity: 0.3, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0.3, scale: 0.95 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="w-full h-full relative"
              >
                <video
                  ref={(el) => { creatorVideoRefs.current[CREATOR_REELS[activeReelIndex].id] = el; }}
                  src={CREATOR_REELS[activeReelIndex].videoUrl}
                  poster={CREATOR_REELS[activeReelIndex].posterUrl}
                  className="w-full h-full object-cover"
                  playsInline
                  loop
                  preload="auto"
                  autoPlay
                  muted={isReelMuted}
                  onClick={() => setIsReelPlaying(!isReelPlaying)}
                />
              </motion.div>
            </AnimatePresence>

            {/* Micro‑overlay for play actions */}
            {!isReelPlaying && (
              <div 
                className="absolute inset-0 bg-black/45 flex items-center justify-center z-15 cursor-pointer"
                onClick={() => setIsReelPlaying(true)}
              >
                <div className="p-3 bg-white/10 rounded-full backdrop-blur-md border border-white/25">
                  <Play className="w-6 h-6 text-white fill-white" />
                </div>
              </div>
            )}

            {/* Gradient shadow blocks supporting legible captions */}
            <div className="absolute bottom-0 left-0 right-0 h-44 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none z-10" />
            <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-black/50 to-transparent pointer-events-none z-10" />
          </div>

          {/* Floated state widgets */}
          <div className="relative z-20 flex justify-between items-center top-3">
            <span className="bg-[#8B5CF6] text-white text-[8px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-sm">
              Live Capture
            </span>
            <button
              onClick={() => setIsReelMuted(!isReelMuted)}
              className="p-1 px-3 bg-black/50 backdrop-blur-md border border-white/10 rounded-full text-[8.5px] font-bold text-white flex items-center gap-1 hover:bg-black/85 cursor-pointer"
            >
              {isReelMuted ? (
                <>
                  <VolumeX className="w-2.5 h-2.5" /> Muted
                </>
              ) : (
                <>
                  <Volume2 className="w-2.5 h-2.5 text-sky-400 animate-bounce" /> Unmuted
                </>
              )}
            </button>
          </div>

          <div className="absolute bottom-16 left-0 right-0 h-1 bg-white/20 z-20">
            <motion.div
              key={activeReelIndex}
              initial={{ width: '0%' }}
              animate={isReelPlaying ? { width: '100%' } : { width: '0%' }}
              transition={{ duration: 7, ease: 'linear' }}
              className="h-full bg-[#8B5CF6]"
            />
          </div>

          {/* Customer Caption Card Frame */}
          <div className="relative z-20 text-left text-white mt-auto space-y-1.5 pb-2 px-1 rounded-b-2xl">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-neutral-800 flex items-center justify-center font-black text-[9.5px] border border-neutral-750">
                {CREATOR_REELS[activeReelIndex].creator.charAt(0)}
              </div>
              <h5 className="text-[11px] font-black text-white">{CREATOR_REELS[activeReelIndex].creator}</h5>
            </div>

            <div className="space-y-1 pr-6">
              <div className="flex text-amber-400 gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-2.5 h-2.5 fill-amber-450 text-amber-450" />
                ))}
              </div>
              <p className="text-[11px] text-neutral-100 font-semibold leading-relaxed italic line-clamp-2">
                "{CREATOR_REELS[activeReelIndex].comment}"
              </p>
            </div>
          </div>

        </div>

        {/* Active control panel */}
        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            onClick={handlePrevReel}
            className="p-2.5 bg-white border border-violet-100/60 hover:bg-[#FAF9F6] rounded-full text-[#1D1D1F] shadow-3xs cursor-pointer active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-4.5 h-4.5" />
          </button>
          
          <div className="flex gap-1.5">
            {CREATOR_REELS.map((_, idx) => (
              <span
                key={idx}
                onClick={() => {
                  setActiveReelIndex(idx);
                  setIsReelPlaying(true);
                }}
                className={`h-1.5 rounded-full transition-all cursor-pointer ${activeReelIndex === idx ? 'w-5 bg-[#8B5CF6]' : 'w-1.5 bg-neutral-300'}`}
              />
            ))}
          </div>

          <button
            onClick={handleNextReel}
            className="p-2.5 bg-white border border-violet-100/60 hover:bg-[#FAF9F6] rounded-full text-[#1D1D1F] shadow-3xs cursor-pointer active:scale-95 transition-transform"
          >
            <ChevronRight className="w-4.5 h-4.5" />
          </button>
        </div>
      </section>

      {/* 5. OFFERS SECTION */}
      <section className="py-14 max-w-7xl mx-auto w-full px-4 text-left" id="exclusive-offers-row">
        <div className="mb-8 pl-1">
          <span className="text-[10px] font-black uppercase tracking-widest text-[#8B5CF6] font-mono leading-none">
            Value Addition Program
          </span>
          <h2 className="text-xl sm:text-3xl font-black text-[#1D1D1F] tracking-tight mt-2">
            Active Partnership Offers
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {OFFERS_DATA.map((offer) => (
            <div
              key={offer.id}
              className="rounded-[32px] p-6 bg-white border border-violet-100/60 flex flex-col justify-between shadow-[0_8px_30px_rgba(139,92,246,0.05)] hover:shadow-[0_15px_40px_rgba(139,92,246,0.12)] hover:scale-[1.015] transition-all duration-300 group"
            >
              <div>
                <span className="text-[9px] font-black text-[#8B5CF6] bg-[#EFE7FF] px-3 py-1 rounded-full uppercase tracking-widest inline-block mb-3.5 border border-violet-100/30">
                  {offer.badge}
                </span>
                
                <h3 className="font-extrabold text-base text-[#1D1D1F] mb-2">
                  {offer.title}
                </h3>
                
                <p className="text-[11.5px] sm:text-xs text-[#6E6E73] leading-relaxed font-semibold">
                  {offer.description}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-violet-100/50 flex items-center justify-between text-[#1D1D1F]">
                <span className="text-[11px] font-black uppercase tracking-wider group-hover:text-[#8B5CF6] transition-colors">
                  Learn Terms &amp; Conditions
                </span>
                <ArrowRight className="w-4 h-4 text-[#6E6E73] group-hover:text-[#8B5CF6] group-hover:translate-x-0.5 transition-all" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. POPULAR CATEGORIES */}
      <section className="py-10 bg-[#F7F3FF] border-t border-violet-100/40" id="categories-indicator-dock">
        <div className="max-w-7xl mx-auto px-4 text-left">
          
          <span className="text-[9.5px] font-black uppercase tracking-widest text-[#8B5CF6] font-mono block mb-4 pl-1">
            Browse Popular Categories
          </span>

          <div className="flex items-center gap-3 overflow-x-auto pb-4 scrollbar-none" id="categories-pill-carousel">
            {CATEGORIES_INDICATOR.map((cat, idx) => {
              const IconComponent = cat.icon;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    fetchProducts('', cat.key);
                    setView('collection');
                  }}
                  className="flex items-center gap-2.5 px-6 py-3.5 bg-white border border-violet-100/60 hover:border-violet-300 hover:bg-[#EFE7FF] rounded-full shrink-0 transition-all cursor-pointer group shadow-3xs animate-fade-in"
                >
                  <IconComponent className="w-4 h-4 text-[#6E6E73] group-hover:text-[#8B5CF6] transition-colors" />
                  <span className="text-xs font-black text-[#1D1D1F] group-hover:text-[#8B5CF6] transition-colors">
                    {cat.name}
                  </span>
                </button>
              );
            })}
          </div>

        </div>
      </section>

      {/* 7. WHY CHOOSE US BENEFITS */}
      <section className="py-14 max-w-7xl mx-auto w-full px-4" id="standard-brand-benefits">
        <span className="text-[9.5px] font-black uppercase tracking-widest text-[#8B5CF6] font-mono block mb-6 text-left pl-1">
          Store Authorized Value Additions
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-left">
          
          <div className="bg-white border border-violet-100/60 p-5 rounded-[32px] flex items-start gap-4 transition-all duration-300 hover:scale-[1.015] hover:shadow-[0_15px_40px_rgba(139,92,246,0.1)] shadow-[0_8px_30px_rgba(139,92,246,0.03)]">
            <div className="p-3 bg-[#EFE7FF] text-[#8B5CF6] shrink-0 rounded-2xl">
              <Truck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-extrabold text-xs text-[#1D1D1F]">Express Shipping</h4>
              <p className="text-[10.5px] text-[#6E6E73] mt-1 leading-relaxed">
                Guaranteed safe express courier dispatch within 24 hours of checkout.
              </p>
            </div>
          </div>

          <div className="bg-white border border-violet-100/60 p-5 rounded-[32px] flex items-start gap-4 transition-all duration-300 hover:scale-[1.015] hover:shadow-[0_15px_40px_rgba(139,92,246,0.1)] shadow-[0_8px_30px_rgba(139,92,246,0.03)]">
            <div className="p-3 bg-[#EFE7FF] text-[#22C55E] shrink-0 rounded-2xl">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-extrabold text-xs text-[#1D1D1F]">Assured Genuine</h4>
              <p className="text-[10.5px] text-[#6E6E73] mt-1 leading-relaxed">
                Sealed hardware directly sourced with valid official manufacturer warranties.
              </p>
            </div>
          </div>

          <div className="bg-white border border-violet-100/60 p-5 rounded-[32px] flex items-start gap-4 transition-all duration-300 hover:scale-[1.015] hover:shadow-[0_15px_40px_rgba(139,92,246,0.1)] shadow-[0_8px_30px_rgba(139,92,246,0.03)]">
            <div className="p-3 bg-[#EFE7FF] text-[#6366F1] shrink-0 rounded-2xl">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-extrabold text-xs text-[#1D1D1F]">Certified Vault</h4>
              <p className="text-[10.5px] text-[#6E6E73] mt-1 leading-relaxed">
                Double encrypted gateways powered with OTP validations and prompt receipts.
              </p>
            </div>
          </div>

          <div className="bg-white border border-violet-100/60 p-5 rounded-[32px] flex items-start gap-4 transition-all duration-300 hover:scale-[1.015] hover:shadow-[0_15px_40px_rgba(139,92,246,0.1)] shadow-[0_8px_30px_rgba(139,92,246,0.03)]">
            <div className="p-3 bg-[#EFE7FF] text-[#D97706] shrink-0 rounded-2xl">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-extrabold text-xs text-[#1D1D1F]">1 Year Warranty</h4>
              <p className="text-[10.5px] text-[#6E6E73] mt-1 leading-relaxed">
                Enjoy complete peace of mind with 1 year official company support across global care centers.
              </p>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
