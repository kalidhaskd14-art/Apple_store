import { useStore } from '../store';

interface FooterProps {
  setView: (view: string, params?: any) => void;
}

export default function Footer({ setView }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#F5F5F7] dark:bg-zinc-950 border-t border-gray-200 dark:border-zinc-850 text-[#86868B] dark:text-zinc-400 py-12 px-4 sm:px-6 lg:px-8 mt-24 transition-colors" id="main-footer">
      <div className="max-w-7xl mx-auto">
        
        {/* Footnotes Disclaimer Box */}
        <div className="border-b border-[#D2D2D7] dark:border-zinc-800 pb-8 mb-8 text-[11px] leading-relaxed font-sans" id="footer-footnotes">
          <p className="mb-3">
            * Terms of Offer: Real-time model availability, promotional coupon discount applications, and localized taxes represent professional retail operations. All product listings represent authentic design indices and global catalog entries.
          </p>
          <p>
            1. Instant Bank Discount: Eligible instant digital savings of up to ₹6,000 are verified during secure HDFC/ICICI card checkout flows. WhatsApp status updates require valid customer contact numbers.
          </p>
        </div>

        {/* Dynamic Directory Grids */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 text-[11.5px] leading-6 mb-12" id="footer-directory">
          
          <div>
            <h4 className="font-semibold text-apple-dark dark:text-zinc-200 font-sans tracking-wide mb-3">Shop and Learn</h4>
            <ul className="space-y-1">
              <li><button onClick={() => setView('collection')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">iPhone models</button></li>
              <li><button onClick={() => setView('collection')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">iPhone Accessories</button></li>
              <li><button onClick={() => setView('collection')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Special Edition Store</button></li>
              <li><button onClick={() => setView('collection')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Gift Card balances</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-apple-dark dark:text-zinc-200 font-sans tracking-wide mb-3">Customer Support</h4>
            <ul className="space-y-1">
              <li><button onClick={() => setView('contact')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Contact Care desk</button></li>
              <li><button onClick={() => setView('account')} className="hover:underline hover:text-black dark:hover:text-white transition-all font-semibold text-left">Track my Shipment</button></li>
              <li><button onClick={() => setView('about')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Returns & Refunds</button></li>
              <li><button onClick={() => setView('contact')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Hardware Warranty</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-apple-dark dark:text-zinc-200 font-sans tracking-wide mb-3">iStore corporate</h4>
            <ul className="space-y-1">
              <li><button onClick={() => setView('about')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">About the brand</button></li>
              <li><button onClick={() => setView('about')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Design philosophies</button></li>
              <li><button onClick={() => setView('about')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Corporate governance</button></li>
              <li><button onClick={() => setView('admin')} className="text-emerald-700 dark:text-emerald-500 font-semibold hover:underline transition-all text-left">Administrative log</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-apple-dark dark:text-zinc-200 font-sans tracking-wide mb-3">Legal & Rules</h4>
            <ul className="space-y-1">
              <li><button onClick={() => setView('privacy')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Privacy Policy</button></li>
              <li><button onClick={() => setView('terms')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Terms of Service</button></li>
              <li><button onClick={() => setView('privacy')} className="hover:underline hover:text-black dark:hover:text-white transition-all text-left">Cookie Disclosures</button></li>
            </ul>
          </div>

          <div className="col-span-2 md:col-span-1">
            <h4 className="font-semibold text-apple-dark dark:text-zinc-200 font-sans tracking-wide mb-3">About iStore</h4>
            <p className="leading-relaxed text-gray-500 dark:text-zinc-400 text-[11px]">
              Delivering premium titanium frameworks, fluid user experiences, and responsive Apple-quality hardware. Engineered using high-performance Node, Vite, React, Express, and secure database states.
            </p>
          </div>

        </div>

        {/* Final Line */}
        <div className="border-t border-[#D2D2D7] dark:border-zinc-800 pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px]" id="footer-bottom">
          <div className="flex flex-wrap gap-2 text-center md:text-left">
            <span>Copyright © {currentYear} iStore Premium Solutions. All rights reserved.</span>
            <span className="hidden md:inline text-gray-300 dark:text-zinc-800">|</span>
            <button onClick={() => setView('privacy')} className="hover:underline hover:text-black dark:hover:text-white">Privacy Policy</button>
            <span className="text-gray-300 dark:text-zinc-800">|</span>
            <button onClick={() => setView('terms')} className="hover:underline hover:text-black dark:hover:text-white">Terms of Use</button>
            <span className="text-gray-300 dark:text-zinc-800">|</span>
            <button onClick={() => setView('about')} className="hover:underline hover:text-black dark:hover:text-white">Sales Policy</button>
          </div>
          <div>
            <span className="text-apple-dark dark:text-zinc-200 font-medium font-mono text-[10.5px]">Global Retail Network / English</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
