import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Product } from '../types';
import { Star, Heart, ShoppingBag, ArrowLeft, ArrowRight, ShieldCheck, Truck, RefreshCw, Calculator, Tv, Sparkles, AlertCircle } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR, formatEMI } from '../utils/currency';
import ThreeSixtyViewer from './ThreeSixtyViewer';
import { getProductMedia, calculateEMISchedules } from '../utils/productMedia';

interface ProductDetailsProps {
  productId: string;
  setView: (view: string, params?: any) => void;
}

export default function ProductDetails({ productId, setView }: ProductDetailsProps) {
  const { 
    currentProduct, 
    fetchProductById, 
    addToCart, 
    toggleWishlist, 
    wishlist, 
    addReview,
    isAuthenticated
  } = useStore();

  const [loading, setLoading] = useState(true);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedStorage, setSelectedStorage] = useState('');
  const [buyQty, setBuyQty] = useState(1);
  const [activeImageIdx, setActiveImageIdx] = useState(0);

  // Dynamic interactive Image Zoom state
  const [zoomPosition, setZoomPosition] = useState({ x: 50, y: 50 });
  const [isZooming, setIsZooming] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomPosition({ x, y });
  };

  // Swipe Support & Auto-slide
  const [touchStartX, setTouchStartX] = useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null || !currentProduct?.images || currentProduct.images.length === 0) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;

    if (diff > 50) {
      // Swipe left -> Next image
      setActiveImageIdx((prev) => (prev + 1) % currentProduct.images.length);
    } else if (diff < -50) {
      // Swipe right -> Prev image
      setActiveImageIdx((prev) => (prev - 1 + currentProduct.images.length) % currentProduct.images.length);
    }
    setTouchStartX(null);
  };

  // Auto-slide every 3 seconds, resets timer on user change
  useEffect(() => {
    if (loading || !currentProduct || !currentProduct.images || currentProduct.images.length <= 1) return;
    const timer = setInterval(() => {
      setActiveImageIdx((prev) => (prev + 1) % currentProduct.images.length);
    }, 3000);
    return () => clearInterval(timer);
  }, [loading, currentProduct, activeImageIdx]);

  // Review form states
  const [ratingInput, setRatingInput] = useState(5);
  const [commentInput, setCommentInput] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);
  const [reviewError, setReviewError] = useState('');

  useEffect(() => {
    setLoading(true);
    fetchProductById(productId).then((prod) => {
      if (prod) {
        setSelectedColor(prod.colors[0]);
        setSelectedStorage(prod.storages[0]);
      }
      setLoading(false);
    });
  }, [productId]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto py-24 text-center">
        <span className="w-8 h-8 border-3 border-violet-100/30 border-t-[#8B5CF6] rounded-full animate-spin inline-block" />
      </div>
    );
  }

  if (!currentProduct) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center px-4 animate-fade-in">
        <h2 className="text-xl font-bold text-[#1D1D1F]">Product Not Found</h2>
        <p className="text-xs text-[#6E6E73] mt-1">This product could not be found or has been removed from the catalog index.</p>
        <button onClick={() => setView('home')} className="px-6 py-3 bg-black text-white text-[11px] font-black tracking-wider uppercase rounded-full mt-6">Return to Storefront</button>
      </div>
    );
  }

  const p = currentProduct;
  const discountPrice = p.price * (1 - p.discount / 100);
  const colorName = p.colorNames[p.colors.indexOf(selectedColor)] || 'Titanium Gray';
  const isInWishlist = wishlist.some(item => item.id === p.id);

  const handleCartSubmit = () => {
    addToCart(p, buyQty, selectedColor, selectedStorage);
    // Micro flash-notification or directly open cart
    setView('cart');
  };

  const handleBuyNow = () => {
    addToCart(p, buyQty, selectedColor, selectedStorage);
    setView('checkout');
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setReviewError('');
    setReviewSuccess(false);

    if (!commentInput.trim()) {
      setReviewError('Please write your review thoughts first');
      return;
    }

    const ok = await addReview(p.id, ratingInput, commentInput);
    if (ok) {
      setReviewSuccess(true);
      setCommentInput('');
    } else {
      setReviewError('Failed to log review. Session may require signing in first.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="product-details-main">
      
      {/* Back button link */}
      <button 
        onClick={() => setView('collection')}
        className="flex items-center gap-1.5 text-xs font-semibold text-[#8B5CF6] hover:underline mb-8 cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Back to Model Collection
      </button>

      {/* Main product card showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        
        {/* LEFT CHANNEL: Studio Multi-images */}
        <div className="space-y-4">
          <div 
            className="w-full aspect-square bg-[#EFE7FF]/40 rounded-[32px] p-6 flex items-center justify-center relative border border-violet-100/40 overflow-hidden select-none cursor-zoom-in shadow-xl"
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            onMouseEnter={() => setIsZooming(true)}
            onMouseLeave={() => {
              setIsZooming(false);
              setZoomPosition({ x: 50, y: 50 });
            }}
            onMouseMove={handleMouseMove}
          >
            {/* Hover visual lens indicator badge */}
            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[9px] font-bold text-[#1D1D1F] uppercase tracking-wider z-10 flex items-center gap-1.5 border border-violet-100/30 shadow-xs pointer-events-none transition-opacity duration-300">
              <span className="w-1.5 h-1.5 bg-[#8B5CF6] rounded-full animate-ping" />
              Interactive Zoom
            </div>

            {/* Left/Right Controls overlay */}
            {p.images.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIdx((prev) => (prev - 1 + p.images.length) % p.images.length);
                  }}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/95 dark:bg-zinc-900/95 hover:bg-white text-apple-dark dark:text-white rounded-full shadow-md hover:scale-110 active:scale-95 transition-all cursor-pointer z-10 border dark:border-white/5"
                  title="Previous image"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveImageIdx((prev) => (prev + 1) % p.images.length);
                  }}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/95 dark:bg-zinc-900/95 hover:bg-white text-apple-dark dark:text-white rounded-full shadow-md hover:scale-110 active:scale-95 transition-all cursor-pointer z-10 border dark:border-white/5"
                  title="Next image"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </>
            )}

            <img 
              src={p.images[activeImageIdx] || p.images[0]} 
              alt={p.name} 
              className="object-contain max-h-[380px] transition-transform duration-150 ease-out pointer-events-none filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.15)]"
              style={isZooming ? {
                transform: 'scale(2.2)',
                transformOrigin: `${zoomPosition.x}% ${zoomPosition.y}%`
              } : undefined}
              referrerPolicy="no-referrer"
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = getFallbackImage(p.name, p.colors[0]);
              }}
            />
            {p.discount > 0 && (
              <span className="absolute top-4 left-4 bg-red-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                {p.discount}% OFF
              </span>
            )}

            {/* Slider Dots Indicator */}
            {p.images.length > 1 && (
              <div className="absolute bottom-4 flex gap-1.5 justify-center z-10">
                {p.images.map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIdx(idx)}
                    className={`w-2 h-2 rounded-full transition-all ${activeImageIdx === idx ? 'w-5 bg-[#8B5CF6]' : 'bg-neutral-300'}`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Mini sliders preview */}
          {p.images.length > 1 && (
            <div className="flex gap-3 justify-center">
              {p.images.map((img, idx) => (
                <button 
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-14 h-14 p-1.5 bg-white rounded-xl border cursor-pointer transition-all ${activeImageIdx === idx ? 'border-[#8B5CF6] ring-2 ring-[#8B5CF6]/30' : 'border-violet-100 hover:bg-violet-50/50'}`}
                >
                  <img 
                    src={img} 
                    alt="" 
                    className="w-full h-full object-contain" 
                    referrerPolicy="no-referrer" 
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = getFallbackImage(p.name, p.colors[idx] || p.colors[0]);
                    }}
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* RIGHT CHANNEL: Buy specs choices */}
        <div className="space-y-6 text-[#1D1D1F]">
          
          <div>
            <span className="text-[10px] font-extrabold text-[#8B5CF6] uppercase tracking-widest font-mono">Mobile Smartphone Series</span>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight text-[#1D1D1F] font-sans mt-1">
              {p.name}
            </h1>
            
            {/* Ratings Summary */}
            <div className="flex items-center gap-2 mt-2">
              <div className="flex text-amber-400 items-center">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              </div>
              <span className="text-xs font-bold text-[#1D1D1F]">{p.ratings.average}</span>
              <span className="text-xs text-[#6E6E73]">| {p.ratings.count} verified customer reviews</span>
            </div>
          </div>

          <p className="text-sm leading-relaxed text-[#6E6E73] font-sans">
            {p.description}
          </p>

          {/* Pricing Deck */}
          <div className="border-t border-b border-violet-100/50 py-4 flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold text-[#6E6E73] uppercase tracking-wider">Retail Checkout Price</p>
              <div className="flex items-baseline gap-2 mt-1">
                {p.discount > 0 ? (
                  <>
                    <strong className="text-2xl font-black text-[#1D1D1F]">{formatINR(discountPrice)}</strong>
                    <span className="text-[#6E6E73] line-through text-sm">{formatINR(p.price)}</span>
                  </>
                ) : (
                  <strong className="text-2xl font-black text-[#1D1D1F]">{formatINR(p.price)}</strong>
                )}
              </div>
            </div>
            <div className="text-right text-[11px] text-[#6E6E73]">
              <span>Pay as low as <b className="text-[#8B5CF6]">{formatEMI(discountPrice)}/mo</b></span><br />
              <span>for 24 months with interest-free installment schemes.</span>
            </div>
          </div>

          {/* COLOR FINISHES SELECTION */}
          <div className="space-y-2 font-semibold">
            <span className="text-xs font-bold text-[#1D1D1F] block uppercase tracking-wide">
              1. Finish: <span className="text-[#8B5CF6]">{colorName}</span>
            </span>
            <div className="flex gap-2.5">
              {p.colors.map((hex, idx) => (
                <button 
                  key={hex}
                  onClick={() => setSelectedColor(hex)}
                  className={`w-7.5 h-7.5 rounded-full border cursor-pointer transition-all flex items-center justify-center ${selectedColor === hex ? 'ring-2 ring-[#8B5CF6] scale-105 border-transparent' : 'border-violet-200 hover:scale-105'}`}
                  style={{ backgroundColor: hex }}
                  title={p.colorNames[idx]}
                />
              ))}
            </div>
          </div>

          {/* STORAGE SIZES SELECTION */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-[#1D1D1F] block uppercase tracking-wide">
              2. Capacity: <span className="text-[#8B5CF6]">{selectedStorage}</span>
            </span>
            <div className="grid grid-cols-3 gap-3">
              {p.storages.map((storage) => (
                <button 
                   key={storage}
                   onClick={() => setSelectedStorage(storage)}
                   className={`p-3 rounded-xl border text-center text-xs font-semibold cursor-pointer transition-all ${selectedStorage === storage ? 'border-[#8B5CF6] bg-[#EFE7FF]/60 text-black font-extrabold shadow-sm' : 'border-violet-100 hover:border-violet-300 bg-white text-[#6E6E73]'}`}
                >
                  {storage}
                </button>
              ))}
            </div>
          </div>

          {/* Fast Buy Actions Panel */}
          <div className="pt-4 border-t border-violet-100/50 flex items-center gap-4">
            {p.stock > 0 ? (
              <>
                <button 
                  onClick={handleCartSubmit}
                  className="flex-1 py-3 text-xs bg-[#EFE7FF] hover:bg-[#E2D2FF] text-[#1D1D1F] font-bold rounded-full transition-all flex items-center justify-center gap-1.5 border border-violet-100/30"
                >
                  <ShoppingBag className="w-4 h-4 text-[#8B5CF6]" />
                  Add to Cart Bag
                </button>
                
                <button 
                  onClick={handleBuyNow}
                  className="bg-[#000000] hover:scale-[1.03] text-white flex-1 py-3.5 text-xs font-black shadow-md rounded-full flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  Buy Now Instantly
                  <ArrowRight className="w-4 h-4 shrink-0" />
                </button>
              </>
            ) : (
              <div className="w-full text-center py-3.5 bg-rose-50 border border-rose-100 rounded-full text-rose-700 font-bold text-xs uppercase tracking-wider">
                🚫 Temporarily Out of Stock
              </div>
            )}

            <button 
              onClick={() => toggleWishlist(p)}
              className={`p-3.5 border rounded-full hover:scale-105 cursor-pointer active:scale-95 transition-all ${isInWishlist ? 'border-rose-500 text-rose-500 bg-rose-50/10' : 'border-violet-100 text-[#6E6E73]'}`}
              title="Add to wishlist favorites"
            >
              <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-rose-500 text-rose-505' : ''}`} />
            </button>
          </div>

          {/* Logistics banner list */}
          <div className="bg-white border border-violet-100/60 rounded-[24px] p-5 space-y-3.5 text-xs text-[#6E6E73] font-sans">
            <div className="flex gap-2.5 items-start">
              <Truck className="w-4 h-4 text-[#8B5CF6] shrink-0 mt-0.5" />
              <div>
                <b className="text-[#1D1D1F] block">Fast, Free Shipping</b>
                <span>Complimentary express delivery on orders over ₹40,000, dispatched from regional hubs.</span>
              </div>
            </div>
            
            <div className="flex gap-2.5 items-start">
              <RefreshCw className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <b className="text-[#1D1D1F] block">Easy Returns</b>
                <span>Return unused models within 14 days in compliance with sales policies, hassle-free.</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* IMMERSIVE MEDIA SUITE: 360° Studio, EMI Planner & Cinema Film */}
      <div className="my-16 space-y-16 border-t border-violet-100/40 pt-16" id="immersive-media-suite">
        
        {/* 1. 360° Interactive Product view */}
        <div className="space-y-4">
          <div>
            <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] border border-violet-100/30 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">3D Model</span>
            <h2 className="text-2xl font-extrabold text-[#1D1D1F] tracking-tight mt-2.5">
               Interactive 360° Showroom
            </h2>
            <p className="text-xs text-[#6E6E73] mt-1 max-w-xl">
              Drag your cursor or finger left and right across the viewport to rotate and inspect color finishes, cameras, and bezel alignment from every angle.
            </p>
          </div>
          
          <ThreeSixtyViewer 
            images={p.images} 
            productName={p.name} 
            category={p.category}
          />
        </div>

        {/* 2. EMI installment plan matrix and bank breakdown calculator */}
        <div className="space-y-4" id="emi-planner-hub">
          <div>
            <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] border border-violet-100/30 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">Calculator</span>
            <h2 className="text-2xl font-extrabold text-[#1D1D1F] tracking-tight mt-2.5">
               Flexible Financing & EMI Installment Plans
            </h2>
            <p className="text-xs text-[#6E6E73] mt-1 max-w-xl">
              Compare installment rates across leading public and private credit card banks. Choose key tenure schemes with dynamic calculations.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 bg-white border border-violet-100/60 rounded-[32px] p-6 shadow-[0_12px_40px_rgba(139,92,246,0.03)] relative overflow-hidden">
            <div className="lg:col-span-1 space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-[#8B5CF6] mb-2">
                  <Calculator className="w-5 h-5" />
                  <span className="font-extrabold text-xs uppercase tracking-wider">Plan Simulator</span>
                </div>
                <h3 className="font-bold text-base text-[#1D1D1F]">Estimate Monthly Pricing</h3>
                <p className="text-[11px] text-gray-400 mt-1 leading-relaxed">
                  Calculated based on standard model configuration retail price of <b>{formatINR(discountPrice)}</b>. EMI terms require credit validation.
                </p>
              </div>

              <div className="p-4 bg-[#FBF9FF] rounded-2xl border border-violet-50">
                <span className="text-[9.5px] font-bold text-gray-400 uppercase tracking-widest font-mono">No Cost EMI Options</span>
                <p className="text-xs text-zinc-700 font-semibold mt-1.5 leading-relaxed">
                  ✓ 0% Interest options are available with 3 and 6-month tenures on selected credit cards of Axis and HDFC.
                </p>
              </div>
            </div>

            <div className="lg:col-span-2 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-violet-100 text-[10px] font-extrabold uppercase tracking-widest text-[#6E6E73] font-mono">
                    <th className="py-3 px-2">Card Institution</th>
                    <th className="py-3 px-2 text-center">Tenure (Months)</th>
                    <th className="py-3 px-2 text-center">Interest</th>
                    <th className="py-3 px-2 text-right">Monthly EMI</th>
                    <th className="py-3 px-2 text-right">Total Payout</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-violet-50/50 text-xs">
                  {calculateEMISchedules(discountPrice).map((plan, index) => (
                    <tr 
                      key={index} 
                      className={`hover:bg-[#FBF9FF] transition-colors ${plan.ratePercent === 0 ? 'bg-emerald-500/5' : ''}`}
                    >
                      <td className="py-3.5 px-2 font-bold text-[#1D1D1F] flex items-center gap-1.5">
                        {plan.bankName}
                        {plan.ratePercent === 0 && (
                          <span className="bg-emerald-500/10 text-emerald-600 text-[8px] font-black font-mono px-1.5 py-0.5 rounded uppercase">
                            No Cost
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-2 text-center font-bold text-gray-500 font-mono">
                        {plan.months} Months
                      </td>
                      <td className="py-3.5 px-2 text-center text-gray-400 font-mono">
                        {plan.ratePercent === 0 ? '0%' : `${plan.ratePercent}%`}
                      </td>
                      <td className="py-3.5 px-2 text-right font-black text-[#8B5CF6] font-mono">
                        {formatINR(plan.monthlyInstallment)}/mo
                      </td>
                      <td className="py-3.5 px-2 text-right text-gray-500 font-mono">
                        {formatINR(plan.totalWithInterest)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="mt-3.5 text-[10px] text-gray-400 font-medium flex items-start gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <span>GST and processing charges may apply per bank discretion. Above values are estimate approximations.</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Official Product Video Commercial */}
        <div className="space-y-4" id="cinema-commercial-section">
          <div>
            <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] border border-violet-100/30 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">Cinema Film</span>
            <h2 className="text-2xl font-extrabold text-[#1D1D1F] tracking-tight mt-2.5">
               Cinema Special Projection Commercial
            </h2>
            <p className="text-xs text-[#6E6E73] mt-1 max-w-xl">
              Immerse yourself in the high-fidelity presentation film exploring the seamless industrial design secrets of {p.name}.
            </p>
          </div>

          <div className="bg-white border border-violet-100/60 rounded-[32px] p-6 shadow-[0_12px_40px_rgba(139,92,246,0.03)] overflow-hidden relative">
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-violet-50 bg-zinc-950 shadow-inner flex items-center justify-center">
              <video 
                src={getProductMedia(p.id).videoUrl}
                className="absolute inset-0 w-full h-full object-cover rounded-2xl"
                autoPlay
                muted
                loop
                playsInline
                controls
                preload="metadata"
              />
            </div>
            
            <div className="mt-4 flex items-center justify-between">
              <span className="text-[11.5px] font-bold text-[#1D1D1F] flex items-center gap-1.5 font-sans">
                <Tv className="w-4 h-4 text-[#8B5CF6]" />
                {getProductMedia(p.id).tagline}
              </span>
              <span className="text-[10px] text-[#6E6E73] font-mono">
                1080P CINEMATIC CHROME
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Grid: Specifications & Reviews log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 border-t border-violet-100/40 pt-16">
        
        {/* TECH SPECS */}
        <div className="space-y-6">
          <h3 className="font-bold text-lg text-[#1D1D1F] tracking-tight">Technical Specifications</h3>
          <div className="border border-violet-100/60 rounded-[28px] overflow-hidden shadow-[0_8px_30px_rgba(139,92,246,0.03)] divide-y divide-violet-50 bg-white">
            {Object.keys(p.specs).map((key) => (
              <div key={key} className="flex p-4 text-xs font-sans">
                <span className="font-bold text-[#1D1D1F] w-1/3 shrink-0">{key}</span>
                <span className="text-[#6E6E73]">{p.specs[key]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CLIENT REVIEWS */}
        <div className="space-y-8" id="customer-reviews-section">
          <h3 className="font-bold text-lg text-[#1D1D1F] tracking-tight">Customer Reviews</h3>

          {/* Form to post a review */}
          <div className="bg-[#EFE7FF]/35 rounded-[32px] p-6 border border-violet-100/30">
            <h4 className="font-bold text-xs text-[#1D1D1F] mb-4">Share Your Product Experience</h4>
            
            {reviewSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs rounded-xl mb-4 flex items-center gap-1.5 font-sans">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                Thank you! Your verified product review was posted successfully.
              </div>
            )}

            {reviewError && (
              <div className="p-3 bg-rose-50 border border-rose-100 text-rose-800 text-xs rounded-xl mb-4 font-sans">
                ⚠️ {reviewError}
              </div>
            )}

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-[#1D1D1F]">Star Score:</span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button 
                      key={num}
                      type="button"
                      onClick={() => setRatingInput(num)}
                      className="text-amber-400 p-0.5 cursor-pointer hover:scale-110 active:scale-95 transition-all"
                    >
                      <Star className={`w-4 h-4 ${ratingInput >= num ? 'fill-amber-400' : 'text-gray-305'}`} />
                    </button>
                  ))}
                </div>
              </div>

              <textarea 
                placeholder="How has the titanium finish felt? Write review thoughts..."
                className="bg-white w-full h-24 text-xs rounded-2xl p-4 border border-violet-100 focus:outline-[#8B5CF6] text-[#1D1D1F]"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                required
              />

              <button 
                type="submit"
                className="py-3 px-6 bg-black text-white text-[10px] tracking-wider uppercase font-black rounded-full cursor-pointer hover:scale-[1.02] transition-all w-full sm:w-auto"
              >
                Post Review Item
              </button>
            </form>
          </div>

          {/* Reviews list */}
          <div className="space-y-4">
            {p.reviews && p.reviews.length > 0 ? (
              p.reviews.map((rev) => (
                <div key={rev.id} className="p-5 bg-white border border-violet-100/50 rounded-[28px] shadow-[0_6px_25px_rgba(139,92,246,0.03)]">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-xs text-[#1D1D1F]">{rev.userName}</span>
                    <span className="text-[9.5px] text-[#6E6E73] font-mono">{new Date(rev.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex text-amber-400 mb-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-250'}`} />
                    ))}
                  </div>
                  <p className="text-xs text-[#6E6E73] font-sans mt-2">{rev.comment}</p>
                </div>
              ))
            ) : (
              <p className="text-xs text-[#6E6E73] text-center py-8 border border-dashed border-violet-100 rounded-3xl">
                No customer reviews posted for this model yet. Be the first to share!
              </p>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
