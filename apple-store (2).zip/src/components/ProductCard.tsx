import { Product } from '../types';
import { useStore } from '../store';
import { ShoppingBag, Star, Heart } from 'lucide-react';
import React from 'react';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR, formatEMI } from '../utils/currency';

interface ProductCardProps {
  product: Product;
  setView: (view: string, params?: any) => void;
  key?: string;
}

export default function ProductCard({ product, setView }: ProductCardProps) {
  const { toggleWishlist, wishlist, addToCart } = useStore();

  const discountPrice = product.price * (1 - product.discount / 100);
  const isInWishlist = wishlist.some(item => item.id === product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(
      product,
      1,
      product.colors[0],
      product.storages[0]
    );
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product);
  };

  return (
    <div 
      className="group relative bg-[#FFFFFF] rounded-[32px] border border-violet-100/60 p-5 hover:scale-[1.02] hover:shadow-[0_15px_40px_rgba(139,92,246,0.12)] transition-all duration-350 flex flex-col justify-between cursor-pointer shadow-[0_8px_30px_rgba(139,92,246,0.05)] overflow-hidden"
      onClick={() => setView('details', { id: product.id })}
      id={`prod-card-${product.id}`}
    >
      <div>
        {/* Badges Overlay & Wishlist Button */}
        <div className="flex items-center justify-between pointer-events-none z-10 mb-2">
          <div className="flex flex-col gap-1.5">
            {product.discount > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0 w-fit">
                {product.discount}% OFF
              </span>
            )}
            {product.isNewArrival && (
               <span className="bg-[#8B5CF6] text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0 w-fit">
                 NEW
               </span>
            )}
            {product.isBestSeller && (
              <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0 w-fit">
                BEST SELLER
              </span>
            )}
          </div>
          <button 
            onClick={handleWishlistToggle}
            className="pointer-events-auto p-2 bg-white dark:bg-zinc-900 rounded-full shadow-xs text-gray-400 dark:text-zinc-500 hover:text-red-500 hover:scale-110 active:scale-95 transition-all cursor-pointer border dark:border-white/10"
            title="Add to Wishlist"
          >
            <Heart className={`w-3.5 h-3.5 ${isInWishlist ? 'fill-red-500 text-red-500' : ''}`} />
          </button>
        </div>

        {/* Product Studio Picture */}
        <div className="w-full aspect-square overflow-hidden rounded-xl bg-blend-multiply bg-gray-50 dark:bg-zinc-950/40 flex items-center justify-center p-2 mb-4 relative border dark:border-white/5">
          <img 
            src={product.images[0]} 
            alt={product.name} 
            className="object-contain h-40 w-full group-hover:scale-105 transition-transform duration-500 filter drop-shadow-[0_5px_15px_rgba(0,0,0,0.1)]"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = getFallbackImage(product.name, product.colors[0]);
            }}
          />
        </div>

        {/* Colors finery */}
        <div className="flex gap-1.5 mb-2 justify-center">
          {product.colors.map((hex, idx) => (
            <span 
              key={hex}
              className="w-2.5 h-2.5 rounded-full border border-gray-300 dark:border-zinc-700 shrink-0 block shadow-inner"
              style={{ backgroundColor: hex }}
              title={product.colorNames[idx]}
            />
          ))}
        </div>

        {/* Info */}
        <h3 className="font-semibold text-[13.5px] text-apple-dark dark:text-white text-center group-hover:text-[#8B5CF6] transition-colors truncate">
          {product.name}
        </h3>
        
        {/* Ratings display */}
        <div className="flex items-center gap-1 justify-center mt-1 text-[11px] text-apple-gray dark:text-zinc-400">
          <div className="flex items-center text-amber-400">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          </div>
          <span className="font-semibold text-apple-dark dark:text-zinc-200">{product.ratings.average}</span>
          <span>({product.ratings.count})</span>
        </div>
      </div>

      <div className="mt-4">
        {/* Pricing Layout */}
        <div className="flex flex-col items-center mb-3">
          {product.discount > 0 ? (
            <div className="flex items-center gap-2">
              <span className="text-gray-400 line-through text-xs">{formatINR(product.price)}</span>
              <span className="text-apple-dark dark:text-white font-extrabold text-sm">{formatINR(discountPrice)}</span>
            </div>
          ) : (
            <span className="text-apple-dark dark:text-white font-extrabold text-sm">{formatINR(product.price)}</span>
          )}
          <span className="text-[10px] text-gray-400 dark:text-zinc-450 mt-0.5 font-sans">
            Or {formatEMI(discountPrice)}/mo for 24 mo.
          </span>
        </div>

        {/* Responsive buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button 
            type="button"
            onClick={(e) => { e.stopPropagation(); setView('details', { id: product.id }); }}
            className="w-full text-center text-xs bg-[#EFE7FF] hover:bg-[#E2D2FF] rounded-full py-2.5 font-semibold text-[#1D1D1F] transition-all cursor-pointer shadow-3xs"
          >
            View Specs
          </button>
          
          <button 
            type="button"
            onClick={handleQuickAdd}
            className="p-2.5 bg-black hover:opacity-90 hover:scale-[1.05] text-white rounded-full transition-all cursor-pointer shadow-sm"
            title="Fast Add to Cart"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
