import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RotateCcw, AlertTriangle, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-slate-900 font-sans">
          <div className="bg-white p-8 md:p-12 rounded-[32px] shadow-[0_24px_64px_rgba(139,92,246,0.06)] border border-violet-100 max-w-xl w-full text-center space-y-6">
            <div className="mx-auto w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center text-amber-500">
              <AlertTriangle className="w-8 h-8" />
            </div>
            
            <div className="space-y-2">
              <h1 className="text-2xl font-black tracking-tight text-[#1D1D1F]">
                An unexpected event occurred
              </h1>
              <p className="text-sm text-slate-500 leading-relaxed">
                Our responsive runtime caught an error during live render. Don't worry, your physical store database state is safe.
              </p>
            </div>

            {this.state.error && (
              <div className="p-4 bg-slate-55 border border-slate-100 rounded-2xl text-left text-xs font-mono text-slate-600 max-h-40 overflow-y-auto scrollbar-thin">
                {this.state.error.stack || this.state.error.message}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <button
                onClick={this.handleReset}
                className="flex-1 flex items-center justify-center gap-2 bg-zinc-950 hover:bg-black text-white text-xs font-bold py-3.5 px-6 rounded-full cursor-pointer transition-all hover:scale-[1.01]"
              >
                <RotateCcw className="w-4 h-4" />
                Reload Application
              </button>
              
              <button
                onClick={() => {
                  this.setState({ hasError: false, error: null });
                  window.location.href = '/';
                }}
                className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-3.5 px-6 rounded-full cursor-pointer transition-all"
              >
                <Home className="w-4 h-4" />
                Go to Homepage
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
