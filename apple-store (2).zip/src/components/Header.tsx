import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../store';
import { Search, ShoppingBag, Heart, User, Menu, X, LogOut, ShieldCheck, ShoppingCart, Sun, Moon } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR } from '../utils/currency';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  currentView: string;
  setView: (view: string, params?: any) => void;
}

type DropdownState = 'idle' | 'search' | 'cart' | 'account' | 'wishlist';

export default function Header({ currentView, setView }: HeaderProps) {
  const { 
    user, 
    logout, 
    cart, 
    wishlist, 
    products, 
    fetchProducts, 
    searchQuery, 
    selectedCategory,
    isDarkMode,
    toggleDarkMode
  } = useStore();

  const [dropdownState, setDropdownState] = useState<DropdownState>('idle');
  const [localQuery, setLocalQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Synchronize local search query
  useEffect(() => {
    setLocalQuery(searchQuery);
  }, [searchQuery]);

  // Click outside to collapse active dropdown menu
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownState('idle');
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + (item.product.price * (1 - item.product.discount / 100)) * item.quantity, 0);

  // Filter products for dropdown autocomplete
  const suggestions = localQuery.trim()
    ? products.filter(p => p.name.toLowerCase().includes(localQuery.toLowerCase())).slice(0, 5)
    : products.slice(0, 4);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchProducts(localQuery, selectedCategory);
    setView('collection');
    setDropdownState('idle');
  };

  const handleSuggestionClick = (productId: string) => {
    setView('details', { id: productId });
    setDropdownState('idle');
  };

  const toggleDropdown = (state: DropdownState) => {
    setDropdownState(dropdownState === state ? 'idle' : state);
  };

  // Nav categories triggers
  const handleNavCategory = (catKey: string) => {
    fetchProducts('', catKey);
    setView('collection');
    setDropdownState('idle');
    setMobileMenuOpen(false);
  };

  const handleOffersNav = () => {
    // scroll to active offers section or filter by discounts
    fetchProducts('', ''); // reset category
    setView('collection');
    setDropdownState('idle');
    setMobileMenuOpen(false);
    // Add artificial delay to let page mount, then look for items with discounts or filter on the UI
  };

  const handleNewArrivalsNav = () => {
    fetchProducts('', ''); // show all
    setView('collection');
    setDropdownState('idle');
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 w-full z-[999999] bg-white/80 dark:bg-[#111112]/80 backdrop-blur-xl border-b border-zinc-200/50 dark:border-white/10 shadow-md rounded-b-2xl transition-colors duration-300">
      <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-center">
        
        {/* Equally spaced horizontal menu with all 6 required icons centered horizontally */}
        <nav className="flex items-center justify-between w-full max-w-xl text-zinc-800 dark:text-zinc-200">
          
          {/* 1. Home Button ( Logo/Wordmark) with Premium Moving Light Effect */}
          <button
            onClick={() => { setView('home'); setDropdownState('idle'); setMobileMenuOpen(false); }}
            className={`group relative overflow-hidden flex items-center gap-2 px-3 py-1.5 rounded-full transition-all duration-350 hover:bg-zinc-100/50 dark:hover:bg-white/5 border border-transparent hover:border-zinc-200/40 dark:hover:border-white/5 ${currentView === 'home' && dropdownState === 'idle' && !mobileMenuOpen ? 'text-[#8B5CF6] dark:text-[#A78BFA]' : ''}`}
            title="Home"
          >
            {/* Embedded modular CSS for absolute 60fps buttery-smooth keyframe animation */}
            <style>{`
              @keyframes premiumLogoGlow {
                0%, 100% {
                  filter: drop-shadow(0 0 3px rgba(139, 92, 246, 0.25)) drop-shadow(0 1px 1px rgba(0, 0, 0, 0.1));
                }
                50% {
                  filter: drop-shadow(0 0 8px rgba(167, 139, 250, 0.55)) drop-shadow(0 1px 2px rgba(167, 139, 250, 0.25));
                }
              }
              .animate-premium-logo {
                animation: premiumLogoGlow 3.5s ease-in-out infinite;
              }
              .glass-shine-sheen {
                background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.18) 50%, rgba(255,255,255,0) 100%);
              }
              .dark .glass-shine-sheen {
                background: linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0) 100%);
              }
            `}</style>

            {/* Static glass sheen reflection overlay that glides across button pill on hover */}
            <div className="absolute inset-0 glass-shine-sheen -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out pointer-events-none" />

            {/* Premium Multi-Layer Visual Logo */}
            <div className="relative flex items-center justify-center">
              <svg className="w-5 h-5 text-current relative overflow-visible animate-premium-logo" viewBox="0 0 24 24">
                <defs>
                  {/* Apple shine gradient - sweeps clean white and high-end lavender purple lights */}
                  <linearGradient id="apple-premium-shine" x1="-1.5" y1="0" x2="-0.5" y2="0" gradientTransform="rotate(25 0.5 0.5)">
                    <stop offset="0%" stopColor="currentColor" stopOpacity="1" />
                    <stop offset="30%" stopColor="currentColor" stopOpacity="1" />
                    {/* Beam core edges - soft lavender purple */}
                    <stop offset="42%" stopColor="#C084FC" />
                    {/* Premium reflective peak - bright pure white */}
                    <stop offset="50%" stopColor="#FFFFFF" />
                    {/* Beam back edge */}
                    <stop offset="58%" stopColor="#C084FC" />
                    <stop offset="70%" stopColor="currentColor" stopOpacity="1" />
                    <stop offset="100%" stopColor="currentColor" stopOpacity="1" />
                    
                    {/* Seamless 60FPS browser-native attributes loop (3.5s duration) */}
                    <animate 
                      attributeName="x1" 
                      from="-1.5" 
                      to="1.5" 
                      dur="3.5s" 
                      repeatCount="indefinite" 
                    />
                    <animate 
                      attributeName="x2" 
                      from="-0.5" 
                      to="2.5" 
                      dur="3.5s" 
                      repeatCount="indefinite" 
                    />
                  </linearGradient>
                </defs>
                
                {/* SVG path loaded matching authentic Apple geometry with active color state filled */}
                <path 
                  d="M18.71,19.5c-.83,1.24-1.71,2.45-3.05,2.47-1.34,.03-1.77-.79-3.29-.79-1.53,0-2,.77-3.27,.82-1.31,.05-2.3-1.32-3.14-2.53C4.25,17,2.94,12.45,4.7,9.39c.87-1.52,2.43-2.48,4.12-2.51,1.28-.02,2.5,.87,3.29,.87,.78,0,2.26-1.07,3.81-.91,1.54,.06,2.7,.61,3.46,1.73C15.4,11.04,14.8,15.78,18.71,19.5M15.97,4.17c1.39-1.68,1.35-3.22,1.35-3.22,0,0-1.42,.02-3.04,1.92-1.12,1.31-1.28,2.7-1.28,2.7,0,0,1.52,.12,2.97-1.4" 
                  fill="url(#apple-premium-shine)"
                />
              </svg>
            </div>
            
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5 group-hover:text-purple-600 dark:group-hover:text-purple-300 transition-colors">Home</span>
          </button>

          {/* 2. Search trigger */}
          <button
            onClick={() => { toggleDropdown('search'); setMobileMenuOpen(false); }}
            className={`group flex items-center gap-1.5 p-2 transition-all hover:text-[#8B5CF6] ${dropdownState === 'search' ? 'text-[#8B5CF6]' : ''}`}
            title="Search Products"
          >
            <Search className="w-5 h-5" />
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5">Search</span>
          </button>

          {/* 3. Bag / Cart trigger */}
          <button
            onClick={() => { toggleDropdown('cart'); setMobileMenuOpen(false); }}
            className={`group flex items-center gap-1.5 p-2 transition-all hover:text-[#8B5CF6] relative ${dropdownState === 'cart' ? 'text-[#8B5CF6]' : ''}`}
            title="Shopping cart bag"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-zinc-950 dark:bg-white dark:text-zinc-950 text-white font-mono text-[8px] font-extrabold rounded-full px-1 min-w-3.5 h-3.5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5 font-sans">Bag</span>
          </button>

          {/* 4. Wishlist trigger */}
          <button
            onClick={() => { toggleDropdown('wishlist'); setMobileMenuOpen(false); }}
            className={`group flex items-center gap-1.5 p-2 transition-all hover:text-rose-500 relative ${dropdownState === 'wishlist' ? 'text-rose-500' : ''}`}
            title="Shortlists watchlist"
          >
            <div className="relative">
              <Heart className={`w-5 h-5 ${wishlist.length > 0 ? 'fill-rose-500/15 text-rose-500' : ''}`} />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full" />
              )}
            </div>
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5">Wishlist</span>
          </button>

          {/* 5. User Account / Profile trigger */}
          <button
            onClick={() => {
              if (user) {
                toggleDropdown('account');
              } else {
                setView('signup');
              }
              setMobileMenuOpen(false);
            }}
            className={`group flex items-center gap-1.5 p-2 transition-all hover:text-[#8B5CF6] ${dropdownState === 'account' ? 'text-[#8B5CF6]' : ''}`}
            title="Your account"
          >
            {user ? (
              <span className="w-5 h-5 bg-[#8B5CF6]/15 hover:bg-[#8B5CF6]/20 border border-[#8B5CF6]/30 rounded-full flex items-center justify-center text-[9px] font-extrabold font-mono text-[#8B5CF6] uppercase">
                {user.name.substring(0, 2)}
              </span>
            ) : (
              <User className="w-5 h-5" />
            )}
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5">Account</span>
          </button>

          {/* 6. Menu trigger */}
          <button
            onClick={() => { setMobileMenuOpen(!mobileMenuOpen); setDropdownState('idle'); }}
            className={`group flex items-center gap-1.5 p-2 transition-all hover:text-[#8B5CF6] ${mobileMenuOpen ? 'text-[#8B5CF6]' : ''}`}
            title="Explore categories"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            <span className="text-[10px] uppercase font-black tracking-widest hidden xs:inline mt-0.5">Menu</span>
          </button>

          {/* Thin border spacer & Dark Mode Switcher */}
          <div className="h-5 w-[1px] bg-zinc-200 dark:bg-white/10 hidden sm:block mx-1" />

          <button 
            onClick={() => toggleDarkMode()} 
            className="p-1.5 hover:text-[#8B5CF6] transition-colors rounded-full"
            title={isDarkMode ? "Light mode appearance" : "Dark mode appearance"}
          >
            {isDarkMode ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </button>

        </nav>
      </div>

      {/* DROPDOWN EXPANSIONS IN SINGLE CARD WITH ABSOLUTE OVERLAY */}
      <AnimatePresence>
        {dropdownState !== 'idle' && (
          <div className="absolute top-14 left-0 right-0 w-full bg-white/95 dark:bg-[#06060c]/98 backdrop-blur-2xl border-b border-zinc-200 dark:border-white/10 shadow-2xl z-50 px-4 py-5" ref={dropdownRef}>
            <div className="max-w-4xl mx-auto text-xs text-zinc-800 dark:text-zinc-200">
              
              {/* DROPDOWN CATEGORY: SEARCH BAR FIELD */}
              {dropdownState === 'search' && (
                <div className="space-y-4">
                  <form onSubmit={handleSearchSubmit} className="flex items-center bg-zinc-50 dark:bg-zinc-900/40 border border-zinc-200 dark:border-white/10 rounded-xl px-4 py-2.5">
                    <Search className="w-4 h-4 text-zinc-400 mr-2 shrink-0" />
                    <input 
                      type="text" 
                      placeholder="Type to find iPhones, iPads, MacBooks, AirPods, Watches, Accessories..."
                      className="border-none bg-transparent outline-hidden text-sm w-full font-sans text-[#1d1d1f] dark:text-white placeholder-zinc-450 focus:ring-0 focus:outline-hidden"
                      value={localQuery}
                      onChange={(e) => setLocalQuery(e.target.value)}
                      autoFocus
                    />
                    {localQuery && (
                      <X className="w-4 h-4 text-zinc-400 cursor-pointer hover:text-red-500" onClick={() => setLocalQuery('')} />
                    )}
                  </form>

                  <div className="space-y-1 bg-zinc-50/50 dark:bg-zinc-950/20 p-2.5 rounded-xl border border-zinc-100 dark:border-white/5">
                    <p className="text-[10px] font-bold text-zinc-400 dark:text-[#0ef0ff] uppercase tracking-widest px-2 py-1 font-mono">
                      {localQuery.trim() ? 'Matched Apple Catalog' : 'Quick Suggestions'}
                    </p>
                    {suggestions.length === 0 ? (
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs py-2 px-2">No models found with "{localQuery}"</p>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {suggestions.map((p) => (
                          <div 
                            key={p.id}
                            onClick={() => handleSuggestionClick(p.id)}
                            className="flex items-center gap-3 p-2 bg-white dark:bg-zinc-900/30 hover:bg-[#0ef0ff]/5 dark:hover:bg-[#0ef0ff]/10 rounded-lg cursor-pointer transition-all border border-zinc-100 dark:border-white/5 hover:border-[#0ef0ff]/30"
                          >
                            <img 
                              src={p.images[0]} 
                              alt={p.name} 
                              className="w-10 h-10 rounded-md object-contain shrink-0 border border-zinc-100 dark:border-white/5 bg-white dark:bg-zinc-950/45 p-1"
                              referrerPolicy="no-referrer"
                              onError={(e) => {
                                  e.currentTarget.onerror = null;
                                  e.currentTarget.src = getFallbackImage(p.name, p.colors[0]);
                              }}
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-xs font-bold text-[#1d1d1f] dark:text-white truncate">{p.name}</p>
                              <p className="text-[10.5px] text-[#8B5CF6] font-bold font-mono">{formatINR(p.price * (1 - p.discount / 100))}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* DROPDOWN CATEGORY: CART SLIDE PREVIEW */}
              {dropdownState === 'cart' && (
                <div>
                  <div className="flex justify-between items-center mb-3 pb-2 border-b border-zinc-100 dark:border-white/10 animate-fade-in">
                    <span className="font-extrabold text-[#1d1d1f] dark:text-white uppercase tracking-wider font-mono text-[11px]">Shopping Cart Bag ({cartCount})</span>
                    <span className="text-[#8B5CF6] font-black font-mono text-sm">{formatINR(cartTotal)}</span>
                  </div>

                  {cart.length === 0 ? (
                    <div className="text-center py-6 text-zinc-400 dark:text-zinc-500 font-medium">Your Shopping Bag is empty.</div>
                  ) : (
                    <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                      {cart.map((item, idx) => {
                        const finalPrice = item.product.price * (1 - item.product.discount / 100);
                        return (
                          <div key={idx} className="flex gap-3 bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-150 dark:border-white/5 p-2 rounded-xl items-center">
                            <img 
                              src={item.product.images[0]} 
                              alt={item.product.name}
                              className="w-10 h-10 rounded-lg object-contain bg-white dark:bg-zinc-950 p-1 border border-zinc-150 dark:border-white/5"
                            />
                            <div className="flex-1 min-w-0">
                              <h5 className="font-bold text-xs text-[#1d1d1f] dark:text-white truncate">{item.product.name}</h5>
                              <p className="text-[10px] text-zinc-500 dark:text-zinc-400 font-semibold">{item.selectedColor} • {item.selectedStorage} • Qty {item.quantity}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <p className="text-xs font-black text-[#8B5CF6] font-mono">{formatINR(finalPrice * item.quantity)}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="mt-4 pt-3 border-t border-zinc-150 dark:border-white/10 flex items-center justify-between">
                    <span className="text-zinc-500 dark:text-zinc-450 text-[10px] font-mono">CODE: <b className="text-pink-500 dark:text-pink-400">COUPON10</b> (10% off checkout)</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setDropdownState('idle')}
                        className="px-3.5 py-1.5 text-zinc-500 hover:text-zinc-950 dark:hover:text-white rounded-lg font-bold"
                      >
                        Keep Browsing
                      </button>
                      <button
                        onClick={() => { setView('cart'); setDropdownState('idle'); }}
                        className="px-5 py-2 bg-black hover:scale-[1.02] text-white rounded-full text-[10px] uppercase font-black tracking-wider transition-all cursor-pointer shadow-sm"
                      >
                        Checkout Order
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* DROPDOWN CATEGORY: WISHLIST PREVIEW */}
              {dropdownState === 'wishlist' && (
                <div>
                  <div className="flex justify-between items-center mb-3 pb-2 border-b border-zinc-100 dark:border-white/5">
                    <span className="font-extrabold text-[#1d1d1f] dark:text-white uppercase tracking-wider font-mono text-[11px]">Favorited Watchlist ({wishlist.length})</span>
                    <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
                  </div>

                  {wishlist.length === 0 ? (
                    <div className="text-center py-6 text-zinc-400 dark:text-zinc-500 font-medium font-sans">Your watchlist is completely vacant.</div>
                  ) : (
                    <div className="space-y-2 max-h-[220px] overflow-y-auto">
                      {wishlist.map((w, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => { setView('details', { id: w.id }); setDropdownState('idle'); }}
                          className="flex gap-3 bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-150 dark:border-white/5 p-2 rounded-xl items-center cursor-pointer hover:bg-zinc-100 dark:hover:bg-zinc-900/40 transition-colors"
                        >
                          <img 
                            src={w.images[0]} 
                            alt={w.name}
                            className="w-8 h-8 rounded bg-white dark:bg-zinc-950 object-contain p-0.5 border border-zinc-150 dark:border-white/5"
                          />
                          <span className="text-xs text-[#1d1d1f] dark:text-white font-extrabold flex-1 truncate">{w.name}</span>
                          <span className="text-xs text-[#8B5CF6] font-black font-mono">{formatINR(w.price * (1 - w.discount / 100))}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-4 pt-3 border-t border-zinc-150 dark:border-white/10 flex justify-end gap-2">
                    <button
                      onClick={() => setDropdownState('idle')}
                      className="px-3 py-1.5 text-zinc-500 hover:text-zinc-950 dark:hover:text-white font-bold"
                    >
                      Close Window
                    </button>
                    <button
                      onClick={() => { setView('wishlist'); setDropdownState('idle'); }}
                      className="px-4 py-2 bg-black hover:scale-[1.02] text-white rounded-full font-bold text-xs"
                    >
                      Open Wishlist Manager
                    </button>
                  </div>
                </div>
              )}

              {/* DROPDOWN CATEGORY: ACCOUNT SERVICES */}
              {dropdownState === 'account' && (
                <div>
                  {user ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-200 dark:border-white/10 p-3.5 rounded-xl flex items-center justify-between">
                        <div className="min-w-0">
                          <p className="text-[10px] text-[#8B5CF6] font-bold uppercase font-mono">Authorized Profile</p>
                          <h4 className="text-sm font-bold text-[#1d1d1f] dark:text-white mt-0.5 truncate">{user.name}</h4>
                          <p className="text-xs text-zinc-550 dark:text-zinc-400 truncate">{user.email}</p>
                        </div>
                        <User className="w-7 h-7 text-[#8B5CF6] bg-[#EFE7FF] p-1.5 rounded-full border border-violet-100 shrink-0" />
                      </div>

                      <div className="flex flex-col justify-between space-y-2">
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => { setView('account'); setDropdownState('idle'); }}
                            className="py-2.5 bg-zinc-900 dark:bg-zinc-800 hover:bg-black dark:hover:bg-zinc-750 border dark:border-white/10 rounded-lg text-center text-xs text-white font-bold transition-all"
                          >
                            My Dashboard
                          </button>
                          {user.role === 'admin' && (
                            <button
                              onClick={() => { setView('admin'); setDropdownState('idle'); }}
                              className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-center text-xs font-bold transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                            >
                              <ShieldCheck className="w-3.5 h-3.5 inline mr-1" />
                              Admin Dashboard
                            </button>
                          )}
                        </div>
                        <div className="flex justify-end pt-1">
                          <button
                            onClick={() => { logout(); setView('home'); setDropdownState('idle'); }}
                            className="flex items-center gap-1.5 px-3 py-1 bg-red-50 dark:bg-red-950/20 hover:bg-red-100 dark:hover:bg-red-900/30 text-red-650 dark:text-red-400 border border-red-200 dark:border-red-900/40 rounded-md font-bold transition-all text-[10px]"
                          >
                            <LogOut className="w-3 h-3" />
                            Sign Out Account
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs mb-4 font-semibold">Login to sync your shopping orders and save preferences safely.</p>
                      <div className="flex flex-col gap-2">
                        <button
                          onClick={() => { setView('signup'); setDropdownState('idle'); }}
                          className="w-full px-4 py-2.5 bg-[#8B5CF6] hover:bg-[#7C3AED] hover:scale-[1.01] font-bold rounded-xl text-white text-xs transition-all shadow-sm"
                        >
                          Create your Apple ID
                        </button>
                        <button
                          onClick={() => { setView('login'); setDropdownState('idle'); }}
                          className="w-full px-4 py-2 border border-zinc-200 hover:bg-zinc-50 dark:border-white/10 dark:hover:bg-zinc-900 rounded-xl font-bold text-zinc-700 dark:text-zinc-300 text-xs transition-all animate-none"
                        >
                          Already have an ID? Sign In
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>
          </div>
        )}
      </AnimatePresence>

      {/* EXPANDED SYSTEM MENU CATEGORY DRAWER */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="absolute top-14 left-0 right-0 w-full bg-white/95 dark:bg-[#111112]/95 backdrop-blur-2xl border-b border-zinc-200 dark:border-white/10 shadow-2xl z-50 transition-colors"
          >
            <div className="max-w-4xl mx-auto px-6 py-8">
              <p className="text-[10px] font-bold text-zinc-400 dark:text-zinc-500 uppercase tracking-widest mb-6 font-mono">
                Explore Apple Store Ecosystem
              </p>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                
                {/* Category 1: iPhone */}
                <button 
                  onClick={() => handleNavCategory('iphones')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">📱</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">iPhone</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Explore Latest Handsets</span>
                </button>

                {/* Category 2: Mac */}
                <button 
                  onClick={() => handleNavCategory('macbooks')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">💻</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">MacBook</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Laptops & Workstations</span>
                </button>

                {/* Category 3: iPad */}
                <button 
                  onClick={() => handleNavCategory('ipads')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">平板</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">iPad</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Multitouch Notebooks</span>
                </button>

                {/* Category 4: Watches */}
                <button 
                  onClick={() => handleNavCategory('watches')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">⌚</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">Apple Watch</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Smart Health Fitness</span>
                </button>

                {/* Category 5: AirPods */}
                <button 
                  onClick={() => handleNavCategory('airpods')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">🎧</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">AirPods</span>
                  <span className="text-[10px] text-zinc-400 mt-1">High-Fidelity Audio</span>
                </button>

                {/* Category 6: Accessories */}
                <button 
                  onClick={() => handleNavCategory('accessories')}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">⚡</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">Accessories</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Cases, Chargers & Pens</span>
                </button>

                {/* Menu Item 7: Compare */}
                <button 
                  onClick={() => { setView('compare'); setMobileMenuOpen(false); }}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-violet-50 dark:hover:bg-zinc-800/60 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-violet-200 transition-all text-left"
                >
                  <span className="text-xl mb-1">⚖️</span>
                  <span className="font-bold text-sm text-[#1d1d1f] dark:text-white">Compare Tools</span>
                  <span className="text-[10px] text-zinc-400 mt-1">Side-by-side specs</span>
                </button>

                {/* Menu Item 8: Offers */}
                <button 
                  onClick={handleOffersNav}
                  className="flex flex-col items-start p-4 bg-zinc-50 dark:bg-zinc-900/40 hover:bg-[#0ef0ff]/5 dark:hover:bg-cyan-950/10 rounded-2xl border border-zinc-150 dark:border-white/5 hover:border-cyan-300 transition-all text-left"
                >
                  <span className="text-xl mb-1 font-mono text-cyan-400 font-bold">🏷️</span>
                  <span className="font-bold text-sm text-cyan-600 dark:text-[#0ef0ff]">Special Offers</span>
                  <span className="text-[10px] text-cyan-500/70 dark:text-cyan-400/70 mt-1">Check current bundle pricing</span>
                </button>

              </div>

              <div className="mt-8 pt-6 border-t border-zinc-150 dark:border-white/5 flex flex-wrap justify-between items-center gap-4 text-xs">
                <div className="flex gap-4">
                  <button onClick={() => { setView('about'); setMobileMenuOpen(false); }} className="text-zinc-500 hover:text-zinc-950 dark:hover:text-white font-medium">About Store</button>
                  <span className="text-zinc-200 dark:text-white/10">|</span>
                  <button onClick={() => { setView('contact'); setMobileMenuOpen(false); }} className="text-zinc-500 hover:text-zinc-950 dark:hover:text-white font-medium">Contact Help</button>
                </div>
                <p className="text-[11px] text-zinc-400">© 2026 iStore. All rights reserved.</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
