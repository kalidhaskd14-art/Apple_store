import React, { useState, useRef, useEffect } from 'react';
import { RotateCw, ShieldAlert, Sparkles, Play, Pause } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';

interface ThreeSixtyViewerProps {
  images: string[];
  productName: string;
  category: string;
}

export default function ThreeSixtyViewer({ images, productName, category }: ThreeSixtyViewerProps) {
  // Let's ensure we have a robust list of 5 images representing 360 angles by filling if missing
  const frames: string[] = [...images];
  if (frames.length < 5) {
    // Generate supplementary frames from fallback images to ensure visual cycle is smooth
    while (frames.length < 5) {
      frames.push(frames[frames.length - 1] || 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&q=80&w=800');
    }
  }

  const [frameIdx, setFrameIdx] = useState(0);
  const [isRotating, setIsRotating] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [useAutoSpin, setUseAutoSpin] = useState(false);
  const [spinSpeed, setSpinSpeed] = useState(250); // ms per frame

  const dragStartX = useRef(0);
  const dragStartIdx = useRef(0);

  // Auto spin mechanics
  useEffect(() => {
    if (!useAutoSpin) return;
    const interval = setInterval(() => {
      setFrameIdx((p) => (p + 1) % frames.length);
    }, spinSpeed);
    return () => clearInterval(interval);
  }, [useAutoSpin, spinSpeed, frames.length]);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setDragActive(true);
    setUseAutoSpin(false); // Stop auto spin upon direct touch interaction
    dragStartX.current = e.clientX;
    dragStartIdx.current = frameIdx;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!dragActive) return;
    const diff = e.clientX - dragStartX.current;
    const sensitivity = 15; // Pixels drag per frame swap
    const offset = Math.floor(diff / sensitivity);
    
    // Cycle backward/forward through matching frame structures
    let nextIdx = (dragStartIdx.current - offset) % frames.length;
    if (nextIdx < 0) nextIdx += frames.length;
    
    setFrameIdx(nextIdx);
  };

  const handleMouseUpOrLeave = () => {
    setDragActive(false);
  };

  // Mobile Touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    setDragActive(true);
    setUseAutoSpin(false);
    dragStartX.current = e.touches[0].clientX;
    dragStartIdx.current = frameIdx;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!dragActive) return;
    const diff = e.touches[0].clientX - dragStartX.current;
    const sensitivity = 12;
    const offset = Math.floor(diff / sensitivity);

    let nextIdx = (dragStartIdx.current - offset) % frames.length;
    if (nextIdx < 0) nextIdx += frames.length;

    setFrameIdx(nextIdx);
  };

  const handleTouchEnd = () => {
    setDragActive(false);
  };

  return (
    <div 
      className="bg-white border border-violet-100/60 rounded-[32px] p-6 shadow-[0_12px_40px_rgba(139,92,246,0.04)] relative overflow-hidden group select-none text-[#1D1D1F]"
      id={`threesixty-${productName.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="absolute top-4 left-4 z-10 flex flex-wrap gap-1.5 pointer-events-none">
        <span className="bg-[#8B5CF6]/10 text-[#8B5CF6] text-[9px] font-mono font-black px-2.5 py-1 rounded-full uppercase tracking-widest flex items-center gap-1">
          <RotateCw className="w-3 h-3 animate-spin" />
          Interactive 360° Studio View
        </span>
        <span className="bg-emerald-500/15 text-emerald-600 text-[9px] font-mono font-black px-2.5 py-1 rounded-full uppercase tracking-widest flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          M4 Pro Render
        </span>
      </div>

      {/* Embedded canvas viewport box */}
      <div 
        className={`w-full h-80 flex items-center justify-center cursor-grab bg-gradient-to-b from-[#FBF9FF] to-[#FAF8FF] rounded-2xl relative border border-purple-50/40 p-4 transition-all duration-300 ${dragActive ? 'cursor-grabbing border-violet-200/50 bg-[#F4EEFF]' : ''}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <img 
          src={frames[frameIdx]} 
          alt={`${productName} Angle ${frameIdx + 1}`} 
          className="max-h-72 object-contain filter drop-shadow-[0_15px_30px_rgba(139,92,246,0.12)] transition-transform duration-300 pointer-events-none select-none hover:scale-103"
          referrerPolicy="no-referrer"
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = getFallbackImage(productName, '#9333EA');
          }}
        />

        {/* Dynamic Rotation Compass overlay HUD */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-md border border-violet-100/40 py-1.5 px-3.5 rounded-full text-[9px] font-bold text-gray-500 font-mono tracking-widest flex items-center gap-2 shadow-xs transition-opacity duration-300">
          <span>LATERAL ROT: <b>{(frameIdx * (360 / frames.length)).toFixed(0)}°</b></span>
          <span className="text-violet-200">|</span>
          <span>VAL: <b>FRAME {frameIdx + 1}/{frames.length}</b></span>
        </div>

        {/* Touch indicator overlay floating handle */}
        <div className="absolute right-4 bottom-4 w-7 h-7 bg-white/80 border border-violet-50 rounded-full flex items-center justify-center text-xs text-violet-500 animate-pulse hidden md:flex" title="Drag horizontal to spin model">
          ↔
        </div>
      </div>

      {/* Control sliders and toggles */}
      <div className="mt-5 pt-4 border-t border-violet-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setUseAutoSpin(!useAutoSpin)}
            className={`px-4.5 py-2.5 text-[10.5px] font-black uppercase tracking-wider rounded-full transition-all flex items-center gap-1.5 border ${
              useAutoSpin 
              ? 'bg-[#8B5CF6] text-white border-transparent shadow-sm' 
              : 'bg-[#EFE7FF] hover:bg-[#E2D2FF] text-[#1D1D1F] border-violet-100/40'
            }`}
          >
            {useAutoSpin ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-white" />
                Pause Auto-Spin
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                Auto Orbit Spin
              </>
            )}
          </button>

          <span className="text-[10px] text-gray-400 font-mono font-bold tracking-wide hidden sm:inline">
            💡 Tap or drag directly to inspect angles manually
          </span>
        </div>

        {/* Rotation speed adjustment slide */}
        {useAutoSpin && (
          <div className="flex items-center gap-2 bg-[#FBF9FF] p-2 rounded-xl border border-violet-50 shadow-4xs shrink-0">
            <span className="text-[9.5px] font-bold uppercase tracking-wider text-gray-500 shrink-0 font-mono">Orbit Speed:</span>
            <input 
              type="range" 
              className="w-24 h-1 bg-violet-100 rounded-lg appearance-none cursor-pointer accent-[#8B5CF6]"
              min="100" 
              max="650" 
              step="50"
              value={spinSpeed}
              onChange={(e) => setSpinSpeed(Number(e.target.value))}
            />
            <span className="text-[9px] font-bold text-[#8B5CF6] font-mono w-10 text-right">{spinSpeed}ms</span>
          </div>
        )}

      </div>
    </div>
  );
}
