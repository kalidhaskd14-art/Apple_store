import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { 
  User, MapPin, Package, Clock, Truck, CheckCircle2, 
  HelpCircle, ChevronRight, Plus, Trash2, Printer, Map, Phone,
  CreditCard, Bell, Key, RefreshCcw, Sparkles
} from 'lucide-react';
import { Address, Order } from '../types';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR } from '../utils/currency';

interface DashboardViewProps {
  setView: (view: string, params?: any) => void;
}

type TabType = 'orders' | 'addresses' | 'profile' | 'notifications' | 'support';

export default function DashboardView({ setView }: DashboardViewProps) {
  const { 
    user, 
    orders, 
    fetchMyOrders, 
    ordersLoading,
    addAddress,
    deleteAddress,
    cancelUserOrder,
    updateProfile,
    isDarkMode
  } = useStore();

  const [activeTab, setActiveTab] = useState<TabType>('orders');
  
  // Invoice state modal
  const [activeInvoice, setActiveInvoice] = useState<Order | null>(null);

  // Cancellation, Returns, and Edit profile states
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancelErrors, setCancelErrors] = useState<Record<string, string>>({});
  const [profileName, setProfileName] = useState(user?.name || '');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [profileSuccess, setProfileSuccess] = useState(false);

  // Returns lodging state
  const [returnedOrders, setReturnedOrders] = useState<Record<string, 'requested' | 'approved'>>({});

  // Address Form State
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [addrName, setAddrName] = useState('');
  const [addrPhone, setAddrPhone] = useState('');
  const [addrLine1, setAddrLine1] = useState('');
  const [addrLine2, setAddrLine2] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrState, setAddrState] = useState('');
  const [addrZip, setAddrZip] = useState('');
  const [addrCountry, setAddrCountry] = useState('India');
  const [addrDefault, setAddrDefault] = useState(true);

  useEffect(() => {
    fetchMyOrders();
    if (user) {
      setProfileName(user.name);
    }
  }, [user]);

  const handleCancelOrder = async (orderId: string) => {
    setCancelErrors(prev => ({ ...prev, [orderId]: '' }));
    setCancellingId(orderId);
    const res = await cancelUserOrder(orderId);
    setCancellingId(null);
    if (!res.success) {
      setCancelErrors(prev => ({ ...prev, [orderId]: res.error || 'Cancellation failed. Please contact support.' }));
    }
  };

  const handleReturnRequest = (orderId: string) => {
    setReturnedOrders(prev => ({ ...prev, [orderId]: 'requested' }));
    setTimeout(() => {
      setReturnedOrders(prev => ({ ...prev, [orderId]: 'approved' }));
    }, 2500);
  };

  const handleAddressSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrName || !addrLine1 || !addrCity) return;

    const payload = {
      name: addrName,
      phone: addrPhone,
      line1: addrLine1,
      line2: addrLine2 || undefined,
      city: addrCity,
      state: addrState,
      postalCode: addrZip,
      country: addrCountry,
      isDefault: addrDefault
    };

    const ok = await addAddress(payload);
    if (ok) {
      setShowAddressForm(false);
      setAddrName('');
      setAddrPhone('');
      setAddrLine1('');
      setAddrLine2('');
      setAddrCity('');
      setAddrState('');
      setAddrZip('');
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) return;
    setIsUpdatingProfile(true);
    setProfileSuccess(false);
    const success = await updateProfile(profileName);
    setIsUpdatingProfile(false);
    if (success) {
      setProfileSuccess(true);
      setTimeout(() => setProfileSuccess(false), 3000);
    }
  };

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto my-16 text-center animate-fade-in px-4">
        <h2 className="text-2xl font-black text-zinc-900 dark:text-white font-mono uppercase tracking-widest">Access Revoked</h2>
        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2">Please sign in to access your personal secure dashboard.</p>
        <button onClick={() => setView('login')} className="glowing-cyan-btn mt-6 text-xs font-black px-6 py-2 rounded-full">Sign In Now</button>
      </div>
    );
  }

  // Simulated live notifications
  const notifications = [
    { id: 1, title: 'Order Dispatched', desc: 'Your iPhone titanium order package is with courier associates.', time: '2 hours ago', icon: Truck, color: 'text-sky-500 bg-sky-500/10' },
    { id: 2, title: 'Price Drop Watchpoint', desc: 'Item "AirPods Max Pro" in your watchlist dropped 5% in valuation!', time: '1 day ago', icon: Bell, color: 'text-indigo-500 bg-indigo-500/10' },
    { id: 3, title: 'Warranty Certified', desc: 'Your Apple Watch Series 10 dynamic care pack is active.', time: '3 days ago', icon: CheckCircle2, color: 'text-emerald-500 bg-emerald-500/10' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="dashboard-view-main">
      
      {/* User Dashboard Profile Header Banner */}
      <div className="relative overflow-hidden luxury-glass-card rounded-3xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 border border-zinc-200 dark:border-white/10">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="flex items-center gap-4 z-10">
          <div className="w-16 h-16 rounded-full bg-zinc-900 dark:bg-zinc-800 text-white flex items-center justify-center text-xl font-black uppercase tracking-widest border border-zinc-250 dark:border-white/15 shadow-[0_0_15px_rgba(14,240,255,0.1)]">
            {user.name.split(' ').map(n => n[0]).join('')}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white font-sans">{user.name}</h2>
              {user.role === 'admin' && (
                <span className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-[9px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider font-mono">ADMIN PRIVILEGE</span>
              )}
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium font-mono mt-0.5">{user.email}</p>
            <p className="text-[10px] text-zinc-400 font-mono mt-1">Authorized ID: {user.id}</p>
          </div>
        </div>
        <div className="flex gap-3 z-10">
          <button 
            onClick={() => setView('collection')} 
            className="glowing-cyan-btn text-xs py-2 px-5 rounded-full font-black uppercase tracking-wider"
          >
            Continue Shopping
          </button>
        </div>
      </div>

      {/* Tabs navigation list */}
      <div className="flex border-b border-zinc-200 dark:border-white/10 mb-8 overflow-x-auto gap-2 sm:gap-6 scrollbar-none" id="dashboard-tabs">
        <button 
          onClick={() => setActiveTab('orders')}
          className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 px-1 transition-all flex items-center gap-1.5 shrink-0 ${activeTab === 'orders' ? 'border-zinc-900 dark:border-[#8B5CF6] text-zinc-900 dark:text-[#8B5CF6]' : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'}`}
        >
          <Package className="w-3.5 h-3.5" />
          Order Logs ({orders.length})
        </button>
        <button 
          onClick={() => setActiveTab('addresses')}
          className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 px-1 transition-all flex items-center gap-1.5 shrink-0 ${activeTab === 'addresses' ? 'border-zinc-900 dark:border-[#8B5CF6] text-zinc-900 dark:text-[#8B5CF6]' : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'}`}
        >
          <MapPin className="w-3.5 h-3.5" />
          Addresses ({user.addresses.length})
        </button>
        <button 
          onClick={() => setActiveTab('profile')}
          className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 px-1 transition-all flex items-center gap-1.5 shrink-0 ${activeTab === 'profile' ? 'border-zinc-900 dark:border-[#8B5CF6] text-zinc-900 dark:text-[#8B5CF6]' : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'}`}
        >
          <User className="w-3.5 h-3.5" />
          My Profile & Cards
        </button>
        <button 
          onClick={() => setActiveTab('notifications')}
          className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 px-1 transition-all flex items-center gap-1.5 shrink-0 relative ${activeTab === 'notifications' ? 'border-zinc-900 dark:border-[#8B5CF6] text-zinc-900 dark:text-[#8B5CF6]' : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'}`}
        >
          <Bell className="w-3.5 h-3.5" />
          Notifications
          <span className="absolute top-0 right-[-6px] w-1.5 h-1.5 rounded-full bg-red-500" />
        </button>
        <button 
          onClick={() => setActiveTab('support')}
          className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 px-1 transition-all flex items-center gap-1.5 shrink-0 ${activeTab === 'support' ? 'border-zinc-900 dark:border-[#8B5CF6] text-zinc-900 dark:text-[#8B5CF6]' : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white'}`}
        >
          <HelpCircle className="w-3.5 h-3.5" />
          Care Center
        </button>
      </div>

      {/* TAB 1: ORDER HISTORIES */}
      {activeTab === 'orders' && (
        <div className="space-y-6" id="dashboard-orders-deck">
          {ordersLoading ? (
            <div className="text-center py-10">
              <span className="w-6 h-6 border-2 border-zinc-900 dark:border-[#8B5CF6] border-t-transparent rounded-full animate-spin shrink-0 inline-block" />
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-[#06060c]/50 border border-zinc-200 dark:border-white/10 rounded-3xl">
              <Package className="w-10 h-10 text-zinc-300 dark:text-zinc-700 mx-auto mb-3" />
              <h3 className="font-extrabold text-sm text-zinc-900 dark:text-white uppercase tracking-wider font-mono">No order logs checked out yet</h3>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 max-w-xs mx-auto">Build your dynamic cart and buy your titanium iPhone models today.</p>
              <button onClick={() => setView('collection')} className="apple-btn-secondary text-[10.5px] font-bold py-2 px-4 mt-5 uppercase tracking-wider rounded-full">Browse Catalog</button>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((order) => {
                const getStep = () => {
                  switch (order.status) {
                    case 'pending': return 1;
                    case 'processing': return 2;
                    case 'shipped': return 3;
                    case 'delivered': return 4;
                    default: return 0;
                  }
                };
                const step = getStep();
                const isReturned = returnedOrders[order.id];

                return (
                  <div key={order.id} className="bg-white dark:bg-[#08080f]/40 border border-zinc-200 dark:border-white/10 rounded-3xl shadow-sm overflow-hidden" id={`client-order-${order.id}`}>
                    
                    {/* Order summary header */}
                    <div className="bg-zinc-55 dark:bg-zinc-950/40 px-6 py-4 border-b border-zinc-200 dark:border-white/15 flex flex-col sm:flex-row justify-between gap-4">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-[11px]">
                        <div>
                          <p className="text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase tracking-wider">ORDER PLACED</p>
                          <p className="font-semibold text-zinc-900 dark:text-white">{new Date(order.createdAt).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase tracking-wider">TOTAL PRICE</p>
                          <p className="font-bold text-zinc-900 dark:text-[#0ef0ff] font-mono">{formatINR(order.total)}</p>
                        </div>
                        <div>
                          <p className="text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase tracking-wider">SHIP TO</p>
                          <p className="font-semibold text-zinc-750 dark:text-zinc-300 truncate max-w-[120px]" title={order.shippingAddress.name}>
                            {order.shippingAddress.name}
                          </p>
                        </div>
                        <div>
                          <p className="text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase tracking-wider">ORDER ID</p>
                          <p className="font-bold text-indigo-500 dark:text-cyan-400 font-mono text-[10px]">{order.id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => setActiveInvoice(order)}
                          className="px-3.5 py-1.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 rounded-xl hover:border-black dark:hover:border-white transition-colors text-[10.5px] font-bold text-zinc-800 dark:text-white flex items-center gap-1.5 cursor-pointer shadow-xs"
                          title="Generate printable dynamic invoice receipt"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          Receipt Invoice
                        </button>
                      </div>
                    </div>

                    {/* Order visual tracking progress bar */}
                    {order.status !== 'cancelled' && !isReturned && (
                      <div className="px-6 py-5 border-b border-zinc-200 dark:border-white/10 bg-white/50 dark:bg-zinc-950/20" id={`timeline-tracker-${order.id}`}>
                        <div className="flex justify-between items-center relative max-w-md mx-auto py-1.5 text-center text-[10px] leading-relaxed">
                          
                          {/* Underline line */}
                          <div className="absolute left-0 right-0 h-0.5 bg-zinc-100 dark:bg-zinc-800 -z-5 top-1/2 -translate-y-1/2" />
                          <div 
                            className="absolute left-0 h-0.5 bg-zinc-900 dark:bg-[#8B5CF6] -z-5 top-1/2 -translate-y-1/2 transition-all duration-1000" 
                            style={{ width: `${((step - 1) / 3) * 100}%` }}
                          />

                          <div className="flex flex-col items-center">
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${step >= 1 ? 'bg-zinc-900 dark:bg-[#8B5CF6] text-white dark:text-black' : 'bg-gray-100 dark:bg-zinc-805 text-gray-400'}`}>
                              1
                            </span>
                            <span className={`mt-1 font-bold ${step >= 1 ? 'text-zinc-900 dark:text-white' : 'text-gray-450'}`}>Placed</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${step >= 2 ? 'bg-zinc-950 dark:bg-[#8B5CF6] text-white dark:text-black' : 'bg-gray-100 dark:bg-zinc-805 text-gray-400'}`}>
                              2
                            </span>
                            <span className={`mt-1 font-bold ${step >= 2 ? 'text-zinc-900 dark:text-white' : 'text-gray-450'}`}>Processing</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${step >= 3 ? 'bg-zinc-950 dark:bg-[#8B5CF6] text-white dark:text-black' : 'bg-gray-100 dark:bg-zinc-805 text-gray-400'}`}>
                              3
                            </span>
                            <span className={`mt-1 font-bold ${step >= 3 ? 'text-zinc-900 dark:text-white' : 'text-gray-450'}`}>Shipped</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[9px] ${step >= 4 ? 'bg-zinc-950 dark:bg-[#8B5CF6] text-white dark:text-black' : 'bg-gray-100 dark:bg-zinc-805 text-gray-400'}`}>
                              4
                            </span>
                            <span className={`mt-1 font-bold ${step >= 4 ? 'text-zinc-900 dark:text-white' : 'text-gray-450'}`}>Delivered</span>
                          </div>

                        </div>
                        {order.trackingNumber && order.status === 'shipped' && (
                          <div className="mt-4 text-center text-xs p-2.5 bg-sky-50 dark:bg-zinc-900/40 border border-sky-100 dark:border-[#8B5CF6]/20 rounded-xl text-zinc-900 dark:text-zinc-300 font-mono">
                            📦 Carrier assigned! Tracking serial is <code className="font-bold select-all text-indigo-650 dark:text-[#8B5CF6]">{order.trackingNumber}</code>. (Simulated delivery timeline: 2 business days)
                          </div>
                        )}
                      </div>
                    )}

                    {/* Return tracker section */}
                    {isReturned && (
                      <div className="px-6 py-4 border-b border-rose-200/40 bg-rose-500/5 text-xs text-rose-600 dark:text-rose-400 flex items-center gap-2 font-mono">
                        <RefreshCcw className={`w-4 h-4 animate-spin ${isReturned === 'approved' ? 'animate-none' : ''}`} />
                        <span>
                          <b>Return status:</b> {isReturned === 'requested' ? 'Pending Store Approval (Refund processing)' : 'Return Request Approved! Full Refund of ' + formatINR(order.total) + ' credited back to source.'}
                        </span>
                      </div>
                    )}

                    {/* Order products list */}
                    <div className="p-6 space-y-4">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4 text-xs">
                          <img 
                            src={item.image} 
                            alt={item.name} 
                            className="w-12 h-12 object-contain bg-zinc-50 dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-white/10 p-1"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              e.currentTarget.onerror = null;
                              e.currentTarget.src = getFallbackImage(item.name, item.color);
                            }}
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-extrabold text-zinc-900 dark:text-white truncate">{item.name}</p>
                            <p className="text-[10px] text-zinc-400 dark:text-zinc-500 mt-0.5">{item.color} | {item.storage}</p>
                          </div>
                          <div className="text-right font-mono">
                            <p className="font-bold text-zinc-900 dark:text-white">{formatINR(item.priceAtPurchase)}</p>
                            <p className="text-[10px] text-zinc-400 dark:text-zinc-500 mt-0.5">Quantity: {item.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Order bottom actions & status footer */}
                    <div className="px-6 py-4 bg-zinc-50/20 dark:bg-zinc-950/20 border-t border-zinc-200 dark:border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="flex flex-col text-left">
                        {order.status === 'cancelled' ? (
                          <span className="text-[10px] font-black uppercase tracking-wider text-red-650 bg-red-100/50 dark:bg-red-950/20 border border-red-200/40 py-1 px-3 rounded-full w-fit">
                            🚫 Order Cancelled
                          </span>
                        ) : isReturned ? (
                          <span className="text-[10px] font-black uppercase tracking-wider text-rose-500 bg-rose-500/10 border border-rose-500/20 py-1 px-3 rounded-full w-fit">
                            ♻️ Return Lodge
                          </span>
                        ) : order.status === 'delivered' ? (
                          <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-100/50 dark:bg-emerald-950/20 border border-emerald-250/30 py-1 px-3 rounded-full w-fit">
                            ✅ Delivered Successfully
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 bg-amber-500/10 border border-amber-500/25 py-1 px-3 rounded-full w-fit">
                            ⚙️ Status: {order.status}
                          </span>
                        )}
                        {cancelErrors[order.id] && (
                          <p className="text-[10px] text-red-500 font-semibold mt-1 max-w-[250px]">{cancelErrors[order.id]}</p>
                        )}
                      </div>

                      <div className="flex gap-2">
                        {/* Lodge Return on Delivered products */}
                        {order.status === 'delivered' && !isReturned && (
                          <button
                            onClick={() => handleReturnRequest(order.id)}
                            className="px-4 py-2 text-xs font-black bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-450 hover:bg-rose-100 border border-rose-200 dark:border-rose-900/40 rounded-xl transition-all"
                          >
                            Lodge Return Request
                          </button>
                        )}

                        {/* Cancel Order trigger */}
                        {(order.status === 'pending' || order.status === 'processing') && (
                          <button
                            onClick={() => handleCancelOrder(order.id)}
                            disabled={cancellingId === order.id}
                            className="px-4 py-2 text-xs font-bold text-red-650 hover:text-white bg-rose-50/50 dark:bg-red-950/10 hover:bg-red-600 dark:hover:bg-red-900 border border-red-100 hover:border-transparent rounded-xl transition-all duration-200 disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            {cancellingId === order.id ? (
                              <>
                                <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin shrink-0" />
                                Cancelling...
                              </>
                            ) : (
                              'Cancel Order'
                            )}
                          </button>
                        )}
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ADDRESSES */}
      {activeTab === 'addresses' && (
        <div className="space-y-6" id="dashboard-addresses-deck">
          
          <div className="flex justify-between items-center">
            <h3 className="font-extrabold text-lg text-zinc-900 dark:text-white uppercase tracking-wider font-mono">Registered Delivery Locations</h3>
            <button 
              onClick={() => setShowAddressForm(!showAddressForm)}
              className="apple-btn-secondary text-xs font-bold py-2 px-4 rounded-full flex items-center gap-1.5 cursor-pointer uppercase tracking-wider font-mono"
            >
              <Plus className="w-4 h-4" />
              {showAddressForm ? 'Cancel Form' : 'Register Address'}
            </button>
          </div>

          {/* Add Address Form */}
          {showAddressForm && (
            <form onSubmit={handleAddressSubmit} className="bg-white dark:bg-zinc-900/40 border border-zinc-200 dark:border-white/10 rounded-3xl p-6 shadow-xl space-y-4 max-w-xl animate-slide-up" id="address-form-body">
              <h4 className="font-bold text-xs text-zinc-900 dark:text-white uppercase tracking-widest border-b border-zinc-100 dark:border-white/5 pb-2 font-mono">Register Address Card</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <input 
                  type="text" 
                  placeholder="Recipient Name (e.g. John Miller)" 
                  className="apple-input col-span-2 dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrName}
                  onChange={(e) => setAddrName(e.target.value)}
                  required
                />
                <input 
                  type="text" 
                  placeholder="Contact Phone (e.g. +91 9999988888)" 
                  className="apple-input col-span-2 dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrPhone}
                  onChange={(e) => setAddrPhone(e.target.value)}
                />
                <input 
                  type="text" 
                  placeholder="Address Line 1 (Street, Apt)" 
                  className="apple-input col-span-2 dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrLine1}
                  onChange={(e) => setAddrLine1(e.target.value)}
                  required
                />
                <input 
                  type="text" 
                  placeholder="Line 2 (Suite, Floor - Optional)" 
                  className="apple-input col-span-2 dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrLine2}
                  onChange={(e) => setAddrLine2(e.target.value)}
                />
                <input 
                  type="text" 
                  placeholder="City" 
                  className="apple-input dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrCity}
                  onChange={(e) => setAddrCity(e.target.value)}
                  required
                />
                <input 
                  type="text" 
                  placeholder="State/Prov" 
                  className="apple-input dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrState}
                  onChange={(e) => setAddrState(e.target.value)}
                  required
                />
                <input 
                  type="text" 
                  placeholder="Postal Code" 
                  className="apple-input dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={addrZip}
                  onChange={(e) => setAddrZip(e.target.value)}
                  required
                />
                <input 
                  type="text" 
                  placeholder="Country" 
                  className="apple-input bg-zinc-100 dark:bg-zinc-800 border-none pointer-events-none"
                  value={addrCountry}
                  readOnly
                />
              </div>

              <div className="flex items-center gap-2 py-2">
                <input 
                  type="checkbox" 
                  id="make-def"
                  className="rounded text-[#8B5CF6] border-gray-300 w-4 h-4 cursor-pointer"
                  checked={addrDefault}
                  onChange={(e) => setAddrDefault(e.target.checked)}
                />
                <label htmlFor="make-def" className="text-xs text-zinc-800 dark:text-zinc-200 font-medium cursor-pointer">Register as primary default address</label>
              </div>

              <button type="submit" className="bg-[#000000] hover:scale-[1.02] text-white text-xs w-full py-3.5 rounded-full uppercase tracking-wider font-bold transition-transform cursor-pointer">Register delivery address</button>
            </form>
          )}

          {/* Directory listing cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {user.addresses && user.addresses.length > 0 ? (
              user.addresses.map((a) => (
                <div key={a.id} className="p-5 bg-white dark:bg-zinc-900/30 border border-zinc-200 dark:border-white/10 rounded-3xl relative flex flex-col justify-between shadow-xs hover:border-zinc-350 dark:hover:border-cyan-400/40 transition-all" id={`address-card-${a.id}`}>
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="font-extrabold text-xs text-zinc-900 dark:text-white">{a.name}</span>
                      {a.isDefault && (
                        <span className="bg-cyan-500/10 text-cyan-500 border border-cyan-500/20 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono uppercase tracking-wider">
                          PRIMARY DEFAULT
                        </span>
                      )}
                    </div>
                    <p className="text-xs leading-relaxed text-zinc-500 dark:text-zinc-400 font-sans">
                      {a.line1} {a.line2 ? `, ${a.line2}` : ''}<br />
                      {a.city}, {a.state} {a.postalCode}<br />
                      {a.country}<br />
                      {a.phone && `📞 ${a.phone}`}
                    </p>
                  </div>
                  
                  <div className="border-t border-zinc-150 dark:border-white/5 pt-3 mt-4 text-right">
                    <button 
                      onClick={() => deleteAddress(a.id)}
                      className="text-red-500 hover:text-red-650 text-xs font-semibold flex items-center justify-end gap-1 ml-auto cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Erase Location
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-10 bg-white dark:bg-[#06060c]/20 border border-zinc-150 dark:border-white/5 rounded-3xl">
                <p className="text-xs text-zinc-400">No delivery locations registered in list. Set one up to buy items smoothly.</p>
              </div>
            )}
          </div>

        </div>
      )}

      {/* TAB 3: PROFILE & EDIT PROFILE CARD */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8" id="dashboard-profile-deck">
          
          {/* PROFILE SECURITY BOX */}
          <div className="p-6 bg-white dark:bg-zinc-900/30 border border-zinc-200 dark:border-white/10 rounded-3xl space-y-6">
            <h3 className="font-extrabold text-md text-zinc-900 dark:text-white uppercase tracking-widest font-mono border-b border-zinc-100 dark:border-white/5 pb-2 flex items-center gap-1.5">
              <Key className="w-4 h-4 text-cyan-400" />
              My Profile Credentials
            </h3>

            {profileSuccess && (
              <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs rounded-xl font-bold font-mono">
                ✓ Account name updated successfully!
              </div>
            )}

            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase block mb-1">Full Signature Name</label>
                <input 
                  type="text" 
                  className="apple-input dark:bg-zinc-950 dark:border-white/10 dark:text-white"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase block mb-1">Account Email System (Permanent)</label>
                <input 
                  type="email" 
                  className="apple-input bg-zinc-100 dark:bg-zinc-900 border-none outline-hidden cursor-not-allowed dark:text-zinc-400"
                  value={user.email}
                  disabled
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 dark:text-zinc-500 font-mono font-bold uppercase block mb-1">Role Permission</label>
                <span className="inline-block px-3 py-1 bg-zinc-100 dark:bg-zinc-850 rounded-lg text-xs font-bold text-zinc-800 dark:text-zinc-300 font-mono">{user.role.toUpperCase()}</span>
              </div>

              <button 
                type="submit" 
                disabled={isUpdatingProfile}
                className="bg-[#000000] hover:scale-[1.02] text-white text-xs px-6 py-3.5 rounded-full font-bold uppercase tracking-wider disabled:opacity-55 transition-transform cursor-pointer"
              >
                {isUpdatingProfile ? 'Processing...' : 'Apply Details Redirection'}
              </button>
            </form>
          </div>

          {/* PAYMENT METHODS & SECURE VAULT CARD */}
          <div className="p-6 bg-white dark:bg-zinc-900/30 border border-zinc-200 dark:border-white/10 rounded-3xl space-y-6">
            <h3 className="font-extrabold text-md text-zinc-900 dark:text-white uppercase tracking-widest font-mono border-b border-zinc-100 dark:border-white/5 pb-2 flex items-center gap-1.5">
              <CreditCard className="w-5 h-5 text-indigo-400" />
              Secure Payment Methods
            </h3>

            {/* Apple Card Matte Hologram */}
            <div className="relative overflow-hidden bg-gradient-to-tr from-zinc-900 to-zinc-800 border border-zinc-200 dark:border-white/20 rounded-2xl p-6 text-white shadow-md flex flex-col justify-between min-h-[170px]">
              <div className="absolute top-0 right-0 -mr-10 -mt-10 w-36 h-36 rounded-full bg-zinc-500/10 blur-2xl pointer-events-none" />
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-mono text-[9px] font-bold text-zinc-400 uppercase tracking-widest">AUTHORIZED CREDIT VAULT</span>
                  <p className="text-sm font-black tracking-widest font-mono mt-1"> Apple Titanium Card</p>
                </div>
                <CreditCard className="w-5 h-5 text-[#8B5CF6]" />
              </div>

              <div>
                <p className="font-mono text-xs text-zinc-400">•••• •••• •••• 2026</p>
                <div className="flex justify-between items-center mt-3 text-[10px] font-mono text-zinc-500">
                  <span>EXPIRES: 12/28</span>
                  <span className="text-white font-bold">{user.name.toUpperCase()}</span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-zinc-400 leading-relaxed font-sans mt-2">
              Payment credentials are encrypted secure endpoints. Add dynamic UPI virtual paths, Rupay cards, or Credit Lines securely during checkout step!
            </p>
          </div>

        </div>
      )}

      {/* TAB 4: SYSTEM NOTIFICATIONS */}
      {activeTab === 'notifications' && (
        <div className="p-6 bg-white dark:bg-zinc-900/30 border border-zinc-200 dark:border-white/10 rounded-3xl space-y-6" id="dashboard-notifications-deck">
          <h3 className="font-extrabold text-md text-zinc-900 dark:text-white uppercase tracking-widest font-mono border-b border-zinc-150 dark:border-white/5 pb-2">
            System Dispatch Notifications
          </h3>

          <div className="divide-y divide-zinc-100 dark:divide-white/5">
            {notifications.map((n) => {
              const Icon = n.icon;
              return (
                <div key={n.id} className="py-4 flex gap-4 first:pt-0 last:pb-0 animate-fade-in">
                  <div className={`p-2.5 rounded-xl shrink-0 ${n.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <h4 className="text-xs font-extrabold text-zinc-900 dark:text-white font-mono uppercase tracking-wider">{n.title}</h4>
                      <span className="text-[9.5px] text-zinc-400 font-mono uppercase">{n.time}</span>
                    </div>
                    <p className="text-xs text-zinc-550 dark:text-zinc-400 mt-1">{n.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 5: CUSTOMER SERVICES HELP DESK */}
      {activeTab === 'support' && (
        <div className="space-y-6" id="dashboard-support-deck">
          <h3 className="font-semibold text-lg text-zinc-900 dark:text-white uppercase tracking-wider font-mono">iStore Premium Global Support</h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-200 dark:border-white/5 p-5 rounded-2xl hover:border-zinc-300 dark:hover:border-white/10 transition-colors">
              <Phone className="w-5 h-5 text-[#8B5CF6] mb-3" />
              <h5 className="font-bold text-xs text-zinc-900 dark:text-white uppercase tracking-wider font-mono">Secure Priority Helpline</h5>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 p-0.5">Chat directly with licensed technicians and store managers.</p>
              <p className="text-xs font-bold text-[#8B5CF6] mt-3 font-mono">+1 (800) MY-APPLE</p>
            </div>

            <div className="bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-200 dark:border-white/5 p-5 rounded-2xl hover:border-zinc-300 dark:hover:border-white/10 transition-colors">
              <Truck className="w-5 h-5 text-indigo-500 dark:text-cyan-400 mb-3" />
              <h5 className="font-bold text-xs text-zinc-900 dark:text-white uppercase tracking-wider font-mono">Standard Carrier Status</h5>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 p-0.5">Global air shipping door-to-door with trackable dispatchers.</p>
              <p className="text-xs font-bold text-zinc-800 dark:text-white mt-3 font-mono">Free shipping above ₹80,000</p>
            </div>

            <div className="bg-zinc-50 dark:bg-zinc-900/20 border border-zinc-200 dark:border-white/5 p-5 rounded-2xl hover:border-zinc-300 dark:hover:border-white/10 transition-colors">
              <HelpCircle className="w-5 h-5 text-indigo-500 dark:text-cyan-400 mb-3" />
              <h5 className="font-bold text-xs text-zinc-900 dark:text-white uppercase tracking-wider font-mono">Premium Warranty Cert</h5>
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 p-0.5">All devices come with 1 Year AppleCare Warranty standard.</p>
              <p className="text-xs font-bold text-zinc-800 dark:text-white mt-3 font-mono">Extendable anytime with AppleCare+</p>
            </div>

          </div>
        </div>
      )}

      {/* INVOICE MODAL DECK */}
      {activeInvoice && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-md animate-fade-in" id="invoice-modal-deck">
          <div className="bg-white dark:bg-[#06060c] border border-zinc-250 dark:border-white/10 rounded-3xl w-full max-w-2xl p-6 md:p-8 max-h-[90vh] overflow-y-auto relative shadow-2xl text-zinc-900 dark:text-white" id="invoice-bill-container">
            
            {/* Close */}
            <button 
              onClick={() => setActiveInvoice(null)}
              className="absolute right-4 top-4 p-2 bg-[#F5F5F7] dark:bg-zinc-900 rounded-full hover:bg-gray-200 dark:hover:bg-zinc-800 transition-colors cursor-pointer text-xl font-bold font-mono"
            >
              ×
            </button>

            {/* Print Header */}
            <div className="flex justify-between items-start border-b border-zinc-200 dark:border-white/10 pb-6 mb-6">
              <div>
                <span className="font-extrabold text-lg uppercase tracking-wider font-mono text-zinc-900 dark:text-white">iStore Official Retail Invoice</span>
                <p className="text-[10px] text-[#8B5CF6] font-mono">Invoice Date: {new Date(activeInvoice.createdAt).toLocaleDateString()}</p>
                <p className="text-[10px] text-zinc-500 font-mono">Transaction ID: {activeInvoice.id}</p>
              </div>
              <div className="text-right text-[10px] text-zinc-400 leading-relaxed font-mono">
                <b>iStore Global Inc</b><br />
                Infinite Loop, Cupertino, CA<br />
                sales@istorepremium.com
              </div>
            </div>

            {/* Info Billing Layout */}
            <div className="grid grid-cols-2 gap-6 text-[11px] border-b border-zinc-200 dark:border-white/10 pb-6 mb-6 font-mono">
              <div>
                <span className="text-zinc-400 font-bold block uppercase tracking-wider mb-1">Delivered Recipient</span>
                <strong className="text-zinc-900 dark:text-white block">{activeInvoice.shippingAddress.name}</strong>
                <p className="text-zinc-500 dark:text-zinc-400 mt-1 leading-relaxed">
                  {activeInvoice.shippingAddress.line1} {activeInvoice.shippingAddress.line2 ? `, ${activeInvoice.shippingAddress.line2}` : ''}<br />
                  {activeInvoice.shippingAddress.city}, {activeInvoice.shippingAddress.state} {activeInvoice.shippingAddress.postalCode}<br />
                  {activeInvoice.shippingAddress.country}<br />
                  Phone: {activeInvoice.shippingAddress.phone || 'N/A'}
                </p>
              </div>
              <div className="text-right">
                <span className="text-zinc-400 font-bold block uppercase tracking-wider mb-1">Payment Method & Delivery</span>
                <p className="text-zinc-900 dark:text-white"><b>Method:</b> {activeInvoice.paymentMethod}</p>
                <p className="text-zinc-400 dark:text-zinc-400 mt-1"><b>Carrier:</b> Apple Delivery Express</p>
                <p className="text-zinc-400 dark:text-zinc-400"><b>Tracking ID:</b> {activeInvoice.trackingNumber || 'Pending Assembly'}</p>
              </div>
            </div>

            {/* Invoice Line list */}
            <div className="space-y-4 border-b border-zinc-200 dark:border-white/10 pb-6 mb-6">
              <span className="text-zinc-400 font-bold block text-[10.5px] uppercase tracking-wider mb-2 font-mono">Order Items Grid</span>
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="border-b border-zinc-150 dark:border-white/5 font-semibold text-zinc-400 pb-2 uppercase tracking-wider">
                    <th className="pb-2">Model details</th>
                    <th className="pb-2 text-center">Qty</th>
                    <th className="pb-2 text-right">Price</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-white/5">
                  {activeInvoice.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="py-2.5">
                        <span className="font-semibold text-zinc-900 dark:text-white block">{item.name}</span>
                        <span className="text-[10px] text-zinc-450">{item.color} | {item.storage}</span>
                      </td>
                      <td className="py-2.5 text-center">{item.quantity}</td>
                      <td className="py-2.5 text-right font-semibold text-zinc-900 dark:text-zinc-800">{formatINR(item.priceAtPurchase)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculated summary totals */}
            <div className="flex justify-end text-xs leading-6 font-mono font-bold">
              <div className="w-60 text-right space-y-1">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-zinc-900 dark:text-white">{formatINR(activeInvoice.subtotal)}</span>
                </div>
                {activeInvoice.discount > 0 && (
                  <div className="flex justify-between text-rose-500">
                    <span>Coupon Savings:</span>
                    <span className="font-semibold">-{formatINR(activeInvoice.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-zinc-400">
                  <span>GST/CGST (18%):</span>
                  <span className="font-semibold text-zinc-900 dark:text-white">{formatINR(activeInvoice.tax)}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Shipping Cost:</span>
                  <span className="font-semibold text-zinc-900 dark:text-white">FREE</span>
                </div>
                <div className="flex justify-between border-t border-zinc-200 dark:border-white/10 pt-2 text-sm font-bold text-zinc-900 dark:text-white">
                  <span>Total Gross Cost:</span>
                  <span className="text-[#8B5CF6] font-extrabold">{formatINR(activeInvoice.total)}</span>
                </div>
              </div>
            </div>

            {/* Print action prompt */}
            <div className="mt-8 pt-4 border-t border-zinc-150 dark:border-white/5 flex gap-2 justify-end">
              <button 
                onClick={() => window.print()}
                className="bg-[#000000] hover:scale-[1.02] text-white text-xs py-3.5 px-6 rounded-full flex items-center gap-1.5 cursor-pointer font-bold uppercase tracking-wider transition-all"
              >
                <Printer className="w-4 h-4" />
                Trigger Hardware Print (PDF)
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
