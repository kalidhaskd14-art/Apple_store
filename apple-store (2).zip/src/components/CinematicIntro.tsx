import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useStore } from '../store';

interface CinematicIntroProps {
  onComplete: () => void;
}

export default function CinematicIntro({ onComplete }: CinematicIntroProps) {
  const { isDarkMode } = useStore();
  const [phase, setPhase] = useState<'coalesce' | 'logo-revealed' | 'light-sweep' | 'dissolve' | 'complete'>('coalesce');
  const [skipped, setSkipped] = useState(false);

  // Phase scheduling matching a precise 5-second cinematic timeline
  useEffect(() => {
    // Stage 1: Particles and smoke begin coalescing, gradient intensifies
    const tReveal = setTimeout(() => {
      setPhase('logo-revealed');
    }, 1800);

    // Stage 2: Blinding premium silver/purple light sweep across the logo
    const tSweep = setTimeout(() => {
      setPhase('light-sweep');
    }, 3000);

    // Stage 3: Motion blur dissolve and upscale transition begins
    const tDissolve = setTimeout(() => {
      setPhase('dissolve');
    }, 4400);

    // Stage 4: Playback ends, hand control back to the App shell
    const tComplete = setTimeout(() => {
      setPhase('complete');
      onComplete();
    }, 5000);

    return () => {
      clearTimeout(tReveal);
      clearTimeout(tSweep);
      clearTimeout(tDissolve);
      clearTimeout(tComplete);
    };
  }, [onComplete]);

  const handleSkip = () => {
    setSkipped(true);
    onComplete();
  };

  if (skipped || phase === 'complete') return null;

  // Generate 80 high-performance micro-particles for coalescence
  const particles = Array.from({ length: 80 }).map((_, idx) => {
    // Calculate randomized start coordinates far from the center
    const angle = Math.random() * Math.PI * 2;
    const distance = 160 + Math.random() * 200; // start scattered outside
    const startX = Math.cos(angle) * distance;
    const startY = Math.sin(angle) * distance;
    
    // Vary size and neon hue
    const size = Math.random() * 3 + 1.5;
    const delay = Math.random() * 0.8; // staggered convergence
    const duration = 1.3 + Math.random() * 0.7; // convergence duration

    return {
      id: idx,
      size,
      startX,
      startY,
      delay,
      duration,
      color: idx % 3 === 0 ? '#C084FC' : idx % 3 === 1 ? '#818CF8' : (isDarkMode ? '#FFFFFF' : '#EC4899'),
    };
  });

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 1, filter: 'blur(0px)' }}
        animate={{ 
          opacity: phase === 'dissolve' ? 0 : 1,
          filter: phase === 'dissolve' ? 'blur(25px)' : 'blur(0px)',
          scale: phase === 'dissolve' ? 1.08 : 1
        }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.75, ease: [0.25, 1, 0.5, 1] }}
        className="fixed inset-0 z-[100] bg-[#F5F5F7] dark:bg-[#040406] flex flex-col items-center justify-center overflow-hidden select-none transition-colors duration-500"
        style={{ perspective: 1200 }}
      >
        {/* Style injection containing hardware-accelerated fluid animations */}
        <style dangerouslySetInnerHTML={{ __html: `
          /* Cinematic Aurora/Nebula slow breathing */
          @keyframes auroraSpin {
            0% { transform: rotate(0deg) scale(1); opacity: 0.4; }
            50% { transform: rotate(180deg) scale(1.15); opacity: 0.65; }
            100% { transform: rotate(360deg) scale(1); opacity: 0.4; }
          }
          @keyframes auroraDrift {
            0% { transform: translate(-5%, -5%) scale(1); }
            50% { transform: translate(10%, 15%) scale(1.1); }
            100% { transform: translate(-5%, -5%) scale(1); }
          }

          /* Light streak animations */
          @keyframes lightStreakOne {
            0% { transform: translate(-100%, -50%) rotate(-35deg); opacity: 0; }
            15% { opacity: 0.25; }
            85% { opacity: 0.25; }
            100% { transform: translate(150%, 50%) rotate(-35deg); opacity: 0; }
          }
          @keyframes lightStreakTwo {
            0% { transform: translate(-100%, 50%) rotate(-15deg); opacity: 0; }
            20% { opacity: 0.2; }
            80% { opacity: 0.2; }
            100% { transform: translate(150%, -50%) rotate(-15deg); opacity: 0; }
          }

          /* Smoke / Fog continuous drift */
          @keyframes smokeDrift {
            0% { transform: scale(1) translate(0px, 0px); opacity: 0.15; }
            50% { transform: scale(1.1) translate(30px, -20px); opacity: 0.25; }
            100% { transform: scale(1) translate(0px, 0px); opacity: 0.15; }
          }

          /* Particle converging motion in 3D space */
          @keyframes coalesceIn {
            0% {
              transform: translate3d(var(--sx), var(--sy), 200px);
              opacity: 0;
            }
            30% {
              opacity: 0.8;
            }
            90% {
              transform: translate3d(0, 0, 0);
              opacity: 1;
              filter: brightness(1.5) drop-shadow(0 0 5px currentColor);
            }
            100% {
              transform: translate3d(0, 0, 0);
              opacity: 0;
              scale: 0.1;
            }
          }

          /* Deluxe Logo floating motion */
          @keyframes premiumFloat {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-6px) rotate(1.5deg); }
          }

          /* Dynamic shimmer sweep */
          @keyframes cinematicShine {
            0% { transform: translateX(-120%) rotate(25deg); }
            100% { transform: translateX(120%) rotate(25deg); }
          }

          .animate-aurora-spin {
            animation: auroraSpin 15s ease-in-out infinite;
          }
          .animate-aurora-drift {
            animation: auroraDrift 18s ease-in-out infinite alternate;
          }
          .animate-smoke {
            animation: smokeDrift 10s ease-in-out infinite;
          }
          .animate-float-logo {
            animation: premiumFloat 5s ease-in-out infinite;
          }
        `}} />

        {/* 1. LAYER 1: DEEP COSMIC NEBULA & AURORA GRADIENTS */}
        <div className="absolute inset-0 pointer-events-none z-0">
          {/* Main Aurora Purple/Indigo Core */}
          <div 
            className="absolute -left-1/4 -top-1/4 w-[150%] h-[150%] rounded-full animate-aurora-spin"
            style={{
              background: isDarkMode 
                ? 'radial-gradient(circle, rgba(139, 92, 246, 0.18) 0%, rgba(99, 102, 241, 0.08) 35%, rgba(236, 72, 153, 0.04) 60%, rgba(0,0,0,0) 80%)'
                : 'radial-gradient(circle, rgba(139, 92, 246, 0.08) 0%, rgba(129, 140, 248, 0.05) 40%, rgba(253, 244, 255, 0) 70%)',
              filter: 'blur(75px)',
            }}
          />
          {/* Opposite Accent Cyan/Blue Ambient Spot */}
          <div 
            className="absolute -right-1/4 -bottom-1/4 w-[130%] h-[130%] rounded-full animate-aurora-drift"
            style={{
              background: isDarkMode
                ? 'radial-gradient(circle, rgba(6, 182, 212, 0.08) 0%, rgba(30, 27, 75, 0.05) 50%, rgba(0,0,0,0) 85%)'
                : 'radial-gradient(circle, rgba(56, 189, 248, 0.05) 0%, rgba(243, 244, 246, 0) 60%)',
              filter: 'blur(90px)',
            }}
          />
        </div>

        {/* 2. LAYER 2: CINEMATIC LIGHT STREAKS (Traveling diagonally) */}
        <div className={`absolute inset-0 z-1 pointer-events-none opacity-40 ${isDarkMode ? 'mix-blend-color-dodge' : 'mix-blend-overlay'}`}>
          {/* Streak 1 */}
          <div 
            className="absolute top-1/2 left-0 w-[120%] h-[1px]"
            style={{
              background: 'linear-gradient(90deg, transparent 0%, rgba(167, 139, 250, 0.3) 30%, rgba(255, 255, 255, 0.6) 50%, rgba(167, 139, 250, 0.3) 70%, transparent 100%)',
              filter: 'blur(4px)',
              animation: 'lightStreakOne 6s cubic-bezier(0.2, 0.8, 0.2, 1) infinite',
            }}
          />
          {/* Streak 2 */}
          <div 
            className="absolute top-1/3 left-0 w-[120%] h-[2px]"
            style={{
              background: 'linear-gradient(90deg, transparent 0%, rgba(99, 102, 241, 0.2) 20%, rgba(167, 139, 250, 0.4) 50%, rgba(236, 72, 153, 0.2) 80%, transparent 100%)',
              filter: 'blur(6px)',
              animation: 'lightStreakTwo 5s cubic-bezier(0.15, 0.85, 0.15, 1) infinite 1.5s',
            }}
          />
        </div>

        {/* 3. LAYER 3: ELEGANT SMOKE / FOG NEBULA CANVASES */}
        <div className="absolute inset-0 z-2 pointer-events-none mix-blend-overlay">
          <svg className={`absolute w-full h-full animate-smoke ${isDarkMode ? 'opacity-35' : 'opacity-15'}`} style={{ filter: 'blur(4px)' }}>
            <defs>
              <linearGradient id="smoke-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#c084fc" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#818cf8" stopOpacity="0.15" />
                <stop offset="100%" stopColor="#ec4899" stopOpacity="0.05" />
              </linearGradient>
            </defs>
            {/* SVG vector shapes rendering ambient cloudy particles */}
            <path d="M 100,200 Q 200,100 400,200 T 700,400 T 1100,200 T 1500,400 L 1500,800 L 0,800 Z" fill="url(#smoke-grad)" />
            <path d="M 0,300 Q 300,150 600,300 T 1000,500 T 1400,300 L 1400,800 L 0,800 Z" fill="url(#smoke-grad)" opacity="0.6" />
          </svg>
        </div>

        {/* 4. LAYER 4: PARTICLE CONVERGENCE FLIGHT (Forms Apple Logo) */}
        {phase === 'coalesce' && (
          <div className="absolute inset-0 z-10 pointer-events-none">
            {particles.map((p) => (
              <div
                key={p.id}
                className="absolute rounded-full"
                style={{
                  top: '50%',
                  left: '50%',
                  width: `${p.size}px`,
                  height: `${p.size}px`,
                  backgroundColor: p.color,
                  boxShadow: `0 0 10px ${p.color}, 0 0 20px ${p.color}`,
                  margin: `-${p.size / 2}px 0 0 -${p.size / 2}px`,
                  // Dynamic local variable definitions applied to standard keyframe block
                  ['--sx' as any]: `${p.startX}px`,
                  ['--sy' as any]: `${p.startY}px`,
                  animation: `coalesceIn ${p.duration}s cubic-bezier(0.08, 0.85, 0.15, 1) ${p.delay}s forwards`,
                }}
              />
            ))}
          </div>
        )}

        {/* 5. LAYER 5: THE CORE APPLE LOGO (Materialized and floating) */}
        <div className="relative z-20 flex flex-col items-center justify-center text-center">
          
          {/* Highly diffused background glowing aura radiating outwards on reveal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.6 }}
            animate={{ 
              opacity: phase !== 'coalesce' ? 1 : 0.1,
              scale: phase === 'light-sweep' ? 1.15 : 1,
            }}
            transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
            className={`absolute rounded-full w-96 h-96 bg-gradient-to-r from-[#A78BFA] via-[#EC4899] to-[#818CF8] blur-[65px] pointer-events-none select-none ${isDarkMode ? 'opacity-40' : 'opacity-25'}`}
          />

          {/* Genuine Luxury Vector Apple Logo Wrapper */}
          <motion.div
            initial={{ opacity: 0, scale: 0.6, filter: 'brightness(3) blur(10px)' }}
            animate={{ 
              opacity: phase !== 'coalesce' ? 1 : 0,
              scale: phase !== 'coalesce' ? 1 : 0.6,
              filter: phase !== 'coalesce' ? 'brightness(1) blur(0px)' : 'brightness(3) blur(10px)',
            }}
            transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
            className="w-32 h-32 relative flex items-center justify-center animate-float-logo"
          >
            {/* Real Logo SVG with Custom Linear Gradients */}
            <svg 
              className="w-28 h-28 relative overflow-visible drop-shadow-[0_4px_24px_rgba(167,139,250,0.35)]" 
              viewBox="0 0 24 24"
            >
              <defs>
                <linearGradient id="cosmic-silver" x1="0%" y1="0%" x2="100%" y2="100%">
                  {isDarkMode ? (
                    <>
                      <stop offset="0%" stopColor="#FFFFFF" />
                      <stop offset="40%" stopColor="#E9D5FF" />
                      <stop offset="70%" stopColor="#C084FC" />
                      <stop offset="100%" stopColor="#818CF8" />
                    </>
                  ) : (
                    <>
                      <stop offset="0%" stopColor="#1E1B4B" />
                      <stop offset="35%" stopColor="#4F46E5" />
                      <stop offset="70%" stopColor="#9333EA" />
                      <stop offset="100%" stopColor="#DB2777" />
                    </>
                  )}
                </linearGradient>

                {/* Mask for precise interior light sweep */}
                <clipPath id="apple-logo-clip">
                  <path d="M18.71,19.5c-.83,1.24-1.71,2.45-3.05,2.47-1.34,.03-1.77-.79-3.29-.79-1.53,0-2,.77-3.27,.82-1.31,.05-2.3-1.32-3.14-2.53C4.25,17,2.94,12.45,4.7,9.39c.87-1.52,2.43-2.48,4.12-2.51,1.28-.02,2.5,.87,3.29,.87,.78,0,2.26-1.07,3.81-.91,1.54,.06,2.7,.61,3.46,1.73C15.4,11.04,14.8,15.78,18.71,19.5M15.97,4.17c1.39-1.68,1.35-3.22,1.35-3.22,0,0-1.42,.02-3.04,1.92-1.12,1.31-1.28,2.7-1.28,2.7,0,0,1.52,.12,2.97-1.4" />
                </clipPath>
              </defs>
              
              {/* Backglow layer */}
              <path 
                d="M18.71,19.5c-.83,1.24-1.71,2.45-3.05,2.47-1.34,.03-1.77-.79-3.29-.79-1.53,0-2,.77-3.27,.82-1.31,.05-2.3-1.32-3.14-2.53C4.25,17,2.94,12.45,4.7,9.39c.87-1.52,2.43-2.48,4.12-2.51,1.28-.02,2.5,.87,3.29,.87,.78,0,2.26-1.07,3.81-.91,1.54,.06,2.7,.61,3.46,1.73C15.4,11.04,14.8,15.78,18.71,19.5M15.97,4.17c1.39-1.68,1.35-3.22,1.35-3.22,0,0-1.42,.02-3.04,1.92-1.12,1.31-1.28,2.7-1.28,2.7,0,0,1.52,.12,2.97-1.4" 
                fill="url(#cosmic-silver)"
              />

              {/* Masked Sweeping Shimmer Beam */}
              {phase !== 'coalesce' && (
                <g clipPath="url(#apple-logo-clip)">
                  <rect 
                    className="absolute inset-0 w-full h-full"
                    fill="url(#cosmic-silver)"
                    width="24"
                    height="24"
                  />
                  <rect 
                    x="-20"
                    y="0"
                    width="12"
                    height="28"
                    fill="rgba(255, 255, 255, 0.95)"
                    style={{
                      transformOrigin: 'center',
                      filter: 'blur(3px)',
                      animation: phase === 'light-sweep' ? 'cinematicShine 1.8s cubic-bezier(0.2, 1, 0.4, 1) forwards' : 'none',
                      mixBlendMode: 'overlay'
                    }}
                  />
                </g>
              )}
            </svg>

            {/* Ambient Sparkles occurring around the logo during the sweep */}
            <AnimatePresence>
              {phase === 'light-sweep' && (
                <>
                  {/* Top Sparkle */}
                  <motion.div 
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: [0, 1.3, 1], opacity: [0, 0.95, 0] }}
                    transition={{ duration: 1.0, delay: 0.2 }}
                    className="absolute -top-3 left-1/3"
                  >
                    <svg className={`w-5 h-5 ${isDarkMode ? 'text-purple-200 drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]' : 'text-purple-600 drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]'} fill-current`} viewBox="0 0 24 24">
                      <path d="M12 0l3 9 9 3-9 3-3 9-3-9-9-3 9-3z" />
                    </svg>
                  </motion.div>

                  {/* Corner Sparkle */}
                  <motion.div 
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: [0, 1.5, 1], opacity: [0, 1, 0] }}
                    transition={{ duration: 1.1, delay: 0.6 }}
                    className="absolute -bottom-2 right-4"
                  >
                    <svg className={`w-6 h-6 ${isDarkMode ? 'text-indigo-100 drop-shadow-[0_0_10px_rgba(255,255,255,0.9)]' : 'text-indigo-600 drop-shadow-[0_0_10px_rgba(99,102,241,0.6)]'} fill-current`} viewBox="0 0 24 24">
                      <path d="M12 0l3 9 9 3-9 3-3 9-3-9-9-3 9-3z" />
                    </svg>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </motion.div>

          {/* 6. TYPOGRAPHY: LUXURY REVEAL TEXT */}
          <div className="h-12 mt-8 relative overflow-hidden flex items-center justify-center">
            <AnimatePresence>
              {phase !== 'coalesce' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 0.9, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 1.3, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
                  className="space-y-1 z-25"
                >
                  <p className="text-xs font-medium tracking-[0.28em] text-zinc-800 dark:text-[#E8E8ED] uppercase font-sans">
                    iStore Special Event
                  </p>
                  <p className="text-[10px] font-semibold text-zinc-400 dark:text-zinc-500 font-mono tracking-widest uppercase">
                    Designed for Apple Intelligence
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

        {/* 7. TRIGGER: LUXURY FORWARD SKIP OPTION */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: isDarkMode ? 0.35 : 0.6 }}
          whileHover={{ 
            opacity: 0.95, 
            scale: 1.02, 
            backgroundColor: isDarkMode ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)',
            borderColor: isDarkMode ? 'rgba(255, 255, 255, 0.25)' : 'rgba(0, 0, 0, 0.15)'
          }}
          onClick={handleSkip}
          className="absolute bottom-10 z-50 px-5 py-2 rounded-full border border-zinc-200 dark:border-white/10 text-[10px] uppercase font-bold tracking-[0.16em] font-mono text-zinc-600 dark:text-zinc-400 bg-white/60 dark:bg-white/5 backdrop-blur-md transition-all duration-300 shadow-[0_4px_24px_rgba(0,0,0,0.06)] dark:shadow-[0_4px_24px_rgba(0,0,0,0.5)]"
        >
          Skip Intro
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}
