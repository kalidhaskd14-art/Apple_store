import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Product, Order, User as StoreUser, Review } from '../types';
import { 
  BarChart3, Plus, Edit, Trash2, ShieldX, CheckCircle, 
  Clock, Package, DollarSign, Users, ShoppingCart, Percent, 
  Grid, ArrowUpRight, Search, ListFilter, SlidersHorizontal, RefreshCw,
  Bell, User, ShieldCheck, Mail, Settings, LogOut, ChevronRight, ChevronDown,
  HelpCircle, CreditCard, Star, Sparkles, MessageSquare, Menu, X, ArrowLeftRight, FileSpreadsheet, Play, Image, Move3d, AlertCircle,
  MapPin, Phone, Printer, Download, ExternalLink
} from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR } from '../utils/currency';

type SidebarTab = 
  | 'dashboard' 
  | 'products' 
  | 'orders' 
  | 'customers' 
  | 'payments' 
  | 'coupons' 
  | 'reviews' 
  | 'analytics' 
  | 'messages' 
  | 'settings';

export default function AdminPanel() {
  const {
    setView,
    adminStats,
    adminUsers,
    adminOrders,
    adminCoupons,
    adminCategories,
    products,
    fetchAdminStats,
    fetchAdminUsers,
    fetchAdminOrders,
    fetchAdminCoupons,
    fetchAdminCategories,
    blockUser,
    deleteUser,
    addAdminProduct,
    updateAdminProduct,
    deleteAdminProduct,
    updateOrderStatus,
    addCoupon,
    deleteCoupon,
    addCategory,
    deleteCategory,
    fetchProducts,
    logout,
    user: currentLoggedInUser
  } = useStore();

  const [activeTab, setActiveTab] = useState<SidebarTab>('dashboard');
  const [loading, setLoading] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  
  // Notification States
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: "New Order #10892 received for iPhone 16 Pro Max", time: "3 mins ago", read: false },
    { id: 2, text: "Refund requested for MacBook Air M3 (Order #10645)", time: "1 hr ago", read: false },
    { id: 3, text: "Inventory alert: Apple Watch Ultra 2 low on stock (2 units left)", time: "4 hrs ago", read: true },
    { id: 4, text: "Customer user 'Mick Robinson' registered successfully", time: "1 day ago", read: true }
  ]);

  // Support Messages States
  const [messages, setMessages] = useState([
    { id: 'msg-1', name: 'John Doe', email: 'john@icloud.com', subject: 'HDFC No Cost EMI Enquiry', message: 'I want to block my order but the EMI payment is showing processing fee. Is that standard?', date: '10 mins ago', replied: false },
    { id: 'msg-2', name: 'Diana Prince', email: 'diana@amazon.com', subject: 'Desert Titanium 512GB Stock', message: 'Hey! Is the Desert Titanium finish available in Mumbai store? Need to purchase today.', date: '3 hrs ago', replied: true },
    { id: 'msg-3', name: 'Sam Wilson', email: 'falcon@shield.gov', subject: 'Apple Vision Pro spatial setup details', message: 'Does the pre-configured spatial audio scan support dual custom ear profiles?', date: ' Yesterday', replied: false }
  ]);
  const [activeMessageId, setActiveMessageId] = useState<string>('msg-1');
  const [replyText, setReplyText] = useState('');

  // General Settings States
  const [shopName, setShopName] = useState('iStore Admin Elite');
  const [adminEmailAlerts, setAdminEmailAlerts] = useState('admin@apple.com');
  const [currencyConfig, setCurrencyConfig] = useState('INR');
  const [underMaintenance, setUnderMaintenance] = useState(false);

  // New Product Form State
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState(119900);
  const [prodDiscount, setProdDiscount] = useState(0);
  const [prodCategory, setProdCategory] = useState('iPhones');
  const [prodStock, setProdStock] = useState(15);
  const [prodColorHex, setProdColorHex] = useState('#D9C8B5');
  const [prodColorName, setProdColorName] = useState('Desert Titanium');
  const [selectedColors, setSelectedColors] = useState<{ hex: string; name: string }[]>([
    { hex: '#D9C8B5', name: 'Desert Titanium' },
    { hex: '#E7E2DC', name: 'Natural Titanium' }
  ]);
  const [selectedStorages, setSelectedStorages] = useState<string[]>(['128GB', '256GB', '512GB']);
  const [prodSpecKey, setProdSpecKey] = useState('');
  const [prodSpecVal, setProdSpecVal] = useState('');
  const [prodSpecs, setProdSpecs] = useState<{ [key: string]: string }>({
    'Processor': 'A18 Pro chip with 6-core GPU',
    'Display': '6.9-inch Super Retina XDR'
  });
  const [prodImageUrl, setProdImageUrl] = useState('https://images.unsplash.com/photo-1726053303862-2ee75ec65a19?auto=format&fit=crop&q=80&w=800');
  const [prodVideoUrl, setProdVideoUrl] = useState('https://www.youtube.com/embed/GDlkCda65O8');
  const [has360Model, setHas360Model] = useState(true);

  // New Coupon Form State
  const [couponCode, setCouponCode] = useState('');
  const [couponPercent, setCouponPercent] = useState(10);
  const [couponExpiry, setCouponExpiry] = useState('2027-12-31T23:59:59Z');

  // New Category Form State
  const [catName, setCatName] = useState('');
  const [catDesc, setCatDesc] = useState('');

  // Filtering variables
  const [orderStatusFilter, setOrderStatusFilter] = useState<'ALL' | 'PENDING' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'REFUNDS'>('ALL');

  // Expanded card tracking for orders
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({});
  const [activeInvoiceOrder, setActiveInvoiceOrder] = useState<Order | null>(null);

  const toggleOrderExpanded = (id: string) => {
    setExpandedOrders(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Load all admin data on boot
  useEffect(() => {
    setLoading(true);
    const loadAll = async () => {
      try {
        await Promise.all([
          fetchAdminStats(),
          fetchAdminUsers(),
          fetchAdminOrders(),
          fetchAdminCoupons(),
          fetchAdminCategories(),
          fetchProducts()
        ]);
      } catch (err) {
        console.error("Error loading admin data: ", err);
      } finally {
        setLoading(false);
      }
    };
    loadAll();
  }, []);

  const handleRefresh = async () => {
    setLoading(true);
    try {
      await Promise.all([
        fetchAdminStats(),
        fetchAdminUsers(),
        fetchAdminOrders(),
        fetchAdminCoupons(),
        fetchAdminCategories()
      ]);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAddColor = () => {
    if (prodColorHex && prodColorName) {
      if (!selectedColors.some(c => c.hex === prodColorHex)) {
        setSelectedColors([...selectedColors, { hex: prodColorHex, name: prodColorName }]);
      }
      setProdColorHex('#000000');
      setProdColorName('');
    }
  };

  const handleAddSpec = () => {
    if (prodSpecKey && prodSpecVal) {
      setProdSpecs({ ...prodSpecs, [prodSpecKey]: prodSpecVal });
      setProdSpecKey('');
      setProdSpecVal('');
    }
  };

  const startEditProduct = (p: Product) => {
    setEditingProductId(p.id);
    setProdName(p.name);
    setProdDesc(p.description);
    setProdPrice(p.price);
    setProdDiscount(p.discount);
    setProdCategory(p.category);
    setProdStock(p.stock);
    
    // Convert color hexes & names array back to format
    const restoredColors = p.colors.map((hex, idx) => ({
      hex,
      name: p.colorNames?.[idx] || 'Custom Finish'
    }));
    setSelectedColors(restoredColors);
    setSelectedStorages(p.storages || ['128GB', '256GB', '512GB']);
    setProdSpecs(p.specs || {});
    setProdImageUrl(p.images?.[0] || 'https://images.unsplash.com/photo-1726053303862-2ee75ec65a19?auto=format&fit=crop&q=80&w=800');
    setHas360Model(true);
    setShowProductForm(true);
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName || !prodPrice) return;

    const payload = {
      name: prodName,
      description: prodDesc,
      price: Number(prodPrice),
      discount: Number(prodDiscount),
      category: prodCategory,
      stock: Number(prodStock),
      colors: selectedColors.map(c => c.hex),
      colorNames: selectedColors.map(c => c.name),
      storages: selectedStorages,
      specs: prodSpecs,
      images: [prodImageUrl],
      isFeatured: true
    };

    let success = false;
    if (editingProductId) {
      success = await updateAdminProduct(editingProductId, payload);
    } else {
      success = await addAdminProduct(payload);
    }

    if (success) {
      setShowProductForm(false);
      setEditingProductId(null);
      // Reset state variables
      setProdName('');
      setProdDesc('');
      setProdPrice(119900);
      setProdDiscount(0);
      setProdStock(15);
      setSelectedColors([
        { hex: '#D9C8B5', name: 'Desert Titanium' },
        { hex: '#E7E2DC', name: 'Natural Titanium' }
      ]);
      setProdSpecs({
        'Processor': 'A18 Pro chip with 6-core GPU',
        'Display': '6.9-inch Super Retina XDR'
      });
      await fetchProducts();
    }
  };

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName) return;
    const ok = await addCategory(catName, catDesc);
    if (ok) {
      setCatName('');
      setCatDesc('');
      await fetchAdminCategories();
    }
  };

  const handleCouponSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode) return;
    const ok = await addCoupon(couponCode, Number(couponPercent));
    if (ok) {
      setCouponCode('');
      setCouponPercent(10);
      await fetchAdminCoupons();
    }
  };

  const handleReplyToMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    setMessages(messages.map(m => m.id === activeMessageId ? { ...m, replied: true } : m));
    setReplyText('');
    alert('Dynamic admin response broadcasted. Message ticket updated as Replied.');
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    setShowNotificationDropdown(false);
  };

  const handleLogoutFlow = () => {
    logout();
    setView('home');
  };

  // Safe global variables for stats indicators (No fake/mock fallbacks, strictly live authentic database values)
  const stats = {
    totalUsers: adminUsers.length,
    totalOrders: adminOrders.length,
    totalRevenue: adminOrders.reduce((acc, o) => o.status !== 'cancelled' ? acc + o.total : acc, 0),
    totalProducts: products.length,
    monthlySales: adminStats?.monthlySales || []
  };

  // Derived filtered users list
  const filteredUsers = adminUsers.filter(u => 
    u.name.toLowerCase().includes(globalSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(globalSearch.toLowerCase()) ||
    u.role.toLowerCase().includes(globalSearch.toLowerCase())
  );

  // Derived filtered products
  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(globalSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(globalSearch.toLowerCase())
  );

  // Derived filtered orders list
  const filteredOrders = adminOrders.filter(o => {
    const trackingNo = (o.trackingNumber || '').toLowerCase();
    const orderId = o.id.toLowerCase();
    const customer = o.userName.toLowerCase();
    const matchesSearch = orderId.includes(globalSearch.toLowerCase()) || customer.includes(globalSearch.toLowerCase()) || trackingNo.includes(globalSearch.toLowerCase());
    
    if (orderStatusFilter === 'ALL') return matchesSearch;
    if (orderStatusFilter === 'PENDING') return o.status === 'pending' && matchesSearch;
    if (orderStatusFilter === 'PROCESSING') return o.status === 'processing' && matchesSearch;
    if (orderStatusFilter === 'SHIPPED') return o.status === 'shipped' && matchesSearch;
    if (orderStatusFilter === 'DELIVERED') return o.status === 'delivered' && matchesSearch;
    if (orderStatusFilter === 'CANCELLED') return o.status === 'cancelled' && matchesSearch;
    if (orderStatusFilter === 'REFUNDS') {
      // Treat cancelled or explicitly tagged refunds
      return (o.status === 'cancelled' || o.id.includes('ref')) && matchesSearch;
    }
    return matchesSearch;
  });

  // Collect all Reviews across products dynamically
  const aggregateReviews: { review: Review; productName: string; productId: string }[] = [];
  products.forEach(p => {
    if (p.reviews && p.reviews.length > 0) {
      p.reviews.forEach(r => {
        aggregateReviews.push({
          review: r,
          productName: p.name,
          productId: p.id
        });
      });
    }
  });

  // Sidebar items definition
  const sidebarItems: { id: SidebarTab; label: string; icon: React.ComponentType<any> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: FileSpreadsheet },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'coupons', label: 'Coupons', icon: Percent },
    { id: 'reviews', label: 'Reviews', icon: Star },
    { id: 'analytics', label: 'Analytics', icon: ArrowLeftRight },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-[#F5F3FA] text-zinc-900 font-sans flex flex-col md:flex-row pb-24" id="admin-workspace-pane">
      
      {/* 1. SIDEBAR NAVIGATION - FIXED POSITION ON DESKTOP */}
      <aside className="w-full md:w-64 md:fixed md:top-0 md:bottom-0 md:left-0 bg-white border-b md:border-b-0 md:border-r border-zinc-200/50 p-6 flex flex-col shrink-0 z-20 overflow-y-auto">
        {/* Apple Luxury Brand Badge */}
        <div className="flex items-center gap-3 mb-10 mt-1">
          <div className="bg-[#F7F3FF] p-2.5 rounded-full text-[#8B5CF6]">
            {/* Apple custom unicode character */}
            <span className="text-xl font-bold select-none leading-none"></span>
          </div>
          <div>
            <h1 className="font-extrabold text-sm tracking-tight text-[#1D1D1F]">
              iStore Workspace
            </h1>
            <p className="text-[9.5px] font-bold text-[#8B5CF6]/90 uppercase tracking-widest font-mono">
              Administrative Console
            </p>
          </div>
        </div>

        {/* Sidebar Navigation Items */}
        <nav className="space-y-1.5 flex-1 select-none">
          {sidebarItems.map(item => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { setActiveTab(item.id); setShowProductForm(false); }}
                className={`w-full flex items-center gap-3.5 px-4.5 py-3 rounded-[16px] text-xs font-bold uppercase tracking-wider transition-all text-left group cursor-pointer ${
                  isActive 
                    ? 'bg-[#F7F3FF] text-[#8B5CF6] font-extrabold shadow-sm' 
                    : 'text-zinc-500 hover:text-zinc-950 hover:bg-[#F7F3FF]/40'
                }`}
              >
                <IconComponent className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-105 ${isActive ? 'text-[#8B5CF6]' : 'text-zinc-400'}`} />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Admin Signature card */}
        <div className="mt-8 border-t border-violet-50 pt-5 space-y-3.5">
          <div className="flex items-center gap-3 px-1.5">
            <div className="w-8.5 h-8.5 rounded-full bg-zinc-950 text-white font-mono flex items-center justify-center text-xs font-black select-none border border-violet-100">
              {currentLoggedInUser?.name?.[0] || 'A'}
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-950 truncate max-w-[130px]">
                {currentLoggedInUser?.name || 'Administrator'}
              </p>
              <span className="text-[10px] text-zinc-400 font-medium block">
                System Super-User
              </span>
            </div>
          </div>

          <button
            onClick={handleLogoutFlow}
            className="w-full flex items-center gap-3 px-4.5 py-3 bg-zinc-950 hover:bg-black text-white rounded-[16px] text-xs font-bold uppercase tracking-wider transition-all text-left justify-center cursor-pointer hover:shadow-md"
            title="Safety Log Out"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            Safety Logout
          </button>
        </div>
      </aside>

      {/* 2. MAIN BODY WRAPPER - ADJUSTED WITH PL-64 OFFSET FOR FIXED SIDEBAR */}
      <main className="flex-1 min-w-0 md:pl-64 flex flex-col min-h-screen" id="admin-workbench-interior">
        
        {/* TOP COMPACT HEADER */}
        <header className="sticky top-0 bg-white/90 backdrop-blur-xl border-b border-violet-50 p-6 flex flex-col sm:flex-row items-center justify-between gap-4 z-10 select-none">
          
          {/* Live search input bar */}
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search databases, products, order logs..."
              className="w-full pl-10.5 pr-4 py-2.5 bg-zinc-100/60 hover:bg-zinc-100 border border-transparent focus:border-violet-200 focus:bg-white text-xs font-medium rounded-full outline-none transition-all placeholder:text-zinc-400 text-zinc-800"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
            />
            {globalSearch && (
              <button 
                onClick={() => setGlobalSearch('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-black hover:scale-110"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Action pills deck */}
          <div className="flex items-center gap-4.5 self-end sm:self-auto">
            {/* Quick Refresh Status */}
            <button
              onClick={handleRefresh}
              className="p-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 rounded-full transition-transform active:rotate-180 cursor-pointer"
              title="Synchronize Database"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>

            {/* Notifications Trigger dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotificationDropdown(!showNotificationDropdown)}
                className="p-2.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 rounded-full cursor-pointer relative"
                title="System Notifications logs"
              >
                <Bell className="w-4 h-4" />
                {notifications.some(n => !n.read) && (
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
                )}
              </button>

              {/* Notification Overlay Menu */}
              {showNotificationDropdown && (
                <div className="absolute right-0 mt-3 w-80 bg-white border border-violet-100 rounded-[24px] shadow-[0_20px_50px_rgba(139,92,246,0.12)] p-4 space-y-3 z-50 text-left">
                  <div className="flex items-center justify-between pb-2 border-b border-violet-50">
                    <span className="text-[10px] font-mono font-bold text-[#8B5CF6] uppercase tracking-wider">
                      Events Notification Bell
                    </span>
                    <button 
                      onClick={clearAllNotifications}
                      className="text-[9.5px] font-bold text-zinc-400 hover:text-zinc-900 underline"
                    >
                      Mute All
                    </button>
                  </div>
                  <div className="space-y-2.5 max-h-60 overflow-y-auto scrollbar-thin">
                    {notifications.length > 0 ? (
                      notifications.map(n => (
                        <div key={n.id} className="p-2 bg-zinc-50/50 hover:bg-zinc-50 rounded-xl space-y-1 transition-colors">
                          <p className="text-[11px] text-zinc-700 leading-normal font-sans font-medium">{n.text}</p>
                          <span className="text-[9px] text-[#8B5CF6]/80 font-mono tracking-wider">{n.time}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-center py-6 text-zinc-400 text-xs font-mono">No new alerts caught in session.</p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Premium Live Environment Indicator */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F7F3FF] border border-violet-100 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9.5px] font-bold text-[#8B5CF6] font-mono uppercase tracking-wider">
                Live Server Synced
              </span>
            </div>
          </div>
        </header>

        {/* WORKBENCH CONTENT VIEW */}
        <div className="p-6 md:p-8 space-y-8" id="admin-dashboard-container">
          
          {/* TAB 1: DASHBOARD OVERVIEW */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-fade-in" id="tab-dashboard-overview">
              
              {/* Premium Hero greeting card */}
              <div className="bg-gradient-to-tr from-[#FAF8FF] to-white border border-violet-100/50 rounded-[32px] p-6 md:p-8 relative overflow-hidden shadow-xs">
                <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-[#F7F3FF]/40 rounded-full blur-3xl pointer-events-none" />
                <div className="relative space-y-2">
                  <span className="inline-block text-[10px] bg-[#F7F3FF] text-[#8B5CF6] border border-violet-100/40 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">
                    System Control Board
                  </span>
                  <h2 className="text-2xl md:text-3xl font-extrabold text-[#1D1D1F] tracking-tight">
                    Welcome back, {currentLoggedInUser?.name || 'Administrator'}
                  </h2>
                  <p className="text-xs text-zinc-500 max-w-xl leading-relaxed">
                    Here is an operational overview of your commerce parameters, security statistics, and technical inventories. Audit incoming packages below.
                  </p>
                </div>
              </div>

              {/* Bento Stats Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* 1. Total Revenue Card */}
                <div className="bg-white border border-violet-100/60 p-5 rounded-[24px] shadow-xs flex items-center gap-4 hover:border-violet-200 transition-all">
                  <div className="p-3 bg-[#F7F3FF] rounded-2.5xl text-[#8B5CF6] shrink-0">
                    <DollarSign className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <p className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                      Total Revenue
                    </p>
                    <h3 className="text-lg md:text-xl font-bold text-[#1D1D1F]">
                      {formatINR(stats.totalRevenue)}
                    </h3>
                  </div>
                </div>

                {/* 2. Gross Orders card */}
                <div className="bg-white border border-violet-100/60 p-5 rounded-[24px] shadow-xs flex items-center gap-4 hover:border-violet-200 transition-all">
                  <div className="p-3 bg-zinc-100 rounded-2.5xl text-zinc-950 shrink-0">
                    <ShoppingCart className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <p className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                      Gross Orders
                    </p>
                    <h3 className="text-lg md:text-xl font-bold text-[#1D1D1F]">
                      {stats.totalOrders} units
                    </h3>
                  </div>
                </div>

                {/* 3. Registered Profiles */}
                <div className="bg-white border border-violet-100/60 p-5 rounded-[24px] shadow-xs flex items-center gap-4 hover:border-violet-200 transition-all">
                  <div className="p-3 bg-[#F7F3FF] rounded-2.5xl text-[#8B5CF6] shrink-0">
                    <Users className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <p className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                      Our Customers
                    </p>
                    <h3 className="text-lg md:text-xl font-bold text-[#1D1D1F]">
                      {stats.totalUsers} profiles
                    </h3>
                  </div>
                </div>

                {/* 4. Active Catalog products */}
                <div className="bg-white border border-violet-100/60 p-5 rounded-[24px] shadow-xs flex items-center gap-4 hover:border-violet-200 transition-all">
                  <div className="p-3 bg-zinc-100 rounded-2.5xl text-zinc-950 shrink-0">
                    <Package className="w-5.5 h-5.5" />
                  </div>
                  <div>
                    <p className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest">
                      Active Models
                    </p>
                    <h3 className="text-lg md:text-xl font-bold text-[#1D1D1F]">
                      {stats.totalProducts} sizes
                    </h3>
                  </div>
                </div>

              </div>

              {/* Graphical Layout Block */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Custom Responsive SVG Chart of Earnings */}
                <div className="bg-white border border-violet-100/60 p-6 rounded-[28px] shadow-xs lg:col-span-2">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h4 className="font-bold text-sm text-[#1D1D1F]">Revenue & Conversion Trends</h4>
                      <p className="text-[10px] text-zinc-400 font-medium leading-relaxed mt-0.5">Real-time dynamic billing summaries tracked over current financial month.</p>
                    </div>
                    <span className="text-[9px] font-bold text-[#8B5CF6] bg-[#F7F3FF] px-2.5 py-1 rounded-full uppercase tracking-wider font-mono">
                      Currency: INR
                    </span>
                  </div>

                  {/* Aesthetic Area Chart Visualization */}
                  <div className="h-60 w-full flex items-end justify-between px-2 pt-6 pb-2 border-b border-violet-50 relative">
                    <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[9px] text-zinc-300 font-mono pb-8 pt-4">
                      <div className="border-b border-dashed border-zinc-100 w-full text-right pr-2">MAX RANGE</div>
                      <div className="border-b border-dashed border-zinc-100 w-full text-right pr-2">MID SECTOR</div>
                      <div className="border-b border-dashed border-zinc-15 w-full text-right pr-2">THRESHOLD</div>
                    </div>
                    {stats.monthlySales && stats.monthlySales.length > 0 ? (
                      stats.monthlySales.map((m: any, idx: number) => {
                        const maxVal = Math.max(...stats.monthlySales.map(item => item.sales), 50000);
                        const pct = (m.sales / maxVal) * 80; // Scaled
                        return (
                          <div key={idx} className="flex flex-col items-center flex-1 mx-2.5 h-full justify-end group relative z-10">
                            {/* Hover Details tooltip overlay */}
                            <div className="absolute bottom-full mb-2.5 hidden group-hover:block bg-zinc-950 text-white text-[9.5px] font-bold px-3 py-1.5 rounded-xl shadow-lg pointer-events-none z-10 whitespace-nowrap">
                              {formatINR(m.sales)} ({m.orders} items)
                            </div>
                            <div 
                              className="bg-zinc-950 hover:bg-[#8B5CF6] rounded-t-xl transition-all duration-300 w-full cursor-pointer shadow-sm shadow-violet-100"
                              style={{ height: `${Math.max(pct, 8)}%` }}
                            />
                            <span className="text-[10px] font-mono mt-3.5 text-zinc-400 font-bold uppercase tracking-wider">
                              {m.month}
                            </span>
                          </div>
                        );
                      })
                    ) : (
                      <p className="text-center text-xs text-zinc-400 w-full py-16 font-mono">No transactions yet</p>
                    )}
                  </div>
                </div>

                {/* Top Selling Products */}
                <div className="bg-white border border-violet-100/60 p-6 rounded-[28px] shadow-xs flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-[#1D1D1F] mb-1">Catalog Performance</h4>
                    <p className="text-[10px] text-zinc-400 font-medium leading-relaxed">Fast-moving devices listed by review ratings.</p>
                  </div>

                  <div className="space-y-4 my-5 flex-1 overflow-y-auto max-h-56 scrollbar-thin">
                    {products.slice(0, 4).map(p => (
                      <div key={p.id} className="flex items-center gap-3 p-1.5 hover:bg-zinc-50 rounded-xl transition-all">
                        <img 
                          src={p.images?.[0] || getFallbackImage(p.name)} 
                          alt={p.name}
                          className="w-10 h-10 object-cover rounded-xl border border-violet-100 bg-[#F7F3FF]/40 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0 flex-1">
                          <h5 className="text-[11.5px] font-extrabold text-[#1D1D1F] truncate leading-tight">
                            {p.name}
                          </h5>
                          <span className="text-[9.5px] text-zinc-400 font-semibold uppercase font-mono">
                            {p.category} • {p.stock} remaining
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-bold font-mono text-[#8B5CF6] block">
                            {formatINR(p.price)}
                          </span>
                          <span className="text-[9.5px] text-amber-500 font-bold uppercase tracking-wider flex items-center justify-end gap-0.5">
                            ★ {p.ratings?.average || '4.8'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setActiveTab('products')}
                    className="w-full py-3 bg-zinc-950 hover:bg-black text-white rounded-[16px] text-xs font-bold uppercase tracking-wider transition-all text-center cursor-pointer"
                  >
                    Manage Inventory Index
                  </button>
                </div>

              </div>

              {/* Transactions list row */}
              <div className="bg-white border border-violet-100/60 rounded-[28.5px] shadow-xs overflow-hidden">
                <div className="px-6 py-4.5 border-b border-violet-50 flex justify-between items-center bg-[#FAF8FF]/40">
                  <h4 className="font-bold text-sm text-[#1D1D1F]">Recent Inbound Shipments</h4>
                  <button 
                    onClick={() => setActiveTab('orders')} 
                    className="text-xs font-extrabold text-[#8B5CF6] hover:underline uppercase tracking-wider"
                  >
                    Open Orders Desk
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50 border-b border-violet-50 text-zinc-400 text-[10px] font-mono tracking-widest uppercase">
                        <th className="px-6 py-3">Order Code</th>
                        <th className="px-6 py-3">Buyer ID</th>
                        <th className="px-6 py-3">Hardware Finished</th>
                        <th className="px-6 py-3">Amount</th>
                        <th className="px-6 py-3">Gate Mode</th>
                        <th className="px-6 py-3">Chronology</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-violet-100/30 text-[#1D1D1F] font-sans">
                      {adminOrders.slice(0, 3).map(o => (
                        <tr key={o.id} className="hover:bg-zinc-55 transition-colors">
                          <td className="px-6 py-4.5 font-bold font-mono text-[#8B5CF6] select-all">{o.id}</td>
                          <td className="px-6 py-4.5 text-zinc-650 font-medium">{o.userName}</td>
                          <td className="px-6 py-4.5 truncate max-w-[220px]" title={o.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}>
                            {o.items.map(i => `${i.name}`).join(', ')}
                          </td>
                          <td className="px-6 py-4.5 font-bold text-zinc-950 font-mono">{formatINR(o.total)}</td>
                          <td className="px-6 py-4.5">
                            <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase font-mono border ${
                              o.status === 'delivered' 
                                ? 'bg-emerald-500/5 text-emerald-600 border-emerald-500/10' 
                                : o.status === 'cancelled' 
                                ? 'bg-red-500/5 text-red-500 border-red-500/10' 
                                : 'bg-amber-500/5 text-amber-500 border-amber-500/10'
                            }`}>
                              {o.status}
                            </span>
                          </td>
                          <td className="px-6 py-4.5 text-zinc-400 font-mono text-[10px] font-bold">
                            {new Date(o.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                      {adminOrders.length === 0 && (
                        <tr>
                          <td colSpan={6} className="text-center py-12 text-zinc-400 font-mono text-xs">No orders yet</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: PRODUCT MANAGEMENT */}
          {activeTab === 'products' && (
            <div className="space-y-8 animate-fade-in" id="tab-products-index">
              
              {/* Index Controls Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Active Hardware Inventory Catalog</h3>
                  <p className="text-xs text-zinc-400">Add, configure, image upload, videography or 360 models files live with Apple-standard bento templates.</p>
                </div>

                <button
                  onClick={() => {
                    setEditingProductId(null);
                    setProdName('');
                    setProdDesc('');
                    setSelectedColors([
                      { hex: '#D9C8B5', name: 'Desert Titanium' },
                      { hex: '#E7E2DC', name: 'Natural Titanium' }
                    ]);
                    setProdSpecs({
                      'Processor': 'A18 Pro chip with 6-core GPU',
                      'Display': '6.9-inch Super Retina XDR'
                    });
                    setShowProductForm(!showProductForm);
                  }}
                  className="bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-wider py-3 px-5 rounded-full shadow-sm flex items-center gap-2 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  {showProductForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {showProductForm ? 'Cancel Form Setup' : 'Add New Apple Device'}
                </button>
              </div>

              {/* DYNAMIC PRODUCT SUBMISSION & UPLOADER FORM */}
              {showProductForm && (
                <form 
                  onSubmit={handleProductSubmit}
                  className="bg-white border border-violet-100 rounded-[32px] p-6 shadow-[0_12px_44px_rgba(139,92,246,0.04)] space-y-6 animate-slide-up"
                >
                  <div className="border-b border-violet-50 pb-3 flex items-center justify-between">
                    <h4 className="font-extrabold text-sm text-[#1D1D1F] uppercase tracking-wider">
                      {editingProductId ? ` Modify specifications for ${prodName}` : ' Seed New Premium Hardware Entity'}
                    </h4>
                    <span className="text-[10px] bg-[#F7F3FF] text-[#8B5CF6] font-bold uppercase font-mono py-1 px-3 rounded-full">
                      Full-Stack Database Mode
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6.5">
                    
                    {/* Column 1: Descriptive Fields */}
                    <div className="space-y-4 md:col-span-2">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Device/Model Name</label>
                          <input 
                            type="text" 
                            className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                            placeholder="e.g. iPhone 16 Pro Max Ultra"
                            value={prodName}
                            onChange={(e) => setProdName(e.target.value)}
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Hardware Category Group</label>
                          <select 
                            className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl outline-none text-zinc-800"
                            value={prodCategory}
                            onChange={(e) => setProdCategory(e.target.value)}
                          >
                            <option value="iPhones">iPhones (Hardware)</option>
                            <option value="Macs">MacBooks (Desktop)</option>
                            <option value="Watches">Apple Watch (Sensory)</option>
                            <option value="Audio">AirPods (Aesthetics)</option>
                            <option value="Vision">Apple Vision (Spatial)</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Marketing Tagline / Description</label>
                        <textarea 
                          className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-semibold rounded-2xl outline-none h-16 resize-none"
                          placeholder="Exquisite detailing, Grade 5 titanium, Apple intelligence core processor limits..."
                          value={prodDesc}
                          onChange={(e) => setProdDesc(e.target.value)}
                          required
                        />
                      </div>

                      {/* Pricing, Stocks & capacity storage matrices */}
                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Retail Price (₹)</label>
                          <input 
                            type="number" 
                            className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-mono font-bold rounded-2xl outline-none"
                            placeholder="119900"
                            value={prodPrice}
                            onChange={(e) => setProdPrice(Number(e.target.value))}
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Percent Off (%)</label>
                          <input 
                            type="number" 
                            className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-mono font-bold rounded-2xl outline-none"
                            placeholder="0"
                            value={prodDiscount}
                            onChange={(e) => setProdDiscount(Number(e.target.value))}
                            min="0"
                            max="90"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Core Inventory Stock</label>
                          <input 
                            type="number" 
                            className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-mono font-bold rounded-2xl outline-none"
                            placeholder="15"
                            value={prodStock}
                            onChange={(e) => setProdStock(Number(e.target.value))}
                            required
                          />
                        </div>
                      </div>

                      {/* Media Assets: Images, Video embedding URL & 360 viewer assets */}
                      <div className="p-4 bg-[#FDEBFF]/10 rounded-[20px] border border-violet-100/40 space-y-3">
                        <h5 className="text-[10px] font-black uppercase tracking-wide text-[#8B5CF6] flex items-center gap-1.5">
                          <Play className="w-3.5 h-3.5" />
                          Immersive Multi-Media Assets config
                        </h5>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          <div className="space-y-1">
                            <label className="text-[9px] font-mono font-bold text-zinc-450 block px-0.5">High-Res Device JPG/PNG (Image)</label>
                            <input 
                              type="text" 
                              className="w-full px-3.5 py-2 bg-white border border-violet-100 focus:border-violet-200 text-[10.5px] font-mono rounded-xl outline-none"
                              placeholder="https://unsplash.com/..."
                              value={prodImageUrl}
                              onChange={(e) => setProdImageUrl(e.target.value)}
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[9px] font-mono font-bold text-zinc-450 block px-0.5 font-sans">Official Cinema Video URL (Commercial)</label>
                            <input 
                              type="text" 
                              className="w-full px-3.5 py-2 bg-white border border-violet-100 focus:border-violet-200 text-[10.5px] font-mono rounded-xl outline-none"
                              placeholder="https://youtube.com/embed/..."
                              value={prodVideoUrl}
                              onChange={(e) => setProdVideoUrl(e.target.value)}
                            />
                          </div>
                        </div>

                        {/* Interactive sequences setup (360 view toggle) */}
                        <div className="flex items-center justify-between pt-1">
                          <div>
                            <span className="text-[11px] font-semibold text-zinc-800 block">Pre-seed Interactive 360° Studio fineries?</span>
                            <span className="text-[9px] text-zinc-400 font-mono">Generates dynamic rotating sequence models when customer sweeps cursor across detailed details window.</span>
                          </div>
                          
                          <label className="relative inline-flex items-center cursor-pointer select-none">
                            <input 
                              type="checkbox" 
                              checked={has360Model} 
                              onChange={(e) => setHas360Model(e.target.checked)} 
                              className="sr-only peer" 
                            />
                            <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#8B5CF6]"></div>
                          </label>
                        </div>
                      </div>

                    </div>

                    {/* Column 2: Colors, Custom technical Specifications, Memory matrices */}
                    <div className="space-y-4">
                      
                      {/* Color finisher catalog */}
                      <div className="space-y-2.5 p-3.5 bg-zinc-50 border border-zinc-200/50 rounded-2xl">
                        <span className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block">Finishes & Colors Matrix</span>
                        <div className="flex flex-wrap gap-2">
                          {selectedColors.map((color, cidx) => (
                            <span key={cidx} className="flex items-center gap-1.5 px-2 py-1 bg-white border border-zinc-200 rounded-full text-[9px] font-bold">
                              <span className="w-2.5 h-2.5 rounded-full border border-zinc-200 block shadow-inner" style={{ backgroundColor: color.hex }} />
                              {color.name}
                              <button 
                                type="button" 
                                onClick={() => setSelectedColors(selectedColors.filter((_, i) => i !== cidx))}
                                className="text-zinc-400 hover:text-black hover:scale-110 ml-0.5"
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))}
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <input 
                            type="text" 
                            placeholder="Natural Gold" 
                            className="bg-white border border-zinc-200 outline-none text-[10px] rounded-lg px-2 py-1.5 text-zinc-700"
                            value={prodColorName}
                            onChange={(e) => setProdColorName(e.target.value)}
                          />
                          <div className="flex items-center gap-1 bg-white border border-zinc-200 rounded-lg px-1 py-0.5">
                            <input 
                              type="color" 
                              className="w-6 h-6 border-0 outline-none cursor-pointer"
                              value={prodColorHex}
                              onChange={(e) => setProdColorHex(e.target.value)}
                            />
                            <button 
                              type="button" 
                              onClick={handleAddColor}
                              className="bg-zinc-950 text-white rounded-md text-[8.5px] font-bold uppercase py-1 px-2 hover:bg-black w-full"
                            >
                              Add Color
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Technical specifications key-value store specs */}
                      <div className="space-y-2.5 p-3.5 bg-zinc-50 border border-zinc-200/50 rounded-2xl">
                        <span className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block">Dynamic Device Specs</span>
                        
                        <div className="space-y-1.5 max-h-24 overflow-y-auto pr-1">
                          {Object.keys(prodSpecs).map((key) => (
                            <div key={key} className="flex justify-between items-center text-[10px] font-medium bg-white px-2 py-1.5 border border-zinc-200/30 rounded-lg">
                              <span className="font-bold text-zinc-805 truncate w-20">{key}:</span>
                              <span className="text-zinc-500 truncate w-32 text-right">{prodSpecs[key]}</span>
                              <button 
                                type="button" 
                                onClick={() => {
                                  const cpy = { ...prodSpecs };
                                  delete cpy[key];
                                  setProdSpecs(cpy);
                                }}
                                className="text-zinc-400 hover:text-red-500 hover:scale-105 shrink-0 ml-1"
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          ))}
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-zinc-250/20">
                          <input 
                            type="text" 
                            placeholder="Processor" 
                            className="bg-white border border-zinc-200 outline-none text-[10px] rounded-lg px-2 py-1"
                            value={prodSpecKey}
                            onChange={(e) => setProdSpecKey(e.target.value)}
                          />
                          <input 
                            type="text" 
                            placeholder="A18 Pro Silicon" 
                            className="bg-white border border-zinc-200 outline-none text-[10px] rounded-lg px-2 py-1"
                            value={prodSpecVal}
                            onChange={(e) => setProdSpecVal(e.target.value)}
                          />
                        </div>
                        <button
                          type="button"
                          onClick={handleAddSpec}
                          className="w-full py-1.5 bg-zinc-950 text-white rounded-xl text-[9px] font-bold uppercase tracking-wide hover:bg-black"
                        >
                          Push Technical specification
                        </button>
                      </div>

                    </div>

                  </div>

                  {/* Form Submission action button */}
                  <div className="flex justify-end gap-3.5 border-t border-violet-50 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowProductForm(false)}
                      className="px-4.5 py-2.5 text-xs font-bold text-zinc-500 hover:text-[#1D1D1F] uppercase tracking-wider block"
                    >
                      Dismiss
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-2.5 bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold uppercase tracking-wider rounded-full shadow-md cursor-pointer transition-all hover:scale-[1.01]"
                    >
                      {editingProductId ? 'Apply Modified Parameters' : 'Publish New Apple Device'}
                    </button>
                  </div>

                </form>
              )}

              {/* Responsive Product Index list */}
              <div className="bg-white border border-violet-100/60 rounded-[28.5px] shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-zinc-55/70 border-b border-violet-50 text-zinc-400 text-[10px] font-mono tracking-widest uppercase">
                        <th className="px-6 py-3.5">Device finery</th>
                        <th className="px-6 py-3.5">Category Group</th>
                        <th className="px-6 py-3.5">Basic Price</th>
                        <th className="px-6 py-3.5">Promo Reduction</th>
                        <th className="px-6 py-3.5">Dynamic Stock Status</th>
                        <th className="px-6 py-3.5">Colors finish count</th>
                        <th className="px-6 py-3.5 text-right">Erase or modify</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-violet-100/30 text-zinc-900 font-sans">
                      {filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-zinc-50/50 transition-colors">
                          <td className="px-6 py-4.5 flex items-center gap-3">
                            <img 
                              src={p.images?.[0] || getFallbackImage(p.name)} 
                              alt="Apple Device model" 
                              className="w-10 h-10 object-cover rounded-xl border border-violet-50 bg-[#F7F3FF]/40 shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <p className="font-extrabold text-[#1D1D1F] truncate max-w-[170px]" title={p.name}>{p.name}</p>
                              <span className="text-[10px] text-[#8B5CF6] font-semibold bg-[#F7F3FF] px-2 py-0.5 rounded-md font-mono">{p.id}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4.5 font-bold text-zinc-500 uppercase tracking-wider font-mono text-[10.5px]">
                            {p.category}
                          </td>
                          <td className="px-6 py-4.5 font-bold text-[#1D1D1F] font-mono">
                            {formatINR(p.price)}
                          </td>
                          <td className="px-6 py-4.5 text-red-500 font-bold font-mono">
                            {p.discount > 0 ? `${p.discount}% OFF` : 'None'}
                          </td>
                          <td className="px-6 py-4.5">
                            <span className={`px-2.5 py-1 rounded-full text-[9.5px] font-extrabold uppercase font-mono border ${
                              p.stock < 5 
                                ? 'bg-rose-500/5 text-rose-500 border-rose-500/15' 
                                : 'bg-emerald-500/5 text-emerald-600 border-emerald-500/15'
                            }`}>
                              {p.stock} units remaining
                            </span>
                          </td>
                          <td className="px-4.5 py-4.5 font-mono text-zinc-400 font-bold">
                            {p.colors?.length || 1} tones
                          </td>
                          <td className="px-6 py-4.5 text-right">
                            <div className="flex gap-3 justify-end items-center h-full">
                              <button 
                                onClick={() => startEditProduct(p)} 
                                className="p-2 bg-zinc-100 hover:bg-[#F7F3FF] text-zinc-650 hover:text-[#8B5CF6] rounded-xl transition-colors cursor-pointer"
                                title="Edit specs payload"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button 
                                onClick={() => { if (window.confirm(`Delete ${p.name} from global databases?`)) deleteAdminProduct(p.id); }} 
                                className="p-2 bg-zinc-100 hover:bg-rose-50 text-zinc-650 hover:text-rose-500 rounded-xl transition-colors cursor-pointer"
                                title="Delete from catalog"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Categories management block */}
              <div className="bg-white border border-violet-100/60 p-6 rounded-[28px] shadow-xs space-y-6">
                <div>
                  <h4 className="font-extrabold text-sm text-[#1D1D1F] uppercase tracking-wider flex items-center gap-2">
                    <Grid className="w-4 h-4 text-[#8B5CF6]" />
                    Interactive Store categories Index
                  </h4>
                  <p className="text-xs text-zinc-400">Add or manage categories list referenced across browse filters.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Category addition form */}
                  <form onSubmit={handleCategorySubmit} className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Browse Label Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Beats Audio Series"
                        className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                        value={catName}
                        onChange={(e) => setCatName(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Secondary description label</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Ultra high-fidelity noise cancellation tech."
                        className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                        value={catDesc}
                        onChange={(e) => setCatDesc(e.target.value)}
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-2xl cursor-pointer"
                    >
                      Construct New Category
                    </button>
                  </form>

                  {/* Category lists */}
                  <div className="space-y-3.5 overflow-y-auto max-h-56 pr-2 scrollbar-thin">
                    {adminCategories.map(c => (
                      <div key={c.id} className="flex justify-between items-center bg-[#FAF8FF]/40 border border-violet-100/30 p-3.5 rounded-2xl">
                        <div>
                          <p className="font-extrabold text-xs text-[#1D1D1F] uppercase tracking-wider">{c.name}</p>
                          <p className="text-[10px] text-zinc-400 font-semibold">{c.description || 'Generic technical finish catalog'}</p>
                        </div>
                        <button
                          onClick={() => deleteCategory(c.id)}
                          className="p-1.5 hover:bg-rose-50 text-zinc-400 hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                          title="Erase category structure"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                    {adminCategories.length === 0 && (
                      <p className="text-center py-10 font-mono text-xs text-zinc-400">No category groups constructs saved in local SQLite storage yet.</p>
                    )}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 3: CUSTOMER ORDERS VIEW */}
          {activeTab === 'orders' && (
            <div className="space-y-8 animate-fade-in text-left">
              
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Audit and Ship Orders Registry</h3>
                  <p className="text-xs text-zinc-400 font-semibold">Change logistic transit state tracking information, filter pending requests, cancellation reviews, or refund proposals below.</p>
                </div>
              </div>

              {/* Category Filter Capsules */}
              <div className="flex pb-1 overflow-x-auto gap-2.5 scrollbar-none select-none">
                {(['ALL', 'PENDING', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED', 'REFUNDS'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setOrderStatusFilter(tab)}
                    className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider font-mono border transition-all cursor-pointer whitespace-nowrap ${
                      orderStatusFilter === tab
                        ? 'bg-zinc-950 text-white border-transparent shadow-sm'
                        : 'bg-white text-zinc-500 border-zinc-150/60 hover:bg-zinc-50'
                    }`}
                  >
                    {tab === 'REFUNDS' ? 'Refund Requests' : tab}
                  </button>
                ))}
              </div>

              {/* Expandable Order Cards List */}
              <div className="space-y-4">
                {filteredOrders.length > 0 ? (
                  filteredOrders.map(o => {
                    const isExpanded = expandedOrders[o.id] || false;
                    const itemsCount = o.items ? o.items.reduce((sum, item) => sum + item.quantity, 0) : 0;
                    const customerRecord = adminUsers.find(u => u.id === o.userId);
                    const userEmail = customerRecord?.email || `${o.userName.toLowerCase().replace(/\s+/g, '')}@gmail.com`;
                    const userPhone = o.shippingAddress.phone || customerRecord?.addresses?.[0]?.phone || '9988776655';
                    
                    return (
                      <div 
                        key={o.id} 
                        className="bg-white border border-zinc-200/50 rounded-[24px] shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden"
                      >
                        {/* Summary Header block */}
                        <div 
                          className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer select-none"
                          onClick={() => toggleOrderExpanded(o.id)}
                        >
                          <div className="flex items-start gap-4">
                            <div className="bg-[#F6F3FA] p-3 rounded-2xl text-zinc-800 flex items-center justify-center shrink-0">
                              <Package className="w-5.5 h-5.5" />
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-sm text-zinc-900 font-mono tracking-tight">#{o.id}</span>
                                <span className="text-[10.5px] text-zinc-400 font-semibold font-mono">
                                  {new Date(o.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-xs text-zinc-800">{o.userName}</span>
                                <span className="text-[10px] text-zinc-400 font-mono font-semibold">({userEmail})</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex flex-wrap md:flex-nowrap items-center gap-4.5 justify-between md:justify-end">
                            <div className="text-left md:text-right">
                              <p className="text-[9px] text-zinc-400 font-mono uppercase font-bold tracking-wider">Grand Total</p>
                              <span className="font-extrabold text-sm text-zinc-950 font-mono">{formatINR(o.total)}</span>
                              <span className="text-[10px] text-zinc-400 block font-semibold">{itemsCount} product{itemsCount !== 1 ? 's' : ''}</span>
                            </div>

                            <div className="flex items-center gap-3">
                              {/* Custom Styled Status badges */}
                              {o.status === 'pending' && (
                                <span className="px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-amber-50 text-amber-600 border border-amber-200">Pending</span>
                              )}
                              {o.status === 'processing' && (
                                <span className="px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-blue-50 text-blue-600 border border-blue-200">Processing</span>
                              )}
                              {o.status === 'shipped' && (
                                <span className="px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-purple-50 text-purple-600 border border-purple-200">Shipped</span>
                              )}
                              {o.status === 'delivered' && (
                                <span className="px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-emerald-50 text-emerald-600 border border-emerald-200">Delivered</span>
                              )}
                              {o.status === 'cancelled' && (
                                <span className="px-3 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-widest bg-rose-50 text-rose-600 border border-rose-200">Cancelled</span>
                              )}

                              {/* Toggle Control Chevron */}
                              <button className="p-2 bg-zinc-50 hover:bg-zinc-100 rounded-full text-zinc-500 transition-transform">
                                <ChevronDown className={`w-4.5 h-4.5 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Expandable Section Board */}
                        {isExpanded && (
                          <div className="p-6 border-t border-zinc-100 bg-[#FDFCFF] space-y-6">
                            
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 text-left">
                              
                              {/* Left sidebar block: Customer profile history + Complete address parameters */}
                              <div className="md:col-span-4 space-y-4">
                                <h4 className="font-extrabold text-[#1D1D1F] text-xs font-mono tracking-wider uppercase border-b border-zinc-100 pb-2 flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-zinc-950" />
                                  Shipping Coordinates
                                </h4>
                                <div className="bg-white p-4.5 rounded-2xl border border-zinc-200/60 space-y-3.5 shadow-2xs">
                                  
                                  <div className="space-y-0.5">
                                    <p className="text-[9px] text-[#8B5CF6] font-mono font-bold uppercase tracking-wider">Consignee Name</p>
                                    <p className="font-extrabold text-xs text-zinc-900">{o.shippingAddress.name}</p>
                                  </div>

                                  <div className="grid grid-cols-2 gap-3.5 border-t border-zinc-100 pt-3">
                                    <div className="space-y-0.5">
                                      <p className="text-[9px] text-zinc-400 font-mono font-bold uppercase tracking-wider">Phone number</p>
                                      <p className="font-semibold text-xs text-zinc-800 flex items-center gap-1 font-mono">
                                        <Phone className="w-3 h-3 text-zinc-400 shrink-0" />
                                        {userPhone}
                                      </p>
                                    </div>
                                    <div className="space-y-0.5">
                                      <p className="text-[9px] text-zinc-400 font-mono font-bold uppercase tracking-wider">Email address</p>
                                      <p className="font-semibold text-xs text-zinc-700 truncate block font-mono" title={userEmail}>
                                        {userEmail}
                                      </p>
                                    </div>
                                  </div>

                                  <div className="space-y-2 border-t border-zinc-100 pt-3 text-[11px] text-zinc-600 leading-normal">
                                    <div className="space-y-0.5">
                                      <p className="text-[9px] text-zinc-400 font-mono font-bold uppercase tracking-wider">Street / Locality</p>
                                      <p className="font-semibold text-zinc-800">
                                        {o.shippingAddress.line1}
                                        {o.shippingAddress.line2 ? `, ${o.shippingAddress.line2}` : ''}
                                      </p>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-3 pb-1">
                                      <div>
                                        <p className="text-[9px] text-zinc-400 font-mono uppercase tracking-wider">City</p>
                                        <p className="font-semibold text-zinc-900">{o.shippingAddress.city}</p>
                                      </div>
                                      <div>
                                        <p className="text-[9px] text-zinc-400 font-mono uppercase tracking-wider">State</p>
                                        <p className="font-semibold text-zinc-900">{o.shippingAddress.state}</p>
                                      </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-zinc-100">
                                      <div>
                                        <p className="text-[9px] text-zinc-400 font-mono uppercase tracking-wider">PIN / Postal Code</p>
                                        <p className="font-bold text-zinc-900 font-mono">{o.shippingAddress.postalCode || '400001'}</p>
                                      </div>
                                      <div>
                                        <p className="text-[9px] text-zinc-400 font-mono uppercase tracking-wider">Country</p>
                                        <p className="font-semibold text-zinc-850">{o.shippingAddress.country || 'India'}</p>
                                      </div>
                                    </div>
                                  </div>

                                </div>
                              </div>

                              {/* Center block: Ordered Product Cart Inventory */}
                              <div className="md:col-span-5 space-y-4">
                                <h4 className="font-extrabold text-[#1D1D1F] text-xs font-mono tracking-wider uppercase border-b border-zinc-100 pb-2">
                                  Purchased Devices ({itemsCount})
                                </h4>
                                <div className="space-y-3 max-h-76 overflow-y-auto pr-1.5 scrollbar-thin">
                                  {o.items ? o.items.map((item, idx) => {
                                    return (
                                      <div key={idx} className="flex gap-3 bg-white p-3 rounded-2xl border border-zinc-150/60">
                                        <img 
                                          src={item.image || getFallbackImage(item.name, item.color)} 
                                          alt={item.name} 
                                          className="w-12 h-12 object-contain bg-[#F7F3FF]/40 rounded-xl border border-zinc-100 p-0.5 shrink-0"
                                          referrerPolicy="no-referrer"
                                          onError={(e) => {
                                            e.currentTarget.onerror = null;
                                            e.currentTarget.src = getFallbackImage(item.name, item.color);
                                          }}
                                        />
                                        <div className="space-y-1 text-[11.5px] min-w-0 flex-1">
                                          <p className="font-black text-zinc-900 leading-tight truncate">{item.name}</p>
                                          
                                          <div className="flex gap-2 text-[9.5px] font-mono tracking-wide text-zinc-400 font-semibold uppercase">
                                            {item.color && (
                                              <span className="flex items-center gap-1 font-mono">
                                                <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ backgroundColor: item.color }} />
                                                {item.color}
                                              </span>
                                            )}
                                            {item.storage && <span>{item.storage}</span>}
                                          </div>

                                          <div className="flex justify-between items-center text-[10.5px]">
                                            <span className="text-zinc-500 font-mono">{formatINR(item.priceAtPurchase)} × {item.quantity}</span>
                                            <span className="font-extrabold text-zinc-950 font-mono">{formatINR(item.priceAtPurchase * item.quantity)}</span>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  }) : null}
                                </div>
                              </div>

                              {/* Right block: Logistics select box, updates, & printable invoice download triggers */}
                              <div className="md:col-span-3 space-y-4">
                                <h4 className="font-extrabold text-[#1D1D1F] text-xs font-mono tracking-wider uppercase border-b border-zinc-100 pb-2">
                                  Compliance & Logistics
                                </h4>
                                <div className="bg-white p-4.5 rounded-2xl border border-zinc-200/60 space-y-4 shadow-2xs">
                                  
                                  {/* Total calculation stats */}
                                  <div className="space-y-1.5 text-[11px] border-b border-zinc-100 pb-3">
                                    <div className="flex justify-between">
                                      <span className="text-zinc-400 font-semibold">Subtotal:</span>
                                      <span className="font-semibold text-zinc-900 font-mono">{formatINR(o.subtotal || o.total)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-zinc-400 font-semibold">Promo code:</span>
                                      <span className="font-semibold text-emerald-600 font-mono">-{formatINR(o.discount || 0)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-zinc-400 font-semibold">GST/Cess (18%):</span>
                                      <span className="font-semibold text-zinc-900 font-mono">+{formatINR(o.tax || 0)}</span>
                                    </div>
                                    <div className="flex justify-between pt-1.5 border-t border-zinc-100 text-xs">
                                      <span className="font-extrabold text-zinc-900">Total Charged:</span>
                                      <span className="font-black text-black font-mono">{formatINR(o.total)}</span>
                                    </div>
                                  </div>

                                  {/* Live controls */}
                                  <div className="space-y-2.5">
                                    <div>
                                      <label className="text-[8.5px] font-mono font-black text-zinc-400 uppercase tracking-widest block mb-1">Transit Status</label>
                                      <select
                                        className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200/50 rounded-xl text-xs uppercase font-extrabold tracking-wider cursor-pointer outline-none text-zinc-800"
                                        value={o.status || 'pending'}
                                        onChange={(e) => updateOrderStatus(o.id, e.target.value as any, o.trackingNumber)}
                                      >
                                        <option value="pending" className="text-amber-500 font-bold">Pending Approval</option>
                                        <option value="processing" className="text-blue-500 font-bold">Processing Order</option>
                                        <option value="shipped" className="text-purple-500 font-bold">Shipped Package</option>
                                        <option value="delivered" className="text-emerald-500 font-bold">Delivered Signed</option>
                                        <option value="cancelled" className="text-red-500 font-bold">Cancelled Void</option>
                                      </select>
                                    </div>

                                    <div>
                                      <label className="text-[8.5px] font-mono font-black text-zinc-400 uppercase tracking-widest block mb-1">Air Waybill Number</label>
                                      <input 
                                        type="text"
                                        className="w-full px-3 py-2 bg-zinc-50 hover:bg-zinc-100 focus:bg-white text-xs font-mono tracking-wider outline-none border border-zinc-200/50 focus:border-black rounded-xl font-bold text-zinc-800"
                                        value={o.trackingNumber || ''}
                                        onChange={(e) => updateOrderStatus(o.id, o.status, e.target.value)}
                                        placeholder="Set Waybill #"
                                      />
                                    </div>
                                  </div>

                                  {/* Custom Printable Invoice Downloader CTA */}
                                  <div className="pt-2 border-t border-zinc-100">
                                    <button
                                      onClick={() => setActiveInvoiceOrder(o)}
                                      className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 bg-zinc-950 hover:bg-black text-white rounded-xl text-xs font-bold transition-all hover:shadow-xs cursor-pointer uppercase tracking-wider"
                                    >
                                      <Printer className="w-4 h-4 shrink-0" />
                                      Generate Invoice
                                    </button>
                                  </div>

                                </div>
                              </div>

                            </div>

                          </div>
                        )}
                      </div>
                    );
                  })
                ) : (
                  <div className="bg-white border border-zinc-200/40 rounded-[28px] p-12 text-center shadow-xs">
                    <FileSpreadsheet className="w-12 h-12 text-zinc-350 mx-auto mb-3" />
                    <p className="text-zinc-500 font-semibold text-xs font-mono">No matching customer orders found in registry databases.</p>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 4: CUSTOMERS & USER REGISTRY */}
          {activeTab === 'customers' && (
            <div className="space-y-6 animate-fade-in text-left" id="tab-customers-list">
              <div>
                <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Registered Profiles & Account Security</h3>
                <p className="text-xs text-zinc-400">Block misbehaving devices, manage privileges, and review administrative clearance parameters.</p>
              </div>

              <div className="bg-white border border-violet-100/60 rounded-[28.5px] overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50 border-b border-violet-50 text-zinc-400 text-[9.5px] font-mono tracking-widest uppercase">
                        <th className="px-6 py-3.5">Device Identifier</th>
                        <th className="px-6 py-3.5">Full Name</th>
                        <th className="px-6 py-3.5">Electronic Mail (Email)</th>
                        <th className="px-6 py-3.5">Authorized Role</th>
                        <th className="px-6 py-3.5">Enrolled on date</th>
                        <th className="px-6 py-3.5 text-right">Moderator Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-violet-100/30 text-zinc-800">
                      {filteredUsers.map(u => (
                        <tr key={u.id} className="hover:bg-zinc-50/30 transition-colors">
                          <td className="px-6 py-4.5 font-mono text-[10px] text-zinc-400 select-all">
                            {u.id}
                          </td>
                          <td className="px-6 py-4.5 font-extrabold text-[#1D1D1F]">
                            {u.name}
                          </td>
                          <td className="px-6 py-4.5 font-medium text-zinc-600">
                            {u.email}
                          </td>
                          <td className="px-6 py-4.5">
                            <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase font-mono tracking-wider ${
                              u.role === 'admin' 
                                ? 'bg-emerald-500/5 text-emerald-600 border border-emerald-500/10' 
                                : 'bg-zinc-100 text-zinc-500'
                            }`}>
                              {u.role}
                            </span>
                          </td>
                          <td className="px-6 py-4.5 text-zinc-400 font-mono font-bold">
                            {new Date(u.createdAt || '2026-06-20').toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4.5 text-right flex gap-3 justify-end items-center">
                            <button
                              onClick={() => blockUser(u.id, !u.blocked)}
                              className={`px-3 py-1.5 text-[9.5px] font-bold rounded-xl flex items-center gap-1 uppercase tracking-wider transition-all border cursor-pointer ${
                                u.blocked 
                                  ? 'bg-rose-500 text-white border-transparent shadow shadow-rose-100' 
                                  : 'bg-white text-zinc-650 hover:bg-zinc-100 border-zinc-200'
                              }`}
                            >
                              <ShieldX className="w-3.5 h-3.5 shrink-0" />
                              {u.blocked ? 'BLOCKED' : 'SUSPEND'}
                            </button>
                            
                            <button
                              onClick={() => { if (window.confirm('Erase this customer profile completely? This action is permanent.')) deleteUser(u.id); }}
                              className="p-1.5 hover:bg-zinc-100 text-zinc-400 hover:text-black rounded-lg transition-colors cursor-pointer"
                              title="Delete profile"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {filteredUsers.length === 0 && (
                        <tr>
                          <td colSpan={6} className="text-center py-12 text-zinc-400 font-mono text-xs">No customers yet</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 5: PAYMENTS & FINANCIALS */}
          {activeTab === 'payments' && (
            <div className="space-y-6 animate-fade-in text-left" id="tab-payments-ledger">
              <div>
                <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Payments ledger ledger & Settlement Reports</h3>
                <p className="text-xs text-zinc-400">Review total billing lists, active refunds, and virtual clearance thresholds.</p>
              </div>

              {/* Stat grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-5 bg-white border border-violet-100/60 rounded-[24px]">
                  <span className="text-[9.5px] font-mono font-bold text-zinc-450 uppercase block">Total Net settlements</span>
                  <p className="text-2xl font-black mt-1 text-[#1D1D1F]">{formatINR(stats.totalRevenue)}</p>
                  <span className="text-[9.5px] text-emerald-500 font-bold block mt-1">✓ Verified by standard HDFC/ICICI pathways</span>
                </div>

                <div className="p-5 bg-white border border-violet-100/60 rounded-[24px]">
                  <span className="text-[9.5px] font-mono font-bold text-zinc-455 uppercase block">Pending Settlement hold</span>
                  <p className="text-2xl font-black mt-1 text-zinc-650">₹0</p>
                  <span className="text-[9.5px] text-zinc-400 font-semibold block mt-1">✓ Automated instant settlement active</span>
                </div>

                <div className="p-5 bg-white border border-violet-100/60 rounded-[24px]">
                  <span className="text-[9.5px] font-mono font-bold text-zinc-455 uppercase block">Refund requests processed</span>
                  <p className="text-2xl font-black mt-1 text-rose-500">₹0</p>
                  <span className="text-[9.5px] text-rose-400 font-semibold block mt-1">0 active claims outstanding</span>
                </div>
              </div>

              <div className="bg-white border border-violet-100/60 rounded-[28.5px] overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50 border-b border-violet-50 text-zinc-400 text-[9.5px] font-mono tracking-widest uppercase">
                        <th className="px-6 py-3.5">Gateway Reference</th>
                        <th className="px-6 py-3.5">Amount Transacted</th>
                        <th className="px-6 py-3.5">Source Method</th>
                        <th className="px-6 py-3.5">Dynamic Payout state</th>
                        <th className="px-6 py-3.5 text-right">Instant validation</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-violet-100/30 text-zinc-850">
                      {adminOrders.map(o => (
                        <tr key={o.id} className="hover:bg-zinc-50/30 transition-colors">
                          <td className="px-6 py-4.5 font-bold font-mono text-[#8B5CF6]">TXN-SRC-{o.id.toUpperCase()}</td>
                          <td className="px-6 py-4.5 font-bold font-mono text-zinc-950">{formatINR(o.total)}</td>
                          <td className="px-6 py-4.5 font-bold text-zinc-500 uppercase tracking-widest text-[9.5px]">MasterCard Premium Checkout</td>
                          <td className="px-6 py-4.5">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-600 border border-emerald-100">SETTLED</span>
                          </td>
                          <td className="px-6 py-4.5 text-right">
                            <span className="text-emerald-500 text-[10.5px] font-bold">✓ Secured</span>
                          </td>
                        </tr>
                      ))}
                      {adminOrders.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center py-12 text-zinc-400 font-mono text-xs">No transactions yet</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 6: PREMIUM GENERAL COUPONS */}
          {activeTab === 'coupons' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in text-left" id="tab-coupons-index">
              
              {/* Box 1: Create Coupons form */}
              <div className="bg-white border border-violet-100/60 p-6 rounded-[28px] shadow-xs space-y-6">
                <div>
                  <h4 className="font-extrabold text-sm text-[#1D1D1F] uppercase tracking-wider flex items-center gap-2">
                    <Percent className="w-4.5 h-4.5 text-[#8B5CF6]" />
                    Dynamic Promotional Codes Console
                  </h4>
                  <p className="text-xs text-zinc-400">Generate special discounts sequence directly stored in backend schema.</p>
                </div>

                <form onSubmit={handleCouponSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Promo Coupon Code</label>
                    <input 
                      type="text" 
                      placeholder="e.g. APPLEINTELLIGENCE"
                      className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl uppercase outline-none"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Percentage off (%)</label>
                    <input 
                      type="number"
                      className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                      min="1"
                      max="90"
                      value={couponPercent}
                      onChange={(e) => setCouponPercent(Number(e.target.value))}
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-2xl shadow-sm transition-transform hover:scale-[1.01]"
                  >
                    Authorize Promo Code
                  </button>
                </form>
              </div>

              {/* Box 2: Coupons Lists */}
              <div className="bg-white border border-[#E9E4F2] p-6 rounded-[28px] shadow-xs space-y-4">
                <span className="text-[9.5px] font-mono font-bold text-[#8B5CF6] uppercase tracking-widest block">Active Global Coupons</span>
                
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1 scrollbar-thin">
                  {adminCoupons.map(c => (
                    <div key={c.code} className="flex justify-between items-center bg-[#FAF8FF]/40 border border-violet-100/40 p-3.5 rounded-2xl">
                      <div>
                        <span className="font-mono font-bold text-xs bg-white border border-[#DDD] px-2.5 py-1 rounded-xl text-zinc-950">
                          {c.code}
                        </span>
                        <span className="ml-3 font-bold text-xs text-[#8B5CF6]">
                          {c.discountPercent}% OFF total cart value
                        </span>
                      </div>

                      <button
                        onClick={() => deleteCoupon(c.code)}
                        className="p-1 px-2.5 bg-rose-50 text-rose-500 rounded-lg text-xs font-bold flex items-center hover:bg-rose-100 cursor-pointer"
                        title="Delete active code"
                      >
                        <Trash2 className="w-3.5 h-3.5 shrink-0 mr-1" />
                        Kill
                      </button>
                    </div>
                  ))}
                  {adminCoupons.length === 0 && (
                    <p className="text-center py-12 text-zinc-450 font-mono text-xs">No saved Coupons. Ready to generate high-conversion tags!</p>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* TAB 7: REVIEWS MODERATION PANEL */}
          {activeTab === 'reviews' && (
            <div className="space-y-6 animate-fade-in text-left font-sans" id="tab-reviews-moderation">
              <div>
                <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Active User Reviews Moderation Hub</h3>
                <p className="text-xs text-zinc-400">Moderate customer ratings, delete bad reviews, and track product quality metrics.</p>
              </div>

              <div className="bg-white border border-violet-100/60 rounded-[28.5px] overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="bg-zinc-50/50 border-b border-violet-50 text-zinc-400 text-[9.5px] font-mono tracking-widest uppercase">
                        <th className="px-6 py-3.5">Device Referenced</th>
                        <th className="px-6 py-3.5">Reviewer Account</th>
                        <th className="px-6 py-3.5">Customer Rating</th>
                        <th className="px-6 py-3.5">Verbatim feedback comment</th>
                        <th className="px-6 py-3.5 font-sans">Created on</th>
                        <th className="px-6 py-3.5 text-right w-24">Moderate</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-violet-100/30 text-zinc-800">
                      {aggregateReviews.map((r, rIdx) => (
                        <tr key={rIdx} className="hover:bg-zinc-50/20 transition-colors">
                          <td className="px-6 py-4.5">
                            <p className="font-extrabold text-[#1D1D1F] truncate max-w-[150px]">{r.productName}</p>
                            <span className="text-[9px] text-[#8B5CF6] font-mono uppercase font-bold">{r.productId}</span>
                          </td>
                          <td className="px-6 py-4.5 font-bold text-zinc-600">
                            {r.review.userName}
                          </td>
                          <td className="px-6 py-4.5">
                            <span className="text-amber-500 font-extrabold flex items-center gap-0.5">
                              ★ {r.review.rating}/5
                            </span>
                          </td>
                          <td className="px-6 py-4.5 italic text-zinc-500 max-w-xs truncate" title={r.review.comment}>
                            "{r.review.comment}"
                          </td>
                          <td className="px-6 py-4.5 font-mono text-zinc-400 font-bold">
                            {new Date(r.review.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4.5 text-right">
                            <button
                              onClick={() => {
                                alert('Review flagged as audited. In dynamic database, edit products to strip individual comments.');
                              }}
                              className="px-2.5 py-1.5 bg-zinc-50 hover:bg-zinc-100 hover:text-black border border-zinc-200 text-[10px] font-bold uppercase rounded-lg transition-colors cursor-pointer"
                              title="Flag or delete comment"
                            >
                              Approve
                            </button>
                          </td>
                        </tr>
                      ))}
                      {aggregateReviews.length === 0 && (
                        <tr>
                          <td colSpan={6} className="text-center py-12 text-zinc-400 font-mono">No review feedback comments registered yet in store metadata.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 8: CONVERSION ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-8 animate-fade-in text-left font-sans" id="tab-analytics-projection">
              <div>
                <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">Interactive conversion Analytics Dashboard</h3>
                <p className="text-xs text-zinc-400">Review interactive hardware metrics, visitor logs, and standard projection targets.</p>
              </div>

              {/* Conversion metrics cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Visualizer 1 */}
                <div className="p-6 bg-white border border-violet-100/60 rounded-[28px] space-y-4">
                  <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] font-mono uppercase tracking-widest font-extrabold px-3 py-1 rounded-full">
                    Visits Conversion Funnel
                  </span>
                  
                  <div className="space-y-2.5 pt-2">
                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span>Checkout Initiated</span>
                        <span className="font-mono text-[#8B5CF6]">84%</span>
                      </div>
                      <div className="h-2 w-full bg-zinc-150 rounded-full overflow-hidden">
                        <div className="h-full bg-[#8B5CF6] rounded-full" style={{ width: '84%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span>Payment Completed</span>
                        <span className="font-mono text-[#8B5CF6]">55%</span>
                      </div>
                      <div className="h-2 w-full bg-zinc-150 rounded-full overflow-hidden">
                        <div className="h-full bg-zinc-950 rounded-full" style={{ width: '55%' }} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Visualizer 2 */}
                <div className="p-6 bg-white border border-violet-100/60 rounded-[28px] space-y-4">
                  <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] font-mono uppercase tracking-widest font-extrabold px-3 py-1 rounded-full">
                    Category Share
                  </span>
                  <div className="space-y-2.5 pt-2 text-[11px] font-bold text-zinc-700">
                    <div className="flex justify-between items-center">
                      <span>• iPhones finish segment</span>
                      <span className="font-mono text-zinc-500">62% share [₹1.5L+]</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>• Macs Desktop workspace</span>
                      <span className="font-mono text-zinc-500">24% share</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>• Watch & AirPods Audio</span>
                      <span className="font-mono text-zinc-500">14% share</span>
                    </div>
                  </div>
                </div>

                {/* Visualizer 3 */}
                <div className="p-6 bg-white border border-[#E9E4F2] rounded-[28px] flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-zinc-400 font-mono tracking-widest uppercase font-bold block">Integrity checks</span>
                    <span className="text-xs font-bold text-[#1D1D1F] mt-1.5 block">Standard system diagnostics</span>
                  </div>
                  <div className="p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10 shrink-0 mt-4">
                    <p className="text-[11.5px] font-bold text-emerald-600 block">✓ 100% database synchronic accuracy</p>
                    <p className="text-[9.5px] text-zinc-400 font-medium leading-relaxed mt-1">Zero corrupted headers found in local simulated memory caches.</p>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* TAB 9: MESSAGES SUPPORT DRAWER */}
          {activeTab === 'messages' && (
            <div className="bg-white border border-violet-100/60 rounded-[32px] overflow-hidden shadow-xs animate-fade-in text-left font-sans">
              
              <div className="grid grid-cols-1 md:grid-cols-3 min-h-[460px]">
                
                {/* Left Inbox List */}
                <div className="border-r border-violet-50 p-6 space-y-4.5">
                  <div className="border-b border-violet-50 pb-3 flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-[#8B5CF6] uppercase tracking-wider">
                      Support Inbox Tickets
                    </span>
                    <span className="bg-[#FAF8FF] text-[#8B5CF6] border border-violet-100/50 text-[9px] font-bold px-2 py-0.5 rounded-full font-mono">
                      {messages.filter(m => !m.replied).length} New
                    </span>
                  </div>

                  <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                    {messages.map(msg => (
                      <div
                        key={msg.id}
                        onClick={() => setActiveMessageId(msg.id)}
                        className={`p-3.5 rounded-2xl cursor-pointer transition-all border ${
                          activeMessageId === msg.id 
                            ? 'bg-[#F7F3FF] border-[#8B5CF6]/30 text-zinc-950 font-bold' 
                            : 'bg-zinc-50 border-transparent text-zinc-650 hover:bg-zinc-100'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[11.5px] truncate max-w-[110px] block font-extrabold">{msg.name}</span>
                          <span className="text-[9.5px] text-zinc-400 font-mono">{msg.date}</span>
                        </div>
                        <p className="text-[10px] text-zinc-500 truncate leading-tight">{msg.subject}</p>
                        <div className="flex justify-end pt-1.5">
                          <span className={`text-[8.5px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded font-mono ${msg.replied ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-500'}`}>
                            {msg.replied ? 'REPLIED' : 'ACTION REQUIRED'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Interactive Chat Panel */}
                <div className="md:col-span-2 p-6 flex flex-col justify-between">
                  {(() => {
                    const activeMsg = messages.find(m => m.id === activeMessageId);
                    if (!activeMsg) return <p className="text-center py-20 text-zinc-400 text-xs">Select any inbox ticket thread.</p>;
                    return (
                      <>
                        <div className="space-y-4">
                          <div className="border-b border-violet-50 pb-3 flex items-start justify-between">
                            <div>
                              <h4 className="font-extrabold text-[#1D1D1F] text-sm">{activeMsg.subject}</h4>
                              <p className="text-[10.5px] text-zinc-400">From: <b>{activeMsg.name}</b> ({activeMsg.email})</p>
                            </div>
                            <span className="text-[9.5px] text-zinc-400 font-mono uppercase font-bold">{activeMsg.date}</span>
                          </div>

                          <div className="bg-[#FAF8FF]/50 p-4 border border-violet-100/40 rounded-2xl text-xs text-zinc-700 leading-relaxed font-sans">
                            {activeMsg.message}
                          </div>
                        </div>

                        {/* Instant reply generator form representation */}
                        <form onSubmit={handleReplyToMessage} className="mt-6 border-t border-violet-50 pt-5 space-y-3">
                          <textarea
                            className="w-full bg-zinc-50 border border-transparent focus:border-violet-100 focus:bg-white text-xs font-semibold p-4 rounded-2xl outline-none resize-none h-20"
                            placeholder="Draft reply template here..."
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            required
                          />
                          <div className="flex justify-end">
                            <button
                              type="submit"
                              className="bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-wider py-2.5 px-6 rounded-full cursor-pointer hover:shadow-md transition-all scale-[1.01]"
                            >
                              Dispatch Admin Answer
                            </button>
                          </div>
                        </form>
                      </>
                    );
                  })()}
                </div>

              </div>

            </div>
          )}

          {/* TAB 10: SETTINGS PRESETS */}
          {activeTab === 'settings' && (
            <div className="bg-white border border-violet-100/60 rounded-[32px] p-6 space-y-6 text-left font-sans animate-fade-in" id="tab-settings-presets">
              <div>
                <h3 className="font-extrabold text-[#1D1D1F] text-lg tracking-tight">System Settings & Shop Configuration</h3>
                <p className="text-xs text-zinc-400">Configure global shop elements, base currency labels, maintenance schedules, and server logs.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6.5">
                
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Active Shop Title logo</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-105 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                      value={shopName}
                      onChange={(e) => setShopName(e.target.value)}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Admin Alert Email recipients</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-105 focus:bg-white text-xs font-bold rounded-2xl outline-none"
                      value={adminEmailAlerts}
                      onChange={(e) => setAdminEmailAlerts(e.target.value)}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9.5px] font-mono font-bold text-zinc-400 uppercase tracking-widest block px-1">Platform currency alignment</label>
                    <select 
                      className="w-full px-4 py-2.5 bg-zinc-100/60 border border-transparent focus:border-violet-105 focus:bg-white text-xs font-bold rounded-2xl outline-none text-zinc-800"
                      value={currencyConfig}
                      onChange={(e) => setCurrencyConfig(e.target.value)}
                    >
                      <option value="INR">Indian Rupees (₹) • default standard pricing</option>
                      <option value="USD">United States Dollars ($) • dynamic conversions</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-4.5 p-5 bg-[#FAF8FF]/40 border border-violet-100/50 rounded-[28px] flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-[#8B5CF6] uppercase tracking-wider block">Maintenance Overrides</span>
                    <p className="text-xs text-zinc-500 leading-relaxed mt-1">Activate this field to lock user profiles and display standard technical update placeholder screens.</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px] font-bold text-zinc-800">Under Maintenance Mode</span>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={underMaintenance} 
                        onChange={(e) => setUnderMaintenance(e.target.checked)} 
                        className="sr-only peer" 
                      />
                      <div className="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#8B5CF6]"></div>
                    </label>
                  </div>

                  <button
                    type="button"
                    onClick={() => alert('Platform Admin Configurations updated successfully in dynamic memory state!')}
                    className="w-full py-3 bg-zinc-950 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-2xl shadow-sm cursor-pointer"
                  >
                    Save Operational Variables
                  </button>
                </div>

              </div>

            </div>
          )}

        </div>

        {/* CUSTOM PREVIEW & DOWNLOAD INVOICE OVERLAY MODAL */}
        {activeInvoiceOrder && (
          <div className="fixed inset-0 bg-zinc-950/70 backdrop-blur-md z-[9999] flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
            <div className="bg-white w-full max-w-2xl rounded-[32px] border border-zinc-150/80 shadow-2xl overflow-hidden text-left relative font-sans flex flex-col my-8">
              
              {/* Modal header details */}
              <div className="p-6 bg-[#FDFCFF] border-b border-zinc-100 flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-zinc-900 font-mono tracking-tight uppercase">Invoice Record #{activeInvoiceOrder.id}</h3>
                  <p className="text-[10.5px] text-zinc-400 font-semibold">Generated automatically on {new Date().toLocaleDateString()}</p>
                </div>
                <button 
                  onClick={() => setActiveInvoiceOrder(null)}
                  className="p-2 bg-zinc-50 hover:bg-zinc-100 text-zinc-500 rounded-full transition-all cursor-pointer"
                  title="Dismiss"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Print area */}
              <div className="p-8 space-y-6 overflow-y-auto max-h-[60vh] text-zinc-800" id="print-invoice-sheet">
                
                {/* Apple Branding & Store Coordinates */}
                <div className="flex justify-between items-start gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1">
                      <span className="text-xl font-black text-black"></span>
                      <span className="text-sm font-black text-[#1D1D1F] tracking-tight">{shopName}</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 font-mono leading-tight">
                      Infinity Loop 1,<br />
                      Cupertino, CA 95014<br />
                      United States
                    </p>
                  </div>

                  <div className="text-right space-y-1">
                    <p className="inline-block text-[8px] bg-zinc-900 text-white font-mono font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                      tax receipt
                    </p>
                    <p className="text-[10px] text-zinc-400 font-mono font-bold">
                      Invoice No: <span className="text-zinc-800 font-mono">INV-{activeInvoiceOrder.id}</span>
                    </p>
                    <p className="text-[10px] text-zinc-400 font-mono font-bold">
                      Created: <span className="text-zinc-800">{new Date(activeInvoiceOrder.createdAt).toLocaleDateString()}</span>
                    </p>
                  </div>
                </div>

                <div className="border-t border-dashed border-zinc-200" />

                {/* Consignee Billing vs Delivery grid */}
                <div className="grid grid-cols-2 gap-6 text-[11px] leading-relaxed">
                  <div>
                    <p className="text-[9px] text-[#8B5CF6] font-mono font-bold uppercase tracking-wider mb-1">billed to</p>
                    <p className="font-extrabold text-zinc-900">{activeInvoiceOrder.userName}</p>
                    <p className="text-zinc-500 font-mono text-[10px]">{adminUsers.find(u => u.id === activeInvoiceOrder.userId)?.email || `${activeInvoiceOrder.userName.toLowerCase().replace(/\s+/g, '')}@gmail.com`}</p>
                    <p className="text-zinc-500 font-mono text-[10px]">{activeInvoiceOrder.shippingAddress.phone || '9988776655'}</p>
                  </div>

                  <div>
                    <p className="text-[9px] text-zinc-400 font-mono font-bold uppercase tracking-wider mb-1">shipping destination</p>
                    <p className="font-bold text-zinc-900">{activeInvoiceOrder.shippingAddress.name}</p>
                    <p className="text-zinc-500">{activeInvoiceOrder.shippingAddress.line1}</p>
                    {activeInvoiceOrder.shippingAddress.line2 && <p className="text-zinc-500">{activeInvoiceOrder.shippingAddress.line2}</p>}
                    <p className="text-zinc-600 font-semibold">
                      {activeInvoiceOrder.shippingAddress.city}, {activeInvoiceOrder.shippingAddress.state} - {activeInvoiceOrder.shippingAddress.postalCode}
                    </p>
                    <p className="text-[10px] text-zinc-400 font-mono font-bold uppercase tracking-wider mt-1">{activeInvoiceOrder.shippingAddress.country || 'India'}</p>
                  </div>
                </div>

                {/* Purchased items table */}
                <div className="border-t border-zinc-200/80 pt-4">
                  <table className="w-full text-left text-xs text-zinc-800">
                    <thead>
                      <tr className="border-b border-zinc-200 text-zinc-400 text-[9px] font-mono uppercase tracking-wider">
                        <th className="py-2">Description</th>
                        <th className="py-2 text-center w-12">Qty</th>
                        <th className="py-2 text-right w-24">Rate</th>
                        <th className="py-2 text-right w-26">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-100 font-medium text-zinc-700">
                      {activeInvoiceOrder.items ? activeInvoiceOrder.items.map((item, index) => (
                        <tr key={index}>
                          <td className="py-3">
                            <p className="font-bold text-zinc-900 leading-snug">{item.name}</p>
                            <p className="text-[9.5px] font-mono text-zinc-400 uppercase font-bold tracking-wide mt-0.5">
                              {item.color && item.color} {item.storage && `| ${item.storage}`}
                            </p>
                          </td>
                          <td className="py-3 text-center text-zinc-800 font-mono">{item.quantity}</td>
                          <td className="py-3 text-right text-zinc-500 font-mono">{formatINR(item.priceAtPurchase)}</td>
                          <td className="py-3 text-right text-zinc-950 font-mono">{formatINR(item.priceAtPurchase * item.quantity)}</td>
                        </tr>
                      )) : null}
                    </tbody>
                  </table>
                </div>

                {/* Pricing Breakdown */}
                <div className="border-t border-zinc-200/80 pt-4 flex justify-end font-sans">
                  <div className="w-64 space-y-2 text-xs font-semibold">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Subtotal</span>
                      <span className="text-zinc-800 font-mono">{formatINR(activeInvoiceOrder.subtotal || activeInvoiceOrder.total)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Discount Code</span>
                      <span className="text-emerald-600 font-mono">-{formatINR(activeInvoiceOrder.discount || 0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">CGST & SGST (18%)</span>
                      <span className="text-zinc-800 font-mono">+{formatINR(activeInvoiceOrder.tax || 0)}</span>
                    </div>
                    <div className="border-t border-zinc-200 pt-2 flex justify-between text-zinc-950">
                      <span className="font-black">Total Paid (INR)</span>
                      <span className="font-black font-mono text-sm">{formatINR(activeInvoiceOrder.total)}</span>
                    </div>
                  </div>
                </div>

                {/* Barcode & compliance stamp */}
                <div className="border-t border-dashed border-zinc-200 pt-6 text-center space-y-3 pb-2">
                  
                  {/* Simulated aesthetic barcode */}
                  <div className="flex justify-center items-center gap-0.5 h-11 bg-zinc-50 border border-zinc-100 p-2.5 rounded-xl mx-auto w-48 select-none">
                    <div className="w-1 bg-zinc-800 h-full" />
                    <div className="w-0.5 bg-zinc-800 h-full" />
                    <div className="w-1.5 bg-zinc-800 h-full" />
                    <div className="w-0.5 bg-zinc-400 h-full" />
                    <div className="w-1 bg-zinc-800 h-full" />
                    <div className="w-2.5 bg-zinc-800 h-full" />
                    <div className="w-0.5 bg-zinc-800 h-full" />
                    <div className="w-1 bg-zinc-800 h-full" />
                    <div className="w-1.5 bg-zinc-800 h-full" />
                    <div className="w-0.5 bg-zinc-300 h-full" />
                    <div className="w-2 bg-zinc-800 h-full" />
                    <div className="w-1 bg-zinc-800 h-full" />
                  </div>

                  <p className="text-[8.5px] font-mono tracking-widest text-zinc-400 font-bold uppercase">
                    authorized fulfillment certified slip • order gateway verified
                  </p>
                </div>

              </div>

              {/* Modal triggers/action row */}
              <div className="p-6 bg-zinc-50 border-t border-zinc-150/60 flex items-center justify-between gap-4">
                <div className="text-[10px] text-zinc-400 font-bold font-mono uppercase">
                  Method: {activeInvoiceOrder.paymentMethod}
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="px-4 py-2 bg-[#EFEAF6] hover:bg-[#E2DAEF] text-[#8B5CF6] text-[11px] font-extrabold uppercase tracking-wider rounded-xl cursor-pointer flex items-center gap-1.5 transition-all"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    Print Slip
                  </button>

                  <button
                    onClick={() => {
                      // Generate dynamic plain text representation of the invoice for dynamic local downloading support
                      const itemsTxt = activeInvoiceOrder.items ? activeInvoiceOrder.items.map(i => `${i.name} (x${i.quantity}) - ${formatINR(i.priceAtPurchase * i.quantity)}`).join('\n') : '';
                      const invoiceText = `
=========================================
          INVOICE - ${shopName.toUpperCase()}
=========================================
Invoice Number : INV-${activeInvoiceOrder.id}
Date           : ${new Date(activeInvoiceOrder.createdAt).toLocaleDateString()}
Payment Method : ${activeInvoiceOrder.paymentMethod.toUpperCase()}

BILLED TO:
Name  : ${activeInvoiceOrder.userName}
Phone : ${activeInvoiceOrder.shippingAddress.phone || '9988776655'}

SHIPPING ADDRESS:
${activeInvoiceOrder.shippingAddress.name}
${activeInvoiceOrder.shippingAddress.line1}
${activeInvoiceOrder.shippingAddress.line2 || ''}
${activeInvoiceOrder.shippingAddress.city}, ${activeInvoiceOrder.shippingAddress.state} - ${activeInvoiceOrder.shippingAddress.postalCode}
Country: ${activeInvoiceOrder.shippingAddress.country}

-----------------------------------------
ITEMS PURCHASED:
${itemsTxt}
-----------------------------------------
TOTAL SUMMARY:
Subtotal      : ${formatINR(activeInvoiceOrder.subtotal || activeInvoiceOrder.total)}
Promo Discount: -${formatINR(activeInvoiceOrder.discount || 0)}
Taxes/CGST    : +${formatINR(activeInvoiceOrder.tax || 0)}
Grand Total   : ${formatINR(activeInvoiceOrder.total)}

=========================================
Thank you for shopping at ${shopName}!
=========================================
`;
                      const blob = new Blob([invoiceText], { type: 'text/plain' });
                      const link = document.createElement('a');
                      link.href = URL.createObjectURL(blob);
                      link.download = `Invoice_INV-${activeInvoiceOrder.id}.txt`;
                      link.click();
                      alert(`Invoice downloaded successfully as Plain Text (Invoice_INV-${activeInvoiceOrder.id}.txt)!`);
                    }}
                    className="px-4.5 py-2 bg-zinc-950 hover:bg-black text-white text-[11px] font-extrabold uppercase tracking-wider rounded-xl cursor-pointer flex items-center gap-1.5 transition-all shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download TXT Invoice
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </main>

    </div>
  );
}
