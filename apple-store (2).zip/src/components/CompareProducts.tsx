import React, { useState } from 'react';
import { useStore } from '../store';
import { Product } from '../types';
import { Star, ShoppingBag, X, Check, Heart, HelpCircle, ArrowLeft, Layers, Sparkles } from 'lucide-react';
import { getFallbackImage } from '../utils/fallbackImage';
import { formatINR, formatEMI } from '../utils/currency';

interface CompareProductsProps {
  setView: (view: string, params?: any) => void;
}

export default function CompareProducts({ setView }: CompareProductsProps) {
  const { products, addToCart, wishlist, toggleWishlist } = useStore();

  // Selected products to compare (supports up to 3 IDs)
  const [selectedIds, setSelectedIds] = useState<string[]>([
    'iphone-16-pro-max',
    'iphone-16',
    'iphone-15-pro'
  ]);

  const [activeCategory, setActiveCategory] = useState<string>('iphones');

  // Filter products matching category
  const categoryProducts = products.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());

  // Resolve compared items
  const comparedItems = selectedIds
    .map(id => products.find(p => p.id === id))
    .filter((p): p is Product => !!p);

  const handleAddProduct = (id: string) => {
    if (selectedIds.includes(id)) return;
    if (selectedIds.length >= 3) {
      // Shift out first item if limit reached
      setSelectedIds([...selectedIds.slice(1), id]);
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleRemoveProduct = (id: string) => {
    setSelectedIds(selectedIds.filter(x => x !== id));
  };

  // Extract all unique specification keys across our compared items
  const specKeys: string[] = Array.from(
    new Set(
      comparedItems.flatMap(p => Object.keys(p.specs || {}))
    )
  ) as string[];

  const handleCategoryChange = (cat: string) => {
    setActiveCategory(cat);
    // Auto-select first few items as defaults to make experience instantly immersive
    const matched = products.filter(p => p.category.toLowerCase() === cat.toLowerCase()).slice(0, 3);
    setSelectedIds(matched.map(m => m.id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-[#1D1D1F]" id="specs-compare-container">
      
      {/* Top Header Deck */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-violet-100/40 pb-6 mb-8 mt-1.5">
        <div>
          <button 
            onClick={() => setView('collection')}
            className="flex items-center gap-1 text-xs font-semibold text-[#8B5CF6] hover:underline cursor-pointer mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Catalog
          </button>
          
          <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] border border-violet-100/30 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">
            Specs Matrix Core
          </span>
          <h1 className="text-3xl md:text-4xl font-extrabold text-[#1D1D1F] tracking-tight mt-2.5">
            Model Specifications Matchroom.
          </h1>
          <p className="text-xs text-[#6E6E73] mt-1 max-w-xl font-medium">
            Analyze pricing, color options, processor generation, cameras, and dimensions side-by-side to find the perfect Apple model.
          </p>
        </div>

        {/* Category selector pillbox */}
        <div className="flex bg-[#EFE7FF] p-1.5 rounded-2xl items-center border border-violet-100/30 h-fit shadow-xs">
          {[
            { id: 'iphones', name: 'iPhones' },
            { id: 'watches', name: 'Apple Watch' },
            { id: 'macbooks', name: 'Macs' },
            { id: 'airpods', name: 'AirPods' },
            { id: 'accessories', name: 'Accessories' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryChange(cat.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${activeCategory === cat.id ? 'bg-white text-black shadow-xs font-black' : 'text-gray-500 hover:text-black hover:bg-white/40'}`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* LEFT BAR: Catalog Selector Drawer */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white border border-violet-100/60 rounded-[28px] p-5 shadow-[0_8px_25px_rgba(139,92,246,0.03)] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 border-b border-violet-50 pb-3 mb-4">
                <Layers className="w-4 h-4 text-[#8B5CF6]" />
                <span className="font-bold text-xs uppercase tracking-wider text-[#1D1D1F]">Add Models</span>
              </div>
              
              <p className="text-[11px] text-gray-400 font-medium leading-relaxed mb-4">
                Select from standard catalog entries below to populate the comparison cells. Show up to 3 side-by-side.
              </p>

              <div className="space-y-2 max-h-96 overflow-y-auto pr-1.5 scrollbar-thin">
                {categoryProducts.map((p) => {
                  const isSelected = selectedIds.includes(p.id);
                  return (
                    <button
                      key={p.id}
                      onClick={() => handleAddProduct(p.id)}
                      disabled={isSelected}
                      className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all text-left text-xs text-[#1D1D1F] font-bold cursor-pointer ${
                        isSelected 
                        ? 'bg-violet-50/40 border-violet-100/30 opacity-60 text-gray-400 cursor-not-allowed' 
                        : 'bg-[#FBF9FF]/40 border-violet-100/20 hover:border-violet-300/40 hover:bg-[#EFE7FF]/30'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <img 
                          src={p.images[0]} 
                          className="w-8 h-8 object-contain shrink-0" 
                          alt="" 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            e.currentTarget.onerror = null;
                            e.currentTarget.src = getFallbackImage(p.name, p.colors[0]);
                          }}
                        />
                        <span className="truncate">{p.name}</span>
                      </div>
                      
                      {!isSelected && (
                        <span className="text-[10px] text-[#8B5CF6] font-mono hover:underline shrink-0 pl-1">
                          + ADD
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-violet-50/50 mt-4">
              <button 
                onClick={() => setSelectedIds([])}
                className="w-full text-center py-2.5 bg-zinc-950 hover:bg-black text-white rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer"
              >
                Clear Selections
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT DECK: Side by Side Cards & Specs List */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Comparison Cards Stage */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {comparedItems.map((p) => {
              const discountPrice = p.price * (1 - p.discount / 100);
              const isFav = wishlist.some(x => x.id === p.id);

              return (
                <div 
                  key={p.id}
                  className="bg-white border border-violet-100/60 rounded-[32px] p-5 shadow-[0_12px_32px_rgba(139,92,246,0.04)] relative group animate-fade-in flex flex-col justify-between"
                  id={`compare-card-${p.id}`}
                >
                  
                  {/* Floating Remove CTA */}
                  <button
                    onClick={() => handleRemoveProduct(p.id)}
                    className="absolute top-4 right-4 p-1.5 bg-gray-100 hover:bg-rose-500 hover:text-white rounded-full transition-colors cursor-pointer text-gray-500 z-10"
                    title="Remove item"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>

                  <div>
                    {/* Device Visual Frame */}
                    <div className="w-full h-36 flex items-center justify-center p-2 bg-[#FBF9FF] rounded-2xl relative mb-4">
                      
                      {p.isBestSeller && (
                        <span className="absolute top-2 left-2 bg-amber-500 text-white text-[8px] font-bold font-mono px-2 py-0.5 rounded-full uppercase tracking-wider">
                          HOT SELLER
                        </span>
                      )}

                      <img 
                        src={p.images[0]} 
                        className="max-h-28 object-contain filter drop-shadow-[0_8px_15px_rgba(0,0,0,0.08)] transform group-hover:scale-105 duration-300 transition-transform cursor-pointer" 
                        alt={p.name}
                        onClick={() => setView('details', { id: p.id })}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = getFallbackImage(p.name, p.colors[0]);
                        }}
                      />
                    </div>

                    <div className="space-y-1">
                      <h4 
                        onClick={() => setView('details', { id: p.id })}
                        className="font-bold text-base text-[#1D1D1F] tracking-tight hover:text-[#8B5CF6] hover:underline cursor-pointer line-clamp-1"
                      >
                        {p.name}
                      </h4>

                      <div className="flex items-center gap-1 text-xs">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span className="font-extrabold text-[#1D1D1F]">{p.ratings.average}</span>
                        <span className="text-gray-400 text-[10px]">({p.ratings.count} reviews)</span>
                      </div>

                      {/* Configured Price tag */}
                      <div className="pt-2">
                        <span className="text-[10px] text-gray-400 block font-mono">RETAIL PRICE</span>
                        <div className="flex items-baseline gap-1.5 flex-wrap-reverse">
                          <b className="text-base font-black text-emerald-500">{formatINR(discountPrice)}</b>
                          {p.discount > 0 && (
                            <span className="text-xs text-gray-400 line-through font-mono">{formatINR(p.price)}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="space-y-2 mt-4 pt-4 border-t border-violet-50/50">
                    <button
                      onClick={() => addToCart(p, 1, p.colorNames[0], p.storages[0])}
                      className="w-full py-2 bg-[#EFE7FF] hover:bg-[#E2D2FF] text-[#1D1D1F] font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-4xs cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5 text-[#8B5CF6]" />
                      Add to Bag
                    </button>

                    <button
                      onClick={() => toggleWishlist(p)}
                      className={`w-full py-1.5 border hover:border-black rounded-xl text-[10.5px] font-bold cursor-pointer transition-all flex items-center justify-center gap-1 ${isFav ? 'border-rose-350 text-rose-500 bg-rose-50/10' : 'border-violet-100 text-gray-500'}`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                      {isFav ? 'In Wishlist' : 'Add Wishlist'}
                    </button>
                  </div>

                </div>
              );
            })}

            {/* Empty matching slot placeholders to encourage comparison additions */}
            {Array.from({ length: Math.max(0, 3 - comparedItems.length) }).map((_, i) => (
              <div 
                key={i} 
                className="bg-dashed border-2 border-dashed border-violet-200/50 rounded-[32px] p-6 h-72 flex flex-col items-center justify-center text-center opacity-80"
                id={`compare-slot-placeholder-${i}`}
              >
                <div className="w-12 h-12 rounded-full bg-violet-50 flex items-center justify-center text-violet-400 mb-3 animate-pulse">
                  ➕
                </div>
                <span className="font-bold text-xs text-violet-400 block uppercase tracking-widest font-mono">Slot Available</span>
                <p className="text-[10px] text-gray-405 mt-1 max-w-[160px] leading-tight">
                  Choose a model from left sidebar of the specs룸.
                </p>
              </div>
            ))}
          </div>

          {/* SIDE-BY-SIDE SPECIFICATIONS MATRIX DECK */}
          {comparedItems.length > 0 ? (
            <div className="bg-white border border-violet-100/60 rounded-[32px] shadow-[0_12px_35px_rgba(139,92,246,0.03)] overflow-hidden">
              <div className="bg-gradient-to-r from-violet-50/30 to-purple-50/10 px-6 py-4.5 border-b border-violet-50 flex items-center justify-between">
                <span className="text-xs font-mono font-black text-[#8B5CF6] uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  Full Comparative Matrix
                </span>
                <span className="text-[10.5px] text-gray-400 font-bold">
                  Matches side-by-side spec criteria
                </span>
              </div>

              {/* Rows catalog */}
              <div className="divide-y divide-violet-50/60">
                
                {/* 1. COLOR FINISHES compare row */}
                <div className="grid grid-cols-1 md:grid-cols-4 p-5 text-sm items-center">
                  <div className="md:col-span-1 font-bold text-[#1D1D1F] text-xs uppercase tracking-wider text-gray-400 font-mono">
                    Model Colors
                  </div>
                  <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6 mt-1 md:mt-0 font-medium">
                    {comparedItems.map((p, idx) => (
                      <div key={idx} className="space-y-1.5 pr-2.5">
                        <div className="flex gap-1">
                          {p.colors.map((hex, k) => (
                            <span 
                              key={k} 
                              className="w-3.5 h-3.5 rounded-full border border-gray-200" 
                              style={{ backgroundColor: hex }} 
                              title={p.colorNames[k]}
                            />
                          ))}
                        </div>
                        <div className="text-[11px] text-[#6E6E73] font-bold truncate">
                          {p.colorNames.join(', ')}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. STORAGE CAPACITIES compare row */}
                <div className="grid grid-cols-1 md:grid-cols-4 p-5 text-sm items-center">
                  <div className="md:col-span-1 font-bold text-[#1D1D1F] text-xs uppercase tracking-wider text-gray-400 font-mono">
                    Storage Steps
                  </div>
                  <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6 mt-1 md:mt-0 font-medium">
                    {comparedItems.map((p, idx) => (
                      <div key={idx} className="flex flex-wrap gap-1">
                        {p.storages.map((sz, k) => (
                          <span 
                            key={k} 
                            className="bg-[#FBF9FF] text-zinc-700 text-[10px] font-bold px-2 py-1 rounded-md border border-violet-50"
                          >
                            {sz}
                          </span>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. EMI RECALCULATIONS row info */}
                <div className="grid grid-cols-1 md:grid-cols-4 p-5 text-sm items-center">
                  <div className="md:col-span-1 font-bold text-[#1D1D1F] text-xs uppercase tracking-wider text-gray-400 font-mono">
                    EMI Estimate
                  </div>
                  <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6 mt-1 md:mt-0 font-mono">
                    {comparedItems.map((p, idx) => {
                      const discountPrice = p.price * (1 - p.discount / 100);
                      return (
                        <div key={idx}>
                          <span className="text-violet-600 font-black text-xs">
                            {formatEMI(discountPrice)}/mo.
                          </span>
                          <span className="text-[9.5px] text-gray-400 block mt-0.5">
                            Interest-free installments over 24 months
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Iterate through calculated keys sheets */}
                {specKeys.map((k) => (
                  <div key={k} className="grid grid-cols-1 md:grid-cols-4 p-5 text-sm items-center animate-fade-in">
                    <div className="md:col-span-1 font-bold text-[#1D1D1F] text-xs tracking-tight">
                      {k}
                    </div>
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-6 mt-1.5 md:mt-0 font-sans text-xs text-gray-500 leading-relaxed pr-2">
                      {comparedItems.map((p, pIdx) => {
                        const specValue = (p.specs as Record<string, string>)[k] || '—';
                        return (
                          <div key={pIdx} className="break-words">
                            {specValue}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}

              </div>
            </div>
          ) : (
            <div className="p-16 border rounded-3xl bg-neutral-50/50 text-center text-gray-400 text-xs font-bold leading-normal">
              No models selected to assemble the full comparative matrix specs room. Add items from the side deck.
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
