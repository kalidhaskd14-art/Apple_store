import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../store';
import { 
  ShieldAlert, 
  ArrowRight, 
  Eye, 
  EyeOff, 
  Smartphone, 
  Lock, 
  User, 
  RefreshCw, 
  CheckCircle2, 
  ChevronLeft,
  X,
  Check,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AuthFormProps {
  mode: 'login' | 'signup';
  setView: (view: string) => void;
}

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

const COUNTRY_CODES = [
  { code: '+91', flag: '🇮🇳', name: 'India' },
  { code: '+1', flag: '🇺🇸', name: 'USA' },
  { code: '+44', flag: '🇬🇧', name: 'UK' },
  { code: '+61', flag: '🇦🇺', name: 'Australia' },
  { code: '+1', flag: '🇨🇦', name: 'Canada' },
  { code: '+65', flag: '🇸🇬', name: 'Singapore' },
  { code: '+971', flag: '🇦🇪', name: 'UAE' },
  { code: '+49', flag: '🇩🇪', name: 'Germany' },
];

export default function AuthForm({ mode, setView }: AuthFormProps) {
  const { 
    login, 
    registerPhone, 
    sendOtp, 
    forgotPassword, 
    resetPassword, 
    authLoading, 
    authError 
  } = useStore();

  const [activeMode, setActiveMode] = useState<'login' | 'signup' | 'forgot_password'>(mode);
  const [regSuccess, setRegSuccess] = useState(false);
  
  // Custom toast notifications state
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Input fields state
  const [name, setName] = useState('');
  const [countryCode, setCountryCode] = useState('+91');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [otp, setOtp] = useState('');
  
  // Validation flags
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  
  // OTP state machine
  const [otpSent, setOtpSent] = useState(false);
  const [sendingOtp, setSendingOtp] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  // References
  const otpInputRef = useRef<HTMLInputElement>(null);

  // Synchronize layout mode from parent call
  useEffect(() => {
    setActiveMode(mode);
    setOtpSent(false);
    setOtpVerified(false);
    setToasts([]);
  }, [mode]);

  // Handle countdown Timer for OTP resend
  useEffect(() => {
    let interval: any;
    if (cooldown > 0) {
      interval = setInterval(() => {
        setCooldown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [cooldown]);

  // Auto-focus OTP input when OTP is sent
  useEffect(() => {
    if (otpSent && otpInputRef.current) {
      otpInputRef.current.focus();
    }
  }, [otpSent]);

  const addToast = (message: string, type: 'success' | 'error' | 'info' = 'error') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const validateMobile = (num: string) => {
    const cleaned = num.replace(/\D/g, '');
    return cleaned.length >= 7 && cleaned.length <= 15;
  };

  // Build the complete combined registration phone number
  const getCombinedPhone = () => {
    const cleaned = phone.replace(/\D/g, '');
    return countryCode + cleaned;
  };

  // Password strength calculator
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: 'Not Entered', color: 'bg-zinc-200', text: 'text-zinc-400', width: 'w-0' };
    let score = 0;
    if (pass.length >= 6) score += 1;
    if (pass.length >= 9) score += 1;
    if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score += 1;
    if (/[0-9]/.test(pass)) score += 1;
    if (/[^A-Za-z0-9]/.test(pass)) score += 1;

    if (score <= 1) {
      return { score, label: 'Weak', color: 'bg-rose-500', text: 'text-rose-500', width: 'w-1/3' };
    } else if (score <= 3) {
      return { score, label: 'Good', color: 'bg-amber-400', text: 'text-amber-500', width: 'w-2/3' };
    } else {
      return { score, label: 'Strong Security', color: 'bg-emerald-500', text: 'text-emerald-500', width: 'w-full' };
    }
  };

  const strength = getPasswordStrength(password);

  // Trigger local OTP send request
  const triggerSignupOtpSend = async () => {
    if (!name.trim()) {
      addToast('Please enter your full name first.', 'error');
      return;
    }
    if (!phone) {
      addToast('Please input your mobile phone number.', 'error');
      return;
    }
    if (!validateMobile(phone)) {
      addToast('Please specify a valid mobile number sequence.', 'error');
      return;
    }

    const fullPhone = getCombinedPhone();
    setSendingOtp(true);
    addToast('Sending OTP verification code to mobile...', 'info');

    const result = await sendOtp(fullPhone);
    setSendingOtp(false);

    if (result.success) {
      setOtpSent(true);
      setCooldown(45);
      addToast('Verification code successfully dispatched! Check your messages.', 'success');
    } else {
      addToast(result.error || 'Failed to dispatch verification OTP. Please verify your number.', 'error');
    }
  };

  // Verify OTP directly on the server database
  const handleVerifyOtp = async (inputOtp?: string) => {
    const otpToCheck = inputOtp || otp;
    if (!otpToCheck || otpToCheck.length < 4) {
      addToast('Please enter the 6-digit confirmation code.', 'error');
      return;
    }

    setVerifyingOtp(true);
    const fullPhone = getCombinedPhone();

    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: fullPhone, otp: otpToCheck })
      });
      const data = await res.json();
      setVerifyingOtp(false);

      if (!res.ok) {
        throw new Error(data.error || 'Invalid confirmation code entered.');
      }

      setOtpVerified(true);
      addToast('Mobile number verified successfully! Set your password.', 'success');
    } catch (err: any) {
      setVerifyingOtp(false);
      addToast(err.message || 'The verification code provided is invalid or expired.', 'error');
    }
  };

  const handleOtpChange = (val: string) => {
    const cleaned = val.replace(/\D/g, '');
    setOtp(cleaned);
    
    // Automatically verify when the 6-digit code is typed fully
    if (cleaned.length === 6) {
      handleVerifyOtp(cleaned);
    }
  };

  // Dispatch OTP Action for Password Recovery
  const triggerForgotOtpSend = async () => {
    if (!phone) {
      addToast('Please specify your mobile number first.', 'error');
      return;
    }
    
    const fullPhone = getCombinedPhone();
    setSendingOtp(true);
    addToast('Sending recovery OTP code...', 'info');

    const result = await forgotPassword(fullPhone);
    setSendingOtp(false);

    if (result.success) {
      setOtpSent(true);
      setCooldown(45);
      addToast('Recovery code dispatched successfully to your phone.', 'success');
    } else {
      addToast(result.error || 'No registered user was found with this phone number.', 'error');
    }
  };

  // Action Submission Route dispatcher
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (activeMode === 'login') {
      if (!phone || !password) {
        addToast('Please complete both credentials to log in.', 'error');
        return;
      }
      
      const fullPhone = validateMobile(phone) && !phone.includes('+') ? getCombinedPhone() : phone;
      const success = await login(fullPhone, password);
      if (success) {
        addToast('Sign in validated successfully! Redirecting...', 'success');
        setView('home');
      } else {
        addToast(useStore.getState().authError || 'Invalid credentials. Check mobile number/password.', 'error');
      }
    } 
    else if (activeMode === 'signup') {
      if (!otpVerified) {
        addToast('Please verify your mobile connection via SMS OTP first.', 'error');
        return;
      }
      if (!password || password.length < 6) {
        addToast('Please pick a secure password (at least 6 characters).', 'error');
        return;
      }

      const fullPhone = getCombinedPhone();
      const success = await registerPhone(name, fullPhone, password, otp);
      if (success) {
        addToast('Apple ID created successfully', 'success');
        setRegSuccess(true);
        setTimeout(() => {
          setRegSuccess(false);
          setView('login');
          // For a flawless login experience, we keep countryCode and phone as-is so the user just type their password!
          setPassword('');
          setOtp('');
          setOtpSent(false);
          setOtpVerified(false);
        }, 3000);
      } else {
        addToast(useStore.getState().authError || 'Could not register account. Please try again.', 'error');
      }
    } 
    else if (activeMode === 'forgot_password') {
      if (!phone || !otp || !newPassword) {
        addToast('Please input verification code and set your new password.', 'error');
        return;
      }

      if (newPassword.length < 6) {
        addToast('New password must match the 6-character safety guidelines.', 'error');
        return;
      }

      const fullPhone = getCombinedPhone();
      const result = await resetPassword(fullPhone, otp, newPassword);
      if (result.success) {
        addToast('Password updated successfully! Directing you to login...', 'success');
        setTimeout(() => {
          setActiveMode('login');
          setPhone('');
          setOtp('');
          setNewPassword('');
          setOtpSent(false);
          setOtpVerified(false);
        }, 1800);
      } else {
        addToast(result.error || 'Failed to update password. Check your security code.', 'error');
      }
    }
  };

  return (
    <div className="relative w-full max-w-lg mx-auto py-4 px-2 sm:px-4 text-left" id="authform-wrapper">
      
      {/* Absolute floating notifications (Toasts) */}
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-110 flex flex-col gap-2.5 max-w-md w-[calc(100%-2rem)]">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ type: 'spring', damping: 20, stiffness: 260 }}
              className={`px-4 py-3.5 rounded-2xl flex items-center gap-3 shadow-[0_12px_24px_rgba(0,0,0,0.1)] border backdrop-blur-md ${
                toast.type === 'success' 
                  ? 'bg-white/95 border-emerald-100 text-zinc-900' 
                  : toast.type === 'info'
                  ? 'bg-white/95 border-indigo-100 text-zinc-900'
                  : 'bg-white/95 border-rose-100 text-zinc-900'
              }`}
            >
              {toast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />}
              {toast.type === 'info' && <RefreshCw className="w-5 h-5 text-purple-500 animate-spin shrink-0" />}
              {toast.type === 'error' && <ShieldAlert className="w-5 h-5 text-rose-500 shrink-0" />}
              
              <p className="text-xs font-semibold leading-normal flex-1">
                {toast.message}
              </p>

              <button 
                type="button"
                onClick={() => removeToast(toast.id)}
                className="text-zinc-400 hover:text-zinc-600 p-1 rounded-full transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Main Luxury Frame & Glass Card */}
      <div className="bg-gradient-to-b from-[#FAF8FF] to-white border border-violet-100 p-1 sm:p-2 rounded-[40px] shadow-[0_32px_64px_-16px_rgba(139,92,246,0.06)] relative overflow-hidden">
        
        {/* Soft, beautiful purple background ambient sphere */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-purple-250/20 blur-[80px] rounded-full pointer-events-none select-none z-0" />

        {/* Absolute premium success overlay */}
        <AnimatePresence>
          {regSuccess && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-6 text-center"
            >
              <motion.div 
                initial={{ scale: 0.5, rotate: -45 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6 text-emerald-600 shadow-md"
              >
                <CheckCircle2 className="w-12 h-12 stroke-[2.5]" />
              </motion.div>
              
              <h3 className="text-2xl font-black text-zinc-900 tracking-tight mb-2">
                Apple ID created successfully
              </h3>
              
              <p className="text-xs text-zinc-500 max-w-xs leading-relaxed">
                Thank you for registering. You are being redirected to the Sign In page to verify your credentials.
              </p>
              
              {/* Animated progress run */}
              <div className="w-40 h-1.5 bg-zinc-100 rounded-full mt-8 overflow-hidden relative">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2.8, ease: "easeInOut" }}
                  className="bg-[#8B5CF6] h-full rounded-full"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="bg-white/80 backdrop-blur-xl border border-white/50 px-6 py-8 sm:px-10 sm:py-10 rounded-[36px] relative z-10">
          
          {/* Large Apple Logo with Dynamic Slow Glow */}
          <div className="text-center mb-8 relative group">
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-gradient-to-tr from-violet-350 to-pink-300 rounded-full blur-2xl opacity-35 animate-pulse" />
            <svg 
              className="w-11 h-11 text-zinc-900 mx-auto relative drop-shadow-[0_2px_10px_rgba(139,92,246,0.15)] transition-transform duration-500 group-hover:scale-105" 
              viewBox="0 0 24 24" 
              fill="currentColor"
            >
              <path d="M18.71,19.5c-.83,1.24-1.71,2.45-3.05,2.47-1.34,.03-1.77-.79-3.29-.79-1.53,0-2,.77-3.27,.82-1.31,.05-2.3-1.32-3.14-2.53C4.25,17,2.94,12.45,4.7,9.39c.87-1.52,2.43-2.48,4.12-2.51,1.28-.02,2.5,.87,3.29,.87,.78,0,2.26-1.07,3.81-.91,1.54,.06,2.7,.61,3.46,1.73C15.4,11.04,14.8,15.78,18.71,19.5M15.97,4.17c1.39-1.68,1.35-3.22,1.35-3.22,0,0-1.42,.02-3.04,1.92-1.12,1.31-1.28,2.7-1.28,2.7,0,0,1.52,.12,2.97-1.4" />
            </svg>

            <h2 className="text-xl sm:text-2xl font-black text-zinc-900 tracking-tight mt-6 font-sans">
              {activeMode === 'login' && 'Sign in to Apple Store'}
              {activeMode === 'signup' && 'Create your Apple ID'}
              {activeMode === 'forgot_password' && 'Recover Apple ID'}
            </h2>

            <p className="text-xs text-zinc-400 mt-2 font-medium max-w-xs mx-auto">
              {activeMode === 'login' && 'Manage your orders, warranties, and express checkout details.'}
              {activeMode === 'signup' && 'Use your Apple ID to secure shopping profiles and quick checkouts.'}
              {activeMode === 'forgot_password' && 'Recover your account details securely using your registered mobile.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* RENDER SIGNUP FORM (CREATING ACCOUNT) STAGE */}
            {activeMode === 'signup' && (
              <>
                {/* 1. Full Name */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-zinc-400" /> Full Name
                  </label>
                  <input 
                    type="text"
                    placeholder="First and Last Name"
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10 disabled:opacity-60"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={otpVerified}
                    required
                  />
                </div>

                {/* 2. Mobile Number with Country Code Selector */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                    <Smartphone className="w-3.5 h-3.5 text-zinc-400" /> Mobile Number
                  </label>
                  <div className="flex gap-2">
                    <div className="relative shrink-0">
                      <select 
                        value={countryCode} 
                        onChange={(e) => setCountryCode(e.target.value)}
                        disabled={otpVerified}
                        className="h-full pl-3 pr-2 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-bold text-zinc-800 transition-all cursor-pointer disabled:opacity-60"
                      >
                        {COUNTRY_CODES.map((item) => (
                          <option key={item.code + item.name} value={item.code}>
                            {item.flag} {item.code}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="relative flex-1">
                      <input 
                        type="tel"
                        placeholder="10-digit mobile"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10 disabled:opacity-60"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                        disabled={otpVerified}
                        required
                      />
                      {otpVerified && (
                        <span className="absolute right-3.5 top-1/2 -translate-y-1/2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 text-[9px] font-mono font-black py-1 px-2.5 rounded-full uppercase">
                          Verified ✓
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* 3. Send OTP button */}
                {!otpSent && !otpVerified && (
                  <motion.button
                    whileTap={{ scale: 0.99 }}
                    type="button"
                    onClick={triggerSignupOtpSend}
                    disabled={sendingOtp || !phone}
                    className="w-full py-3 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:from-zinc-900 hover:to-black text-white rounded-2xl text-xs font-bold tracking-wide transition-all shadow-md disabled:opacity-40 cursor-pointer"
                  >
                    {sendingOtp ? 'Generating security key...' : 'Send OTP Verification Code'}
                  </motion.button>
                )}

                {/* 4. OTP input with auto-focus and countdown timer */}
                <AnimatePresence>
                  {otpSent && !otpVerified && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-2 p-4 bg-[#F9F8FD] border border-violet-100 rounded-2xl overflow-hidden"
                    >
                      <div className="flex justify-between items-center px-0.5">
                        <label className="text-[10px] font-bold text-[#8B5CF6] uppercase tracking-wider flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> SMS Confirm Code
                        </label>
                        {cooldown > 0 ? (
                          <span className="text-[10px] font-mono text-zinc-400 font-medium">Resend in {cooldown}s</span>
                        ) : (
                          <button
                            type="button"
                            onClick={triggerSignupOtpSend}
                            className="text-[10px] font-bold text-[#8B5CF6] hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <RefreshCw className="w-2.5 h-2.5" /> Resend Code
                          </button>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <input 
                          ref={otpInputRef}
                          type="text"
                          maxLength={6}
                          placeholder="••••••"
                          className="w-full py-3 border border-zinc-200 rounded-2xl text-center font-mono text-lg font-bold tracking-widest bg-white focus:border-[#8B5CF6] focus:ring-2 focus:ring-[#8B5CF6]/10 outline-none transition-all text-[#1D1D1F]"
                          value={otp}
                          onChange={(e) => handleOtpChange(e.target.value)}
                          required
                        />
                        <button
                          type="button"
                          onClick={() => handleVerifyOtp()}
                          disabled={verifyingOtp || otp.length < 4}
                          className="px-5 bg-[#1d1d1f] hover:bg-black text-[11px] text-white font-bold rounded-2xl transition-all cursor-pointer disabled:opacity-40"
                        >
                          {verifyingOtp ? 'Checking...' : 'Verify'}
                        </button>
                      </div>
                      <p className="text-[10px] text-zinc-400 text-center font-medium mt-1">
                        We have dispatched your temporary validation token. Enter standard preview code <strong className="font-mono text-zinc-600">123456</strong> or check SMS.
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* 5. Password field with show/hide icon and strength indicator */}
                <div className="space-y-1.5 transition-all">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-zinc-400" /> Passcode Security
                    </label>
                    {!otpVerified && (
                      <span className="text-[9px] font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-1 bg-zinc-100 px-2 py-0.5 rounded-md">
                        Locked (Pending SMS)
                      </span>
                    )}
                  </div>

                  <div className="relative">
                    <input 
                      type={showPassword ? 'text' : 'password'}
                      placeholder={otpVerified ? "Must be at least 6 characters" : "Verify OTP to set your password"}
                      className={`w-full pl-4 pr-10 py-3 rounded-2xl outline-none text-xs font-semibold transition-all border ${
                        otpVerified 
                          ? 'bg-white border-zinc-200 focus:border-[#8B5CF6] focus:ring-2 focus:ring-[#8B5CF6]/10 text-zinc-900' 
                          : 'bg-zinc-100 border-zinc-200 text-zinc-400 cursor-not-allowed'
                      }`}
                      value={password}
                      disabled={!otpVerified}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    {otpVerified && (
                      <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    )}
                  </div>

                  {/* Password strength indicator */}
                  {otpVerified && password && (
                    <motion.div 
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-1 mt-1.5 px-0.5"
                    >
                      <div className="flex justify-between items-center text-[10px] font-bold text-zinc-400">
                        <span>Strength: <span className={strength.text}>{strength.label}</span></span>
                      </div>
                      <div className="h-1.5 w-full bg-zinc-100 rounded-full overflow-hidden">
                        <div className={`h-full ${strength.color} ${strength.width} transition-all duration-300 rounded-full`} />
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* 6. Create Account button */}
                <motion.button 
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:from-zinc-900 hover:to-black text-white rounded-2xl text-xs font-bold tracking-wide flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer disabled:opacity-40"
                  disabled={authLoading || !otpVerified || password.length < 6 || !name.trim()}
                  id="auth-signup-submit-btn"
                >
                  {authLoading ? (
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      Create Apple ID Account
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </motion.button>
              </>
            )}

            {/* RENDER STANDARD SIGN IN (LOGIN) STAGE */}
            {activeMode === 'login' && (
              <>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                    <Smartphone className="w-3.5 h-3.5 text-zinc-400" /> Mobile Number
                  </label>
                  <div className="flex gap-2">
                    <div className="relative shrink-0">
                      <select 
                        value={countryCode} 
                        onChange={(e) => setCountryCode(e.target.value)}
                        className="h-full pl-3 pr-2 py-3 bg-zinc-50 border border-zinc-150 rounded-2xl outline-none text-xs font-bold text-zinc-800 transition-all cursor-pointer"
                      >
                        {COUNTRY_CODES.map((item) => (
                          <option key={'login-' + item.code + item.name} value={item.code}>
                            {item.flag} {item.code}
                          </option>
                        ))}
                      </select>
                    </div>

                    <input 
                      type="text"
                      placeholder="e.g. 9988776655"
                      className="flex-1 px-4 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5 relative">
                  <div className="flex justify-between items-center px-0.5">
                    <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-zinc-400" /> Passcode ID
                    </label>
                    <button 
                      type="button"
                      onClick={() => {
                        setActiveMode('forgot_password');
                        setPhone('');
                        setOtpSent(false);
                      }}
                      className="text-[10px] font-bold text-[#8B5CF6] hover:underline"
                    >
                      Forgot?
                    </button>
                  </div>
                  <div className="relative">
                    <input 
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Access security key"
                      className="w-full pl-4 pr-10 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-650 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <motion.button 
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:from-zinc-900 hover:to-black text-white rounded-2xl text-xs font-bold tracking-wide flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer mt-2"
                  disabled={authLoading}
                >
                  {authLoading ? (
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      Verify and Log In
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </motion.button>
              </>
            )}

            {/* RENDER FORGOT PASSWORD RECOVERY STAGE */}
            {activeMode === 'forgot_password' && (
              <>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                    <Smartphone className="w-3.5 h-3.5 text-zinc-400" /> Registered Mobile
                  </label>
                  <div className="flex gap-2">
                    <div className="relative shrink-0">
                      <select 
                        value={countryCode} 
                        onChange={(e) => setCountryCode(e.target.value)}
                        disabled={otpSent}
                        className="h-full pl-3 pr-2 py-3 bg-zinc-50 border border-zinc-150 rounded-2xl outline-none text-xs font-bold text-zinc-800 transition-all cursor-pointer disabled:opacity-65"
                      >
                        {COUNTRY_CODES.map((item) => (
                          <option key={'forgot-' + item.code + item.name} value={item.code}>
                            {item.flag} {item.code}
                          </option>
                        ))}
                      </select>
                    </div>

                    <input 
                      type="text"
                      placeholder="10-digit mobile"
                      className="flex-1 px-4 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10 disabled:opacity-65"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                      disabled={otpSent}
                      required
                    />
                  </div>
                </div>

                {!otpSent && (
                  <motion.button
                    whileTap={{ scale: 0.99 }}
                    type="button"
                    onClick={triggerForgotOtpSend}
                    className="w-full py-3 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:from-zinc-900 hover:to-black text-white rounded-2xl text-xs font-bold tracking-wide transition-all cursor-pointer"
                    disabled={sendingOtp || !phone}
                  >
                    {sendingOtp ? 'Verifying profile...' : 'Send Recovery OTP'}
                  </motion.button>
                )}

                {otpSent && (
                  <motion.div 
                    initial={{ opacity: 0, y: -5 }} 
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    <div className="space-y-1.5 p-3.5 bg-violet-50/50 border border-violet-100 rounded-2xl">
                      <div className="flex justify-between items-center px-0.5">
                        <label className="text-[10px] font-bold text-[#8B5CF6] uppercase tracking-wider">
                          SMS Security Pin
                        </label>
                        {cooldown > 0 ? (
                          <span className="text-[9px] font-mono text-zinc-400">Resend in {cooldown}s</span>
                        ) : (
                          <button
                            type="button"
                            onClick={triggerForgotOtpSend}
                            className="text-[9px] font-bold text-[#8B5CF6] hover:underline"
                          >
                            Resend Code
                          </button>
                        )}
                      </div>
                      <input 
                        type="text"
                        maxLength={6}
                        placeholder="••••••"
                        className="w-full py-2.5 border border-zinc-200 rounded-2xl text-center font-mono text-base font-bold bg-white focus:border-[#8B5CF6] focus:ring-2 focus:ring-[#8B5CF6]/10 outline-none transition-all"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                        required
                      />
                    </div>

                    <div className="space-y-1.5 relative">
                      <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider px-0.5 flex items-center gap-2">
                        <Lock className="w-3.5 h-3.5 text-zinc-400" /> New security password
                      </label>
                      <div className="relative">
                        <input 
                          type={showNewPassword ? 'text' : 'password'}
                          placeholder="At least 6 characters"
                          className="w-full pl-4 pr-10 py-3 bg-zinc-50 border border-zinc-150 focus:border-[#8B5CF6] focus:bg-white rounded-2xl outline-none text-xs font-semibold text-zinc-900 transition-all focus:ring-2 focus:ring-[#8B5CF6]/10"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          required
                        />
                        <button 
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-650 cursor-pointer"
                        >
                          {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <motion.button 
                      whileTap={{ scale: 0.98 }}
                      type="submit"
                      className="w-full py-3.5 bg-gradient-to-b from-zinc-800 to-zinc-950 hover:from-zinc-900 hover:to-black text-white rounded-2xl text-xs font-bold tracking-wide flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
                      disabled={authLoading}
                    >
                      {authLoading ? (
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          Reset Password & Log In
                          <ArrowRight className="w-3.5 h-3.5" />
                        </>
                      )}
                    </motion.button>
                  </motion.div>
                )}
              </>
            )}

          </form>

          {/* Luxury Switchers Footer */}
          <div className="mt-8 pt-6 border-t border-zinc-100 text-center text-xs text-zinc-500 font-medium font-sans">
            {activeMode === 'forgot_password' ? (
              <button 
                type="button"
                onClick={() => {
                  setView('login');
                  setPhone('');
                  setOtpSent(false);
                  setOtpVerified(false);
                }} 
                className="text-zinc-800 hover:text-[#8B5CF6] font-bold flex items-center justify-center gap-1.5 mx-auto transition-colors"
              >
                <ChevronLeft className="w-4 h-4" /> Back to Log In
              </button>
            ) : activeMode === 'login' ? (
              <p>
                Don't have an Apple ID?{' '}
                <button 
                  type="button"
                  onClick={() => { 
                    setView('signup'); 
                    setPhone(''); 
                    setOtpSent(false); 
                    setOtpVerified(false);
                  }} 
                  className="text-[#8B5CF6] hover:underline font-bold transition-all ml-1"
                >
                  Create one now
                </button>
              </p>
            ) : (
              <p>
                <button 
                  type="button"
                  onClick={() => { 
                    setView('login'); 
                    setPhone(''); 
                    setOtpSent(false); 
                    setOtpVerified(false);
                  }} 
                  className="text-[#8B5CF6] hover:underline font-bold transition-all"
                >
                  Already have an Apple ID? Sign In
                </button>
              </p>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
