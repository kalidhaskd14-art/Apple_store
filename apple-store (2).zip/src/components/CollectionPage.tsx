import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import ProductCard from './ProductCard';
import { 
  Search, ListFilter, SlidersHorizontal, Grid, Star, 
  Layers, ShoppingBag, Heart, Check, Smartphone, Flame, BadgeAlert 
} from 'lucide-react';
import { formatINR, formatEMI } from '../utils/currency';
import { getFallbackImage } from '../utils/fallbackImage';
import { Product } from '../types';

interface CollectionPageProps {
  setView: (view: string, params?: any) => void;
}

// Interactive sub-card presenting the requested 2-box-layered configuration
interface TwoBoxProductCardProps {
  product: Product;
  setView: (view: string, params?: any) => void;
  key?: string;
}

function TwoBoxProductCard({ product, setView }: TwoBoxProductCardProps) {
  const { toggleWishlist, wishlist, addToCart } = useStore();

  const [selectedColorIdx, setSelectedColorIdx] = useState(0);
  const [selectedStorageIdx, setSelectedStorageIdx] = useState(0);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const isInWishlist = wishlist.some(item => item.id === product.id);

  // Recalculate price dynamically for storage ticks: base size stays base, higher capacity steps increase offset
  const basePrice = product.price;
  const storageOffset = selectedStorageIdx * 10000;
  const configuredOriginalPrice = basePrice + storageOffset;
  const configuredDiscountPrice = configuredOriginalPrice * (1 - product.discount / 100);

  const activeImage = product.images[selectedColorIdx % product.images.length] || product.images[0];
  const activeColorName = product.colorNames[selectedColorIdx % product.colorNames.length] || product.colorNames[0];
  const activeStorage = product.storages[selectedStorageIdx % product.storages.length] || product.storages[0];

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1, activeColorName, activeStorage);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 2000);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product);
  };

  return (
    <div 
      className="bg-[#FFFFFF] border border-violet-100/60 rounded-[32px] overflow-hidden shadow-[0_8px_30px_rgba(139,92,246,0.05)] hover:shadow-[0_15px_40px_rgba(139,92,246,0.12)] hover:border-violet-200/50 transition-all duration-350 grid grid-cols-1 md:grid-cols-2 group text-[#1D1D1F] cursor-pointer relative"
      onClick={() => setView('details', { id: product.id })}
      id={`layered-card-${product.id}`}
    >
      
      {/* BOX LAYER 1: Large Immersive Device Stage */}
      <div className="bg-[#EFE7FF]/40 p-6 flex flex-col justify-between relative min-h-[280px] md:border-r border-violet-105/40 select-none max-md:rounded-t-[32px]">
        
        {/* Floating Top Header Badges */}
        <div className="flex items-center justify-between z-10">
          <div className="flex flex-wrap gap-1">
            {product.discount > 0 && (
              <span className="bg-rose-500 text-white text-[9px] font-mono font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                -{product.discount}% OFF
              </span>
            )}
            {product.isNewArrival && (
              <span className="bg-[#8B5CF6] text-white text-[9px] font-mono font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                NEW
              </span>
            )}
            {product.isBestSeller && (
              <span className="bg-amber-500 text-white text-[9px] font-mono font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                TOP SELLER
              </span>
            )}
          </div>
          <button
            onClick={handleToggleWishlist}
            className="p-2 bg-white hover:bg-zinc-50 rounded-full shadow-xs text-gray-400 hover:text-red-500 transition-all cursor-pointer transform hover:scale-110 active:scale-90"
            title="Toggle Wishlist"
          >
            <Heart className={`w-3.5 h-3.5 ${isInWishlist ? 'fill-red-500 text-red-500' : ''}`} />
          </button>
        </div>

        {/* Studio Product Graphic Center */}
        <div className="my-4 w-full flex items-center justify-center p-2 relative h-48">
          <img
            src={activeImage}
            alt={product.name}
            className="h-44 w-full object-contain transform group-hover:scale-106 duration-500 transition-transform"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = getFallbackImage(product.name, product.colors[selectedColorIdx] || '#8c8780');
            }}
          />
        </div>

        {/* Dynamic Color Selector Band */}
        <div className="flex flex-col items-center gap-1.5 z-10">
          <div className="flex gap-2">
            {product.colors.map((hex, idx) => (
              <button
                key={hex}
                type="button"
                onClick={(e) => { e.stopPropagation(); setSelectedColorIdx(idx); }}
                className={`w-3.5 h-3.5 rounded-full border transition-all cursor-pointer relative flex items-center justify-center ${
                  selectedColorIdx === idx ? 'ring-2 ring-[#8B5CF6] scale-110 border-white' : 'border-violet-200 hover:scale-105'
                }`}
                style={{ backgroundColor: hex }}
                title={product.colorNames[idx]}
              />
            ))}
          </div>
          <p className="text-[10px] text-[#6E6E73] font-medium tracking-wide">
            Model Finish: <span className="text-[#1D1D1F] font-semibold">{activeColorName}</span>
          </p>
        </div>
      </div>

      {/* BOX LAYER 2: Live Specification Specs & Configurator Deck */}
      <div className="p-6 md:p-8 flex flex-col justify-between space-y-4">
        
        {/* Title, rating and short descriptions */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-bold text-gray-450 uppercase tracking-widest bg-gray-100 px-2.5 py-0.5 rounded-md">
               {product.category.toUpperCase()}
            </span>
            <div className="flex items-center gap-1 text-[11px] text-[#86868b] font-semibold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="text-zinc-800">{product.ratings.average}</span>
              <span className="text-zinc-400 font-normal">({product.ratings.count} reviews)</span>
            </div>
          </div>
          
          <h3 className="text-xl md:text-2xl font-black text-apple-dark font-sans tracking-tight leading-none">
            {product.name}
          </h3>
          
          <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed font-medium">
            {product.description}
          </p>
        </div>

        {/* Spec Sheet Grid Box */}
        <div className="bg-[#EFE7FF]/40 border border-violet-100/40 rounded-2xl p-4 space-y-2.5">
          <span className="text-[9.5px] font-bold font-mono uppercase tracking-widest text-[#8B5CF6] block">
            System Specs Sheet
          </span>
          <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-[10.5px] text-[#6E6E73] font-mono leading-tight">
            {Object.entries(product.specs).slice(0, 4).map(([key, val]) => (
              <div key={key} className="space-y-0.5">
                <span className="text-zinc-400 font-bold block text-[9.5px]">{key}</span>
                <span className="text-apple-dark truncate block max-w-[135px] font-semibold" title={val}>
                  {val}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Interactive storage capacity radio toggles */}
        <div className="space-y-2">
          <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">
            Configure Storage:
          </span>
          <div className="flex flex-wrap gap-2">
            {product.storages.map((sz, idx) => (
              <button
                key={sz}
                type="button"
                onClick={(e) => { e.stopPropagation(); setSelectedStorageIdx(idx); }}
                className={`px-3.5 py-1.5 text-xs font-bold border rounded-lg transition-all cursor-pointer ${
                  selectedStorageIdx === idx 
                  ? 'bg-apple-dark text-white border-transparent shadow-xs' 
                  : 'bg-zinc-50 hover:bg-zinc-100 border-gray-200 text-zinc-500'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Pricing Box with EMI recalculations */}
        <div className="pt-3 border-t border-gray-150 flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
          <div>
            <span className="text-[10px] text-zinc-400 block font-bold uppercase tracking-wide">
              Configured Valuation
            </span>
            <div className="flex items-center gap-2 mt-1">
              {product.discount > 0 && (
                <span className="text-xs text-zinc-400 line-through font-mono font-medium">
                  {formatINR(configuredOriginalPrice)}
                </span>
              )}
              <span className="text-xl font-black text-emerald-500 tracking-tight leading-none">
                {formatINR(configuredDiscountPrice)}
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono mt-0.5 block leading-none">
              Or {formatEMI(configuredDiscountPrice)}/mo. EMI for 24 months
            </span>
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleQuickAdd}
              className={`px-4 py-2.5 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer max-w-[150px] ${
                addedAnimation 
                ? 'bg-emerald-500 text-white' 
                : 'bg-zinc-950 text-white hover:bg-black active:scale-95'
              }`}
            >
              {addedAnimation ? (
                <>
                  <Check className="w-4 h-4" />
                  Bagged!
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5" />
                  Add to Bag
                </>
              )}
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}

// Ultra-premium shimmering skeleton screen loading animations
function SkeletonLoader() {
  return (
    <div className="space-y-8" id="skeleton-container">
      {[1, 2, 3].map((n) => (
        <div key={n} className="bg-white dark:bg-zinc-900/30 border border-zinc-200 dark:border-white/10 rounded-[28px] overflow-hidden p-6 grid grid-cols-1 md:grid-cols-2 gap-6 relative">
          <div className="bg-zinc-100 dark:bg-zinc-950/40 rounded-2xl h-64 flex items-center justify-center relative overflow-hidden">
            <div className="w-24 h-40 rounded-lg shimmer-bg" />
          </div>
          <div className="space-y-4 py-2">
            <div className="h-4 rounded-md w-1/4 shimmer-bg" />
            <div className="h-7 rounded-md w-2/3 shimmer-bg" />
            <div className="h-4 rounded-md w-1/3 shimmer-bg" />
            <div className="space-y-2 pt-4">
              <div className="h-3 rounded-md w-full shimmer-bg" />
              <div className="h-3 rounded-md w-5/6 shimmer-bg" />
            </div>
            <div className="flex gap-3 pt-8">
              <div className="h-10 rounded-full w-1/2 shimmer-bg" />
              <div className="h-10 rounded-full w-1/2 shimmer-bg" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function CollectionPage({ setView }: CollectionPageProps) {
  const { products, categories, fetchProducts } = useStore();

  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activePriceRange, setActivePriceRange] = useState<number>(160000);
  const [activeRating, setActiveRating] = useState<number>(0);
  const [activeStorage, setActiveStorage] = useState<string>('all');
  const [activeColor, setActiveColor] = useState<string>('all');
  const [activeStock, setActiveStock] = useState<boolean>(false); // True: In-stock only
  const [isLoading, setIsLoading] = useState(true);
  
  // Default to 'twobox' double card layout format for premium catalog experience
  const [layoutMode, setLayoutMode] = useState<'grid' | 'twobox'>('twobox');

  useEffect(() => {
    setIsLoading(true);
    fetchProducts().then(() => {
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 700);
      return () => clearTimeout(timer);
    });
  }, []);

  // Filter in memory for advanced responsive UI checks
  const filteredProducts = products.filter((p) => {
    // 1. Category Filter
    if (activeCategory !== 'all' && p.category.toLowerCase() !== activeCategory.toLowerCase()) {
      return false;
    }
    
    // 2. Calculated Discount Price upper boundary
    const discountPrice = p.price * (1 - p.discount / 100);
    if (discountPrice > activePriceRange) {
      return false;
    }

    // 3. Minimum Average Rating
    if (p.ratings.average < activeRating) {
      return false;
    }

    // 4. Storage selection
    if (activeStorage !== 'all' && !p.storages.includes(activeStorage)) {
      return false;
    }

    // 5. Color Hex match
    if (activeColor !== 'all' && !p.colorNames.some(cName => cName.toLowerCase().includes(activeColor.toLowerCase()))) {
      return false;
    }

    // 6. In-Stock toggle
    if (activeStock && p.stock <= 0) {
      return false;
    }

    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-apple-dark" id="collection-page-main">
      
      {/* Visual Top Header Tag */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 pb-4 border-b border-violet-100/40">
        <div>
          <span className="text-[10px] bg-[#EFE7FF] text-[#8B5CF6] border border-violet-100/30 font-extrabold px-3 py-1 rounded-full uppercase tracking-widest font-mono">
            Interactive Design Studio
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#1D1D1F] tracking-tight mt-2.5">
            Store Hardware & Collections.
          </h1>
          <p className="text-xs sm:text-sm text-[#6E6E73] mt-1 max-w-2xl">
            Configure model finishes on-the-fly, inspect pricing details, and choose capacity options directly inside our interactive layered layout.
          </p>
        </div>

        {/* Specs comparative matrix CTA button */}
        <button
          onClick={() => setView('compare')}
          className="bg-zinc-950 hover:bg-black hover:scale-[1.02] text-white py-3 px-5 rounded-full text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-sm shrink-0 cursor-pointer border border-[#EFE7FF]/20"
          id="compare-launcher-btn"
        >
          Compare Specifications Matrix
          <span className="bg-[#8B5CF6] text-white text-[9px] px-2 py-0.5 rounded-full font-mono animate-pulse">
             Live
          </span>
        </button>
      </div>

      {/* Category selector capsules */}
      <div className="flex pb-5 mb-8 overflow-x-auto gap-3 scrollbar-none" id="categories-tabs">
        <button 
          onClick={() => setActiveCategory('all')} 
          className={`px-4.5 py-2.5 text-xs font-bold rounded-full border transition-all cursor-pointer shrink-0 ${activeCategory === 'all' ? 'bg-black text-white border-transparent shadow-sm' : 'bg-white text-[#1D1D1F] border-violet-100/60 hover:bg-[#EFE7FF]'}`}
        >
          All Premium Hardware
        </button>
        {categories.map((c) => (
          <button 
            key={c.id} 
            onClick={() => setActiveCategory(c.name)} 
            className={`px-4.5 py-2.5 text-xs font-bold rounded-full border transition-all cursor-pointer shrink-0 ${activeCategory === c.name ? 'bg-black text-white border-transparent shadow-sm' : 'bg-white text-[#1D1D1F] border-violet-100/60 hover:bg-[#EFE7FF]'}`}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* LEFT DECK: Filter Sidebar */}
        <div className="lg:col-span-1 bg-white border border-violet-100/60 rounded-[32px] p-5 space-y-6 h-fit shadow-[0_8px_30px_rgba(139,92,246,0.05)] animate-fade-in" id="advanced-filters-sidebar">
          
          <div className="flex items-center gap-2 border-b border-violet-100/40 pb-3 mb-1">
            <SlidersHorizontal className="w-4 h-4 text-[#8B5CF6]" />
            <span className="font-bold text-sm tracking-tight text-[#1D1D1F]">Advanced Filters</span>
          </div>

          {/* Price Range Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-bold">
              <span className="text-[#6E6E73]">Max Budget:</span>
              <span className="text-[#8B5CF6] font-extrabold">{formatINR(activePriceRange)}</span>
            </div>
            <input 
              type="range" 
              className="w-full h-1 bg-violet-100 rounded-lg appearance-none cursor-pointer accent-[#8B5CF6]"
              min="40000" 
              max="160000" 
              step="5000"
              value={activePriceRange}
              onChange={(e) => setActivePriceRange(Number(e.target.value))}
            />
            <div className="flex justify-between text-[9px] text-[#6E6E73] font-mono">
              <span>{formatINR(40000)}</span>
              <span>{formatINR(160000)}</span>
            </div>
          </div>

          {/* Rating filter radio */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Minimum Ratings</span>
            <div className="space-y-1.5 text-xs text-zinc-650">
              <label className="flex items-center gap-2 cursor-pointer font-bold hover:text-black">
                <input 
                  type="radio" 
                  name="rating" 
                  checked={activeRating === 0} 
                  onChange={() => setActiveRating(0)}
                  className="rounded-full text-zinc-950 border-gray-300 cursor-pointer focus:ring-zinc-900"
                />
                Show All Ratings
              </label>

              {[4.7, 4.6, 4.4].map((score) => (
                <label key={score} className="flex items-center gap-2 cursor-pointer font-bold hover:text-black">
                  <input 
                    type="radio" 
                    name="rating" 
                    checked={activeRating === score} 
                    onChange={() => setActiveRating(score)}
                    className="rounded-full text-zinc-950 border-gray-300 cursor-pointer focus:ring-zinc-900"
                  />
                  <div className="flex items-center gap-1">
                    <span className="flex text-amber-400"><Star className="w-3.5 h-3.5 fill-amber-400" /></span>
                    <span>{score} & Up</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Storage selector capsules */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Storage Capacity</span>
            <div className="flex flex-wrap gap-1.5">
              {['all', '128GB', '256GB', '512GB', '1TB'].map((sz) => (
                <button 
                  key={sz}
                  onClick={() => setActiveStorage(sz)}
                  className={`px-3 py-1.5 text-[10.5px] font-extrabold border rounded-lg transition-all cursor-pointer ${activeStorage === sz ? 'bg-black text-white border-transparent shadow-xs' : 'bg-zinc-50 border-gray-200 hover:bg-gray-100 text-zinc-600'}`}
                >
                  {sz === 'all' ? 'All sizes' : sz}
                </button>
              ))}
            </div>
          </div>

          {/* Color filter bubble list */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Color Finish Palette</span>
            <div className="flex flex-wrap gap-1.5">
              {['all', 'Titanium', 'Teal', 'Pink', 'Starlight', 'Midnight', 'Black', 'Blue'].map((col) => (
                <button 
                  key={col}
                  onClick={() => setActiveColor(col)}
                  className={`px-3 py-1.5 text-[10.5px] font-extrabold border rounded-lg transition-all cursor-pointer ${activeColor === col ? 'bg-black text-white border-transparent' : 'bg-zinc-50 border-gray-200 hover:bg-gray-100 text-zinc-600'}`}
                >
                  {col === 'all' ? 'All' : col}
                </button>
              ))}
            </div>
          </div>

          {/* In-Stock toggle check */}
          <div className="border-t border-gray-100 pt-4 flex items-center justify-between">
            <label htmlFor="avail-toggle" className="text-xs font-bold text-zinc-700 cursor-pointer">In-Stock Only</label>
            <input 
              type="checkbox" 
              id="avail-toggle" 
              checked={activeStock}
              onChange={(e) => setActiveStock(e.target.checked)}
              className="rounded text-zinc-955 border-gray-300 w-4 h-4 cursor-pointer focus:ring-zinc-900"
            />
          </div>

          {/* Reset Filters CTA */}
          <button 
            onClick={() => {
              setActiveCategory('all');
              setActivePriceRange(160000);
              setActiveRating(0);
              setActiveStorage('all');
              setActiveColor('all');
              setActiveStock(false);
            }}
            className="w-full text-center py-2.5 border border-zinc-200 hover:border-black rounded-xl text-xs font-bold cursor-pointer hover:bg-zinc-50 transition-colors"
          >
            Reset Catalog Filters
          </button>

        </div>

        {/* RIGHT DECK: Product list result cards */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Deck Toolbar with Responsive Switchers */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-150 pb-3.5">
            <div className="text-xs text-[#86868b] font-medium">
              Showing <span className="font-extrabold text-apple-dark">{filteredProducts.length}</span> matching premium models catalog
            </div>

            {/* Twin Layout Deck Switcher (Compact vs Double Box format) */}
            <div className="flex bg-[#EFE7FF] p-1 rounded-xl items-center border border-violet-105/30 self-start sm:self-auto shadow-4xs">
              <button
                type="button"
                onClick={() => setLayoutMode('grid')}
                className={`p-1.5 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-xs font-bold cursor-pointer ${layoutMode === 'grid' ? 'bg-white text-zinc-900 shadow-xs' : 'text-[#6E6E73] hover:text-[#1D1D1F]'}`}
              >
                <Grid className="w-3.5 h-3.5" />
                Grid View
              </button>
              <button
                type="button"
                onClick={() => setLayoutMode('twobox')}
                className={`p-1.5 px-3.5 rounded-lg flex items-center gap-1.5 transition-all text-xs font-bold cursor-pointer ${layoutMode === 'twobox' ? 'bg-white text-zinc-900 shadow-xs' : 'text-[#6E6E73] hover:text-[#1D1D1F]'}`}
              >
                <Layers className="w-3.5 h-3.5 text-[#8B5CF6]" />
                2-Box Layer Format
              </button>
            </div>
          </div>

          {isLoading ? (
            <SkeletonLoader />
          ) : filteredProducts.length === 0 ? (
            <div className="h-72 flex flex-col items-center justify-center text-center bg-[#F5F5F7]/30 border border-dashed border-gray-200 rounded-3xl p-8" id="empty-collection-results">
              <span className="text-zinc-400 text-xs font-bold uppercase tracking-wider">No Catalog Matches Found</span>
              <p className="text-[11px] text-[#86868b] mt-1.5 max-w-sm font-medium">
                We couldn't locate any items matching your active filter criteria. Relax your budget max range or rating selection to reload catalog models.
              </p>
            </div>
          ) : (
            <div>
              {layoutMode === 'twobox' ? (
                /* Premium 2-Box Layer format list block */
                <div className="space-y-8 animate-fade-in" id="collection-twobox-list">
                  {filteredProducts.map((p) => (
                    <TwoBoxProductCard key={p.id} product={p} setView={setView} />
                  ))}
                </div>
              ) : (
                /* Compact columns grid matching fallback visual */
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in" id="collection-grid-list">
                  {filteredProducts.map((p) => (
                    <ProductCard key={p.id} product={p} setView={setView} />
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
